using System;
using System.Diagnostics;
using ShatteredWorld.Simulation;
using ShatteredWorld.Tests;
if(args.Length==2&&args[0]=="--export-map")
{
    var options=new System.Text.Json.JsonSerializerOptions{IncludeFields=true,WriteIndented=true};
    // Serialize only map definitions; calculated V2 properties are not needed in the diagram.
    options.IgnoreReadOnlyProperties=true;
    System.IO.File.WriteAllText(args[1],System.Text.Json.JsonSerializer.Serialize(new MapLayout(),options));return;
}
int failures=0;
foreach(var test in ScenarioSuite.Cases)
{
    try {test.Value();Console.WriteLine("PASS "+test.Key);}
    catch(Exception e){failures++;Console.WriteLine("FAIL "+test.Key+": "+e.Message);}
}
Console.WriteLine($"Scenarios: {ScenarioSuite.Cases.Count-failures}/{ScenarioSuite.Cases.Count}");
if(Array.IndexOf(args,"--smoke")>=0)
{
    var timer=Stopwatch.StartNew();var w=new MatchWorld();
    if(Array.IndexOf(args,"--bots")>=0)w.Player.IsPlayer=false;
    double duration=Array.IndexOf(args,"--long")>=0?1800:960;
    while(w.Clock.Time<duration&&w.Phase==MatchPhase.Playing)w.Step();
    int aliveTowers=0,deadHeroes=0;foreach(var u in w.Units){if(u.Kind==Kind.Tower&&u.Alive)aliveTowers++;if(u.IsHero&&!u.Alive)deadHeroes++;}
    Console.WriteLine($"SMOKE time={w.Clock.Time:F2}s phase={w.Phase} winner={w.Winner} kills={w.Kills[0]}:{w.Kills[1]} towers={aliveTowers} units={w.Units.Count} elapsed={timer.Elapsed.TotalSeconds:F2}s");
    if(Array.IndexOf(args,"--verbose")>=0)
    {
        foreach(var u in w.Units)if(u.IsHero||u.IsStructure)Console.WriteLine($"UNIT {u.Id} {u.Team} {u.Kind} L{u.Lane} T{u.Tier} hp={u.Health:F0} p=({u.Position.X:F1},{u.Position.Y:F1}) dest=({u.Destination.X:F1},{u.Destination.Y:F1}) path={u.PathIndex}/{u.Path.Count} target={u.Target}");
        foreach(var u in w.Units)if(u.IsMinion&&u.Alive)Console.WriteLine($"MINION {u.Id} {u.Team} {u.Kind} L{u.Lane} d={u.LaneDistance:F1} p=({u.Position.X:F1},{u.Position.Y:F1}) hp={u.Health:F0}");
    }
    if(w.Phase!=MatchPhase.Finished){Console.WriteLine("FAIL automated match did not finish within requested duration");failures++;}
}
Environment.ExitCode=failures==0?0:1;
