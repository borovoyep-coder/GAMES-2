"""Validate the generated real 3D streams without requiring Unity."""
import json,math,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];source=root/'Assets/ShatteredWorld/Art/Source'
manifest=json.loads((source/'ArtManifest.json').read_text());palette={m['Name'] for m in manifest['Materials']};triangles=vertices=0;names=[]
for model in manifest['Models']:
 bundle=json.loads((source/model['File']).read_text());counted=0
 for chunk in bundle['Chunks']:
  n=len(chunk['Vertices'])//3;assert len(chunk['Vertices'])==n*3;assert len(chunk['Normals'])==n*3;assert len(chunk['Colors'])==n*4;assert len(chunk['UV'])==n*2
  assert all(math.isfinite(v) for v in chunk['Vertices']+chunk['Normals']+chunk['UV'])
  assert all(0<=v<=1.001 for v in chunk['Colors'])
  assert all(.98<sum(v*v for v in chunk['Normals'][i:i+3])<1.02 for i in range(0,n*3,3))
  for sub in chunk['Submeshes']:
   assert sub['Material'] in palette;assert len(sub['Triangles'])%3==0;assert min(sub['Triangles'],default=0)>=0;assert max(sub['Triangles'],default=0)<n;counted+=len(sub['Triangles'])//3
  vertices+=n
 assert counted==model['Triangles'],model['Name'];triangles+=counted;names.append(model['Name']);print('PASS mesh',model['Name'],counted,'triangles',len(bundle['Chunks']),'spatial chunks')
required={'Environment','Bridge','CrystalGate','MagmaGuardian','MoonWolf','RiftGhost','AzureGolem','StoneCentipede','CrystalCrab','ObserverFirefly','RiftRay','SolarColossus','NightLeviathan','TowerBlue','TowerRed','CoreBlue','CoreRed'}
assert required<=set(names)
layout=json.loads((source/'ValleyLayout.json').read_text());vegetation=json.loads((source/'ValleyVegetation.json').read_text())
assert layout['TreeObstacles']==vegetation['Positions'];assert len(vegetation['Positions'])>100;assert len(layout['Camps'])==12 and len(layout['Crystals'])==8 and len(layout['Bridges'])==2
for material in manifest['Materials']:assert (root/'Assets/ShatteredWorld/Art/Textures'/(material['Texture']+'.png')).is_file()
print('PASS shared palette, all creature types, source textures and tree/navigation parity')
print('TOTAL',len(names),'model kits',triangles,'prototype triangles',vertices,'vertices')
