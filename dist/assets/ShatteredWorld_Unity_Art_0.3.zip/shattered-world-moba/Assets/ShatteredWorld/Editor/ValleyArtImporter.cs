using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using ShatteredWorld.Simulation;
using ShatteredWorld.Unity;

namespace ShatteredWorld.Editor
{
    public static class ValleyArtImporter
    {
        const string Source="Assets/ShatteredWorld/Art/Source/";
        const string Generated="Assets/ShatteredWorld/Art/Generated/";
        public const string CatalogPath="Assets/ShatteredWorld/Resources/ValleyArtCatalog.asset";
        public const string ShowcasePath="Assets/ShatteredWorld/Scenes/ValleyShowcase.unity";

        [MenuItem("Shattered World/Art/Rebuild native meshes and prefabs")]
        public static void Rebuild(){EnsureGenerated(true);AssetDatabase.SaveAssets();}

        public static ValleyArtCatalog EnsureGenerated(bool force=false)
        {
            var existing=AssetDatabase.LoadAssetAtPath<ValleyArtCatalog>(CatalogPath);
            if(existing&&!force)return existing;
            string manifestPath=Source+"ArtManifest.json";
            if(!File.Exists(manifestPath)){Debug.LogWarning("Valley art source has not been generated. Legacy blockout remains available.");return null;}
            var manifest=JsonUtility.FromJson<ArtManifestData>(File.ReadAllText(manifestPath));
            Directory.CreateDirectory(Generated+"Meshes");Directory.CreateDirectory(Generated+"Materials");Directory.CreateDirectory(Generated+"Prefabs");Directory.CreateDirectory("Assets/ShatteredWorld/Resources");
            AssetDatabase.Refresh();
            var shader=Shader.Find("Shattered World/Painted World");
            if(!shader)throw new InvalidOperationException("Painted World shader is missing; wait for Unity to import the shader before rebuilding art.");
            var palette=new Dictionary<string,Material>();
            foreach(var definition in manifest.Materials)
            {
                string path=Generated+"Materials/"+definition.Name+".mat";
                var material=AssetDatabase.LoadAssetAtPath<Material>(path);
                if(!material){material=new Material(shader);AssetDatabase.CreateAsset(material,path);}
                material.shader=shader;material.SetColor("_BaseColor",Color.white);
                material.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/ShatteredWorld/Art/Textures/"+definition.Texture+".png"));
                material.SetFloat("_EmissionStrength",definition.Emission);
                material.SetFloat("_WindStrength",definition.Name=="Foliage"?.09f:0);
                material.SetFloat("_FlowSpeed",definition.Name=="Water"?.025f:0);
                material.SetFloat("_ShadeStrength",.72f);material.enableInstancing=true;
                EditorUtility.SetDirty(material);palette.Add(definition.Name,material);
            }
            var entries=new List<ArtModelReference>();
            try
            {
                for(int modelIndex=0;modelIndex<manifest.Models.Length;modelIndex++)
                {
                    var model=manifest.Models[modelIndex];
                    EditorUtility.DisplayProgressBar("Valley of Shards — import",model.Name,(float)modelIndex/manifest.Models.Length);
                    var data=JsonUtility.FromJson<ArtBundleData>(File.ReadAllText(Source+model.File));
                    var root=new GameObject(model.Name);var visual=new GameObject("Visual");visual.transform.SetParent(root.transform,false);
                    foreach(var chunk in data.Chunks)
                    {
                        ValidateChunk(chunk);
                        string path=Generated+"Meshes/"+chunk.Name+".asset";
                        var mesh=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                        bool fresh=!mesh;if(fresh)mesh=new Mesh{name=chunk.Name};else mesh.Clear();
                        mesh.indexFormat=chunk.Vertices.Length/3>65535?IndexFormat.UInt32:IndexFormat.UInt16;
                        int count=chunk.Vertices.Length/3;var vertices=new Vector3[count];var normals=new Vector3[count];var colors=new Color[count];var uv=new Vector2[count];
                        for(int i=0;i<count;i++)
                        {
                            vertices[i]=new Vector3(chunk.Vertices[i*3],chunk.Vertices[i*3+1],chunk.Vertices[i*3+2]);
                            normals[i]=new Vector3(chunk.Normals[i*3],chunk.Normals[i*3+1],chunk.Normals[i*3+2]);
                            colors[i]=new Color(chunk.Colors[i*4],chunk.Colors[i*4+1],chunk.Colors[i*4+2],chunk.Colors[i*4+3]);
                            uv[i]=new Vector2(chunk.UV[i*2],chunk.UV[i*2+1]);
                        }
                        mesh.vertices=vertices;mesh.normals=normals;mesh.colors=colors;mesh.uv=uv;mesh.subMeshCount=chunk.Submeshes.Length;
                        var materials=new Material[chunk.Submeshes.Length];
                        for(int i=0;i<chunk.Submeshes.Length;i++){mesh.SetTriangles(chunk.Submeshes[i].Triangles,i,false);materials[i]=palette[chunk.Submeshes[i].Material];}
                        mesh.RecalculateBounds();
                        if(fresh)AssetDatabase.CreateAsset(mesh,path);else EditorUtility.SetDirty(mesh);
                        var part=new GameObject(chunk.Name);part.transform.SetParent(visual.transform,false);
                        part.AddComponent<MeshFilter>().sharedMesh=mesh;
                        var renderer=part.AddComponent<MeshRenderer>();renderer.sharedMaterials=materials;renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
                        if(model.Name=="Environment")GameObjectUtility.SetStaticEditorFlags(part,StaticEditorFlags.BatchingStatic|StaticEditorFlags.OccluderStatic);
                    }
                    bool living=!model.Name.StartsWith("Tower")&&!model.Name.StartsWith("Core")&&model.Name!="Environment"&&model.Name!="Bridge"&&model.Name!="CrystalGate";
                    if(living){var idle=root.AddComponent<StylizedIdleMotion>();idle.Visual=visual.transform;idle.Floating=model.Name=="RiftGhost"||model.Name=="ObserverFirefly"||model.Name=="RiftRay"||model.Name=="NightLeviathan";}
                    var prefab=PrefabUtility.SaveAsPrefabAsset(root,Generated+"Prefabs/"+model.Name+".prefab");
                    UnityEngine.Object.DestroyImmediate(root);entries.Add(new ArtModelReference{Name=model.Name,Prefab=prefab,Triangles=model.Triangles});
                }
            }
            finally{EditorUtility.ClearProgressBar();}
            var catalog=existing?existing:ScriptableObject.CreateInstance<ValleyArtCatalog>();catalog.Version=manifest.Version;catalog.Models=entries.ToArray();catalog.InvalidateCache();
            foreach(var entry in entries)if(entry.Name=="Environment")catalog.Environment=entry.Prefab;
            if(!existing)AssetDatabase.CreateAsset(catalog,CatalogPath);else EditorUtility.SetDirty(catalog);
            AssetDatabase.SaveAssets();Debug.Log("Valley art: imported "+entries.Count+" native mesh prefabs. Blender is not needed to open this Unity project.");return catalog;
        }

        public static void ValidateChunk(ArtChunkData chunk)
        {
            int count=chunk.Vertices.Length/3;
            if(chunk.Vertices.Length%3!=0||chunk.Normals.Length!=count*3||chunk.Colors.Length!=count*4||chunk.UV.Length!=count*2)throw new InvalidDataException("Invalid vertex stream: "+chunk.Name);
            foreach(var sub in chunk.Submeshes)
            {
                if(sub.Triangles.Length%3!=0)throw new InvalidDataException("Invalid triangle stream: "+chunk.Name);
                foreach(int index in sub.Triangles)if(index<0||index>=count)throw new InvalidDataException("Invalid mesh index: "+chunk.Name);
            }
        }

        public static void ApplyDetailedLayout(MatchConfig configuration)
        {
            string path=Source+"ValleyLayout.json";
            if(File.Exists(path)){configuration.Layout=JsonUtility.FromJson<MapLayout>(File.ReadAllText(path));EditorUtility.SetDirty(configuration);}
        }

        static GameObject Place(ValleyArtCatalog catalog,string name,Transform parent,V2 position,float height=0)
        {
            var prefab=catalog.Find(name);if(!prefab)return null;
            var go=(GameObject)PrefabUtility.InstantiatePrefab(prefab);go.transform.SetParent(parent,false);go.transform.localPosition=WorldRenderer.P(position,height);return go;
        }
        static void Identify(GameObject go,ArtObjectKind kind,int index,string name,Team team=Team.Neutral)
        {
            if(!go)return;var id=go.AddComponent<WorldArtIdentity>();id.Kind=kind;id.Index=index;id.DisplayName=name;id.Team=team;
        }

        public static void CreateShowcase(MatchConfig configuration,ValleyArtCatalog catalog)
        {
            if(!catalog||File.Exists(ShowcasePath))return;
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var preview=new GameObject("Valley · complete edit-time art preview");
            var environment=(GameObject)PrefabUtility.InstantiatePrefab(catalog.Environment);environment.transform.SetParent(preview.transform,false);
            var world=new MatchWorld(configuration.Rules,configuration.Layout);
            while(world.Clock.Time<420)world.Clock.Advance();world.Objectives.Update();
            foreach(var unit in world.Units)
            {
                var go=Place(catalog,catalog.ModelFor(unit),preview.transform,unit.Position,.22f);if(!go)continue;
                var kind=unit.IsHero?ArtObjectKind.Hero:unit.Kind==Kind.Core?ArtObjectKind.Core:unit.Kind==Kind.Tower?ArtObjectKind.Tower:unit.Camp>=14?ArtObjectKind.Boss:unit.Camp>=12?ArtObjectKind.RiftCreature:ArtObjectKind.Camp;
                Identify(go,kind,unit.Camp>=0?unit.Camp:unit.Id,catalog.ModelFor(unit),unit.Team);
            }
            for(int i=0;i<8;i++)Identify(Place(catalog,"CrystalGate",preview.transform,configuration.Layout.Crystals[i]),ArtObjectKind.Crystal,i,"Кристальный проход "+(i+1));
            for(int i=0;i<2;i++)
            {
                var bridge=Place(catalog,"Bridge",preview.transform,configuration.Layout.Bridges[i],-.45f);
                bridge.transform.localRotation=Quaternion.Euler(0,45,0);bridge.SetActive(i==0);Identify(bridge,ArtObjectKind.Bridge,i,i==0?"Мост Рассвета":"Мост Сумерек");
            }
            var controller=new GameObject("Valley art inspection").AddComponent<ValleyShowcaseController>();controller.Configuration=configuration;controller.EditTimePreview=preview;
            var camera=new GameObject("Main Camera").AddComponent<Camera>();camera.tag="MainCamera";camera.gameObject.AddComponent<AudioListener>();camera.orthographic=true;camera.orthographicSize=77;camera.farClipPlane=400;camera.nearClipPlane=.1f;camera.backgroundColor=new Color(.035f,.09f,.12f);camera.transform.position=new Vector3(0,140,-98);camera.transform.LookAt(new Vector3(0,-.5f,0));camera.gameObject.AddComponent<UniversalAdditionalCameraData>().renderPostProcessing=true;
            SetupLighting();
            EditorSceneManager.SaveScene(scene,ShowcasePath);
            var view=SceneView.lastActiveSceneView;if(view)view.LookAt(new Vector3(0,0,0),Quaternion.Euler(55,0,0),90);
        }

        public static void SetupLighting()
        {
            Directory.CreateDirectory(Generated);AssetDatabase.Refresh();
            var sun=new GameObject("Warm morning key light").AddComponent<Light>();sun.type=LightType.Directional;sun.color=new Color(1,.91f,.77f);sun.intensity=1.6f;sun.shadows=LightShadows.Soft;sun.shadowStrength=.75f;sun.transform.rotation=Quaternion.Euler(48,-35,0);
            RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=new Color(.42f,.54f,.6f);RenderSettings.ambientEquatorColor=new Color(.31f,.4f,.34f);RenderSettings.ambientGroundColor=new Color(.2f,.24f,.22f);
            RenderSettings.fog=true;RenderSettings.fogMode=FogMode.Linear;RenderSettings.fogColor=new Color(.045f,.13f,.17f);RenderSettings.fogStartDistance=135;RenderSettings.fogEndDistance=260;QualitySettings.shadowDistance=140;
            var volume=new GameObject("Subtle crystal bloom").AddComponent<Volume>();volume.isGlobal=true;
            var profile=ScriptableObject.CreateInstance<VolumeProfile>();var bloom=profile.Add<Bloom>();bloom.intensity.Override(.26f);bloom.threshold.Override(1.2f);
            volume.sharedProfile=profile;
            string path=Generated+"ValleyVolume.asset";
            var existing=AssetDatabase.LoadAssetAtPath<VolumeProfile>(path);
            if(!existing)
            {
                AssetDatabase.CreateAsset(profile,path);
                foreach(var component in profile.components)AssetDatabase.AddObjectToAsset(component,profile);
            }
            else{volume.sharedProfile=existing;UnityEngine.Object.DestroyImmediate(profile);}
        }
    }
}
