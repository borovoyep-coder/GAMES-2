using System.Collections.Generic;
using UnityEngine;
using ShatteredWorld.Simulation;
namespace ShatteredWorld.Unity
{
    public sealed partial class WorldRenderer
    {
        public static readonly Color Blue=new Color(.16f,.65f,1),Red=new Color(1,.23f,.28f),Gold=new Color(.88f,.67f,.28f),Purple=new Color(.64f,.23f,1);
        readonly Transform root;
        readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
        readonly Dictionary<int,GameObject> units=new Dictionary<int,GameObject>();
        readonly Dictionary<string,Stack<GameObject>> pool=new Dictionary<string,Stack<GameObject>>();
        readonly Dictionary<int,string> kinds=new Dictionary<int,string>();
        readonly HashSet<int> alive=new HashSet<int>();readonly List<int> remove=new List<int>();
        readonly GameObject[] crystals=new GameObject[8],bridges=new GameObject[2];
        readonly List<GameObject> telegraphs=new List<GameObject>();
        public bool ShowAll { get; set; }
        public bool UsesDetailedArt=>artCatalog;
        public WorldRenderer(Transform root,bool showAll=false){this.root=root;ShowAll=showAll;artCatalog=Resources.Load<ValleyArtCatalog>("ValleyArtCatalog");}
        public static Vector3 P(V2 p,float y=0)=>new Vector3(p.X,y,p.Y);
        Material Mat(Color color,bool emission=false)
        {
            string key=ColorUtility.ToHtmlStringRGBA(color)+(emission?"e":"");if(materials.TryGetValue(key,out var existing))return existing;
            var shader=Shader.Find("Universal Render Pipeline/Lit")??Shader.Find("Standard");var m=new Material(shader){color=color};
            if(emission){m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",color*1.1f);}materials.Add(key,m);return m;
        }
        GameObject Shape(string name,PrimitiveType type,Vector3 position,Vector3 scale,Color color,Transform parent=null,bool glow=false)
        {
            var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(parent?parent:root,false);go.transform.localPosition=position;go.transform.localScale=scale;
            go.GetComponent<Renderer>().sharedMaterial=Mat(color,glow);Object.Destroy(go.GetComponent<Collider>());return go;
        }
        void Road(V2 a,V2 b,float width,Color color,float y=.03f)
        {
            var direction=P(b-a);var go=Shape("Древняя дорога",PrimitiveType.Cube,P((a+b)/2,y),new Vector3(width,.15f,direction.magnitude),color);
            go.transform.rotation=Quaternion.LookRotation(direction);
        }
        void Ring(V2 center,float radius,Color color,float y=.15f,int segments=48,float width=.15f)
        {
            var go=new GameObject("Рунический круг");go.transform.SetParent(root);var line=go.AddComponent<LineRenderer>();line.sharedMaterial=Mat(color,true);
            line.positionCount=segments+1;line.startWidth=width;line.endWidth=width;line.useWorldSpace=true;
            for(int i=0;i<=segments;i++){float a=i*Mathf.PI*2/segments;line.SetPosition(i,P(center,y)+new Vector3(Mathf.Cos(a)*radius,0,Mathf.Sin(a)*radius));}
        }
        public void Build(MapLayout map)
        {
            if(BuildDetailedArt(map))return;
            Shape("Парящий каменный материк",PrimitiveType.Cube,new Vector3(0,-2.2f,0),new Vector3(116,4,116),new Color(.17f,.24f,.23f));
            Shape("Земля долины",PrimitiveType.Cube,new Vector3(0,-.3f,0),new Vector3(114,.6f,114),new Color(.2f,.32f,.22f));
            var river=Shape("Бирюзовый разлом",PrimitiveType.Cube,new Vector3(0,-.03f,0),new Vector3(7,.25f,126),new Color(.03f,.53f,.58f),null,true);river.transform.rotation=Quaternion.Euler(0,135,0);
            foreach(var lane in map.Lanes)for(int i=1;i<lane.Length;i++)Road(lane[i-1],lane[i],7,new Color(.52f,.46f,.32f),.12f);
            foreach(var wall in map.Walls)
            {
                Shape("Руины · препятствие",PrimitiveType.Cube,P(wall.Center,1),new Vector3(wall.Size.X,2,wall.Size.Y),new Color(.49f,.46f,.35f));
                Shape("Карниз руин",PrimitiveType.Cube,P(wall.Center,2.1f),new Vector3(wall.Size.X+.3f,.3f,wall.Size.Y+.3f),Gold);
                int n=(int)(Mathf.Max(wall.Size.X,wall.Size.Y)/2.5f);
                for(int j=0;j<n;j++)
                {
                    var p=wall.Center+new V2(wall.Size.X>wall.Size.Y?(j-n/2)*2.3f:0,wall.Size.Y>wall.Size.X?(j-n/2)*2.3f:0);
                    Tree(p);
                }
            }
            for(int i=0;i<2;i++)
            {
                Color c=i==0?Blue:Red;
                Shape("Площадь базы",PrimitiveType.Cylinder,P(map.Bases[i],.12f),new Vector3(19,.18f,19),new Color(.42f,.42f,.34f));Ring(map.Bases[i],8,c);
                Shape("Внешняя арена босса",PrimitiveType.Cylinder,P(map.Bosses[i],-.6f),new Vector3(26,.8f,26),new Color(.31f,.29f,.29f));
                Shape("Плиты арены",PrimitiveType.Cylinder,P(map.Bosses[i],.1f),new Vector3(24,.15f,24),i==0?new Color(.53f,.41f,.25f):new Color(.28f,.2f,.36f));
                Ring(map.Bosses[i],9,i==0?Gold:Purple);Ring(map.Bosses[i],6,i==0?Gold:Purple);
                foreach(var entrance in map.BossEntrances[i].Points)Road(entrance,map.Bosses[i],6,new Color(.48f,.42f,.33f));
                for(int j=0;j<12;j++)
                {float angle=j*Mathf.PI*2/12;var point=map.Bosses[i]+new V2(Mathf.Cos(angle),Mathf.Sin(angle))*11.5f;
                    if(map.OnLane(point,7))continue;Shape("Колонна арены",PrimitiveType.Cylinder,P(point,2),new Vector3(.9f,2,.9f),Gold);}
                bridges[i]=Shape("Динамический мост",PrimitiveType.Cube,P(map.Bridges[i],.25f),new Vector3(5,.5f,13),Gold,null,true);bridges[i].transform.rotation=Quaternion.Euler(0,45,0);
                Ring(map.Bridges[i],6,new Color(.13f,.77f,.74f));
            }
            for(int i=0;i<8;i++)
            {
                crystals[i]=new GameObject("Кристалл прохода "+i);crystals[i].transform.SetParent(root);crystals[i].transform.position=P(map.Crystals[i]);
                Shape("Кристалл",PrimitiveType.Cube,new Vector3(0,2,0),new Vector3(2,3.2f,2),Purple,crystals[i].transform,true).transform.localRotation=Quaternion.Euler(0,45,20);
                Ring(map.Crystals[i],2.5f,Purple);
            }
            foreach(var c in map.Camps){Shape("Лесной лагерь",PrimitiveType.Cylinder,P(c,.02f),new Vector3(7,.1f,7),new Color(.33f,.35f,.22f));Ring(c,3,new Color(.57f,.53f,.29f));}
            foreach(var b in map.Bushes)
                for(int i=0;i<8;i++){float a=i*Mathf.PI/4;Shape("Кусты · скрытие",PrimitiveType.Sphere,P(b+new V2(Mathf.Cos(a),Mathf.Sin(a))*1.5f,.6f),new Vector3(1.9f,1.5f,1.9f),new Color(.3f,.46f,.16f));}
            for(int side=0;side<4;side++)for(int i=0;i<28;i++)
            {
                float t=-55+i*4;V2 p=side==0?new V2(t,55):side==1?new V2(t,-55):side==2?new V2(55,t):new V2(-55,t);
                if(V2.Distance(p,map.Bosses[0])>14&&V2.Distance(p,map.Bosses[1])>14)Tree(p);
            }
        }
        void Tree(V2 p)
        {
            Shape("Ствол",PrimitiveType.Cylinder,P(p,1.2f),new Vector3(.55f,1.2f,.55f),new Color(.28f,.21f,.13f));
            Shape("Крона",PrimitiveType.Capsule,P(p,3.7f),new Vector3(2.4f,2.5f,2.4f),new Color(.07f,.25f,.19f));
        }
        GameObject CreateUnit(Unit u)
        {
            string poolKey=u.Kind+":"+u.Team+":"+u.Camp+":"+u.IsPlayer;
            if(pool.TryGetValue(poolKey,out var stack)&&stack.Count>0){var reused=stack.Pop();reused.SetActive(true);return reused;}
            var art=CreateDetailedUnit(u);if(art)return art;
            var go=new GameObject(u.Kind.ToString());go.transform.SetParent(root);
            Color c=u.Team==Team.Blue?Blue:u.Team==Team.Red?Red:u.Camp>=14?u.Camp==14?Gold:Purple:u.Camp%6==0?new Color(1,.36f,.1f):u.Camp%6==3?Blue:new Color(.68f,.63f,.46f);
            if(u.IsHero)
            {
                Shape("Герой",PrimitiveType.Capsule,new Vector3(0,1.5f,0),new Vector3(1.4f,1.5f,1.4f),c,go.transform);
                Shape("Нагрудник",PrimitiveType.Cube,new Vector3(0,1.6f,-.4f),new Vector3(1.5f,.9f,.6f),Gold,go.transform);
                Shape("Оружие",PrimitiveType.Cube,new Vector3(1,1.6f,0),new Vector3(.22f,u.Kind==Kind.Mage?3:2.6f,.3f),u.Kind==Kind.Mage?Purple:Gold,go.transform,true);
                if(u.IsPlayer)Shape("Метка игрока",PrimitiveType.Cylinder,new Vector3(0,.08f,0),new Vector3(2.7f,.05f,2.7f),new Color(.8f,.9f,.45f),go.transform,true);
            }
            else if(u.IsStructure)
            {
                bool core=u.Kind==Kind.Core;float scale=core?1.7f:1;
                Shape("Основание",PrimitiveType.Cylinder,new Vector3(0,.5f,0),new Vector3(3.8f*scale,.5f,3.8f*scale),Gold,go.transform);
                Shape("Башня",PrimitiveType.Cylinder,new Vector3(0,2*scale,0),new Vector3(2.2f*scale,1.5f*scale,2.2f*scale),new Color(.5f,.49f,.38f),go.transform);
                var shard=Shape("Ядро",PrimitiveType.Cube,new Vector3(0,4*scale,0),new Vector3(1.5f,2.4f,1.5f)*scale,c,go.transform,true);shard.transform.localRotation=Quaternion.Euler(0,45,15);
            }
            else if(u.Kind==Kind.Monster)
            {
                float s=u.Camp>=14?4:u.Camp<12&&u.Camp%6==1?1.3f:2;
                Shape("Существо",PrimitiveType.Sphere,new Vector3(0,s*.65f,0),new Vector3(s,s*1.3f,s),c,go.transform);
                Shape("Сердце",PrimitiveType.Cube,new Vector3(0,s*1.3f,0),new Vector3(s*.5f,s*.7f,s*.5f),u.Camp>=14?c:Purple,go.transform,true).transform.localRotation=Quaternion.Euler(0,45,15);
            }
            else
            {
                float s=u.Kind==Kind.Destroyer?1.5f:.8f;
                Shape("Миньон",u.Kind==Kind.Caster?PrimitiveType.Sphere:PrimitiveType.Capsule,new Vector3(0,s,0),new Vector3(s,s,s),c,go.transform);
                Shape("Шлем",PrimitiveType.Cube,new Vector3(0,s*1.6f,0),new Vector3(s,.4f,s),Gold,go.transform);
            }
            return go;
        }
        public void Sync(MatchWorld w)
        {
            alive.Clear();
            foreach(var u in w.Units)if(u.Alive&&(ShowAll||w.Visible(w.Player.Team,u)))
            {
                alive.Add(u.Id);if(!units.TryGetValue(u.Id,out var go)){go=CreateUnit(u);units.Add(u.Id,go);kinds[u.Id]=u.Kind+":"+u.Team+":"+u.Camp+":"+u.IsPlayer;}
                var target=P(u.Position,UsesDetailedArt?DetailedSurfaceHeight(w,u.Position):0);var delta=target-go.transform.position;
                if(delta.sqrMagnitude>.01f&&delta.sqrMagnitude<4)go.transform.rotation=Quaternion.Slerp(go.transform.rotation,Quaternion.LookRotation(delta),.2f);
                go.transform.position=target;
            }
            remove.Clear();foreach(var pair in units)if(!alive.Contains(pair.Key))remove.Add(pair.Key);
            foreach(int id in remove){var go=units[id];go.SetActive(false);var kind=kinds[id];if(!pool.TryGetValue(kind,out var stack)){stack=new Stack<GameObject>();pool.Add(kind,stack);}stack.Push(go);units.Remove(id);kinds.Remove(id);}
            for(int i=0;i<8;i++)crystals[i].SetActive(!w.Map.Crystals[i].Broken);
            for(int i=0;i<2;i++)
            {
                bridges[i].SetActive(w.Map.Bridges[i].Open);
                if(!UsesDetailedArt)bridges[i].transform.localScale=new Vector3(5,w.Map.Bridges[i].Warning?.3f+Mathf.Abs(Mathf.Sin(Time.time*5))*.5f:.5f,13);
                else PulseBridge(i,w.Map.Bridges[i].Warning);
            }
            if(UsesDetailedArt)SyncStrategicAreas(w);
            while(telegraphs.Count<w.Telegraphs.Count)telegraphs.Add(Shape("Опасная зона",PrimitiveType.Cylinder,Vector3.zero,Vector3.one,Red,null,true));
            for(int i=0;i<telegraphs.Count;i++)
            {
                bool active=i<w.Telegraphs.Count;telegraphs[i].SetActive(active);if(!active)continue;
                var t=w.Telegraphs[i];telegraphs[i].transform.position=P(t.Point,.35f);telegraphs[i].transform.localScale=new Vector3(t.Radius*2,.025f,t.Radius*2);
            }
        }
        public void Dispose()
        {
            foreach(var m in materials.Values)Object.Destroy(m);Object.Destroy(root.gameObject);
        }
    }
}
