using System;

namespace ShatteredWorld.Unity
{
    // Import-only plain data. The built player uses native Unity Mesh and Prefab assets.
    [Serializable] public sealed class ArtMaterialData {public string Name,Texture;public float Emission;}
    [Serializable] public sealed class ArtModelData {public string Name,File;public int Triangles,Chunks;}
    [Serializable] public sealed class ArtManifestData {public string Version;public ArtModelData[] Models;public ArtMaterialData[] Materials;}
    [Serializable] public sealed class ArtSubmeshData {public string Material;public int[] Triangles;}
    [Serializable] public sealed class ArtChunkData {public string Name;public float[] Vertices,Normals,UV,Colors;public ArtSubmeshData[] Submeshes;}
    [Serializable] public sealed class ArtBundleData {public string Name;public ArtChunkData[] Chunks;}
}
