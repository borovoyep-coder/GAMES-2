using System.Collections.Generic;
using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    public sealed partial class WorldRenderer
    {
        readonly ValleyArtCatalog artCatalog;
        readonly List<GameObject> portalViews=new List<GameObject>();
        readonly List<GameObject> zoneViews=new List<GameObject>();
        readonly MaterialPropertyBlock bridgeProperties=new MaterialPropertyBlock();
        readonly MeshRenderer[][] bridgeRenderers=new MeshRenderer[2][];
        bool BuildDetailedArt(MapLayout map)
        {
            if(!artCatalog||!artCatalog.Environment)return false;
            Object.Instantiate(artCatalog.Environment,root,false).name="Долина осколков · окружение";
            var bridgePrefab=artCatalog.Find("Bridge");var crystalPrefab=artCatalog.Find("CrystalGate");
            if(!bridgePrefab||!crystalPrefab)throw new System.InvalidOperationException("Detailed art catalog has no bridge or crystal prefab. Rebuild art from Shattered World/Art.");
            for(int i=0;i<2;i++)
            {
                bridges[i]=Object.Instantiate(bridgePrefab,root,false);bridges[i].name=i==0?"Мост Рассвета":"Мост Сумерек";
                bridges[i].transform.localPosition=P(map.Bridges[i],-.45f);bridges[i].transform.localRotation=Quaternion.Euler(0,45,0);
                bridgeRenderers[i]=bridges[i].GetComponentsInChildren<MeshRenderer>(true);
            }
            for(int i=0;i<8;i++)
            {
                crystals[i]=Object.Instantiate(crystalPrefab,root,false);crystals[i].name="Разрушаемый кристалл "+(i+1);crystals[i].transform.localPosition=P(map.Crystals[i]);
            }
            return true;
        }
        GameObject CreateDetailedUnit(Unit unit)
        {
            if(!artCatalog)return null;var prefab=artCatalog.Find(artCatalog.ModelFor(unit));if(!prefab)return null;
            var go=Object.Instantiate(prefab,root,false);go.name=artCatalog.ModelFor(unit)+" #"+unit.Id;
            var idle=go.GetComponent<StylizedIdleMotion>();if(idle)idle.Phase=unit.Id*.713f;
            if(unit.Kind==Kind.Monster&&unit.Camp<12&&unit.Camp%6==1)go.transform.localScale=Vector3.one*(unit.Id%3==0?1.15f:.85f);
            if(unit.IsPlayer)
            {
                var marker=CreateStrategicRing("Управляемый герой",new Color(.95f,.85f,.5f));marker.transform.SetParent(go.transform,false);marker.transform.localPosition=Vector3.up*.24f;marker.transform.localScale=Vector3.one*1.6f;
            }
            return go;
        }
        float DetailedSurfaceHeight(MatchWorld world,V2 position)
        {
            for(int i=0;i<2;i++)if(world.Map.Bridges[i].Open&&world.Map.OnBridge(position,i))
            {
                var d=position-world.Layout.Bridges[i];float t=(d.X+d.Y)*.7071068f;
                return Mathf.Max(.15f,-.035f+.65f*Mathf.Cos(t*Mathf.PI/13));
            }
            if(world.Layout.OnLane(position))return .24f;
            foreach(var b in world.Layout.Bases)if(V2.Distance(position,b)<9)return .24f;
            foreach(var b in world.Layout.Bosses)if(V2.Distance(position,b)<12)return .24f;
            return .02f;
        }
        void PulseBridge(int index,bool warning)
        {
            float tint=warning?.65f+.35f*Mathf.Abs(Mathf.Sin(Time.time*5)):1;
            bridgeProperties.SetColor("_BaseColor",new Color(1,tint,tint,1));
            foreach(var renderer in bridgeRenderers[index])renderer.SetPropertyBlock(bridgeProperties);
        }
        GameObject CreateStrategicRing(string name,Color color)
        {
            var go=new GameObject(name);go.transform.SetParent(root,false);
            var line=go.AddComponent<LineRenderer>();line.sharedMaterial=Mat(color,true);line.useWorldSpace=false;line.loop=true;line.positionCount=64;line.startWidth=.08f;line.endWidth=.08f;
            for(int i=0;i<64;i++){float a=i*Mathf.PI*2/64;line.SetPosition(i,new Vector3(Mathf.Cos(a),.12f,Mathf.Sin(a)));}
            return go;
        }
        void SyncStrategicAreas(MatchWorld world)
        {
            int count=world.Objectives.Portals.Count*2;
            while(portalViews.Count<count)portalViews.Add(CreateStrategicRing("Врата Бездны",Purple));
            for(int i=0;i<portalViews.Count;i++)
            {
                bool active=i<count;var go=portalViews[i];go.SetActive(active);if(!active)continue;
                var portal=world.Objectives.Portals[i/2];go.transform.localPosition=P(i%2==0?portal.A:portal.B,.23f);go.transform.localScale=Vector3.one*2.3f;
                go.transform.localRotation=Quaternion.Euler(0,Time.time*20,0);
            }
            while(zoneViews.Count<world.Objectives.Zones.Count)zoneViews.Add(CreateStrategicRing("Зона разлома",new Color(.5f,.9f,.77f)));
            for(int i=0;i<zoneViews.Count;i++)
            {
                bool active=i<world.Objectives.Zones.Count;zoneViews[i].SetActive(active);if(!active)continue;
                var zone=world.Objectives.Zones[i];zoneViews[i].transform.localPosition=P(zone.Position,.22f);zoneViews[i].transform.localScale=Vector3.one*(zone.Vision?16:7);
            }
        }
    }
}
