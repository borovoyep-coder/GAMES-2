using System;
namespace ShatteredWorld.Simulation
{
    public sealed class CombatSystem
    {
        readonly MatchWorld w;
        public CombatSystem(MatchWorld world){w=world;}
        public bool CanTarget(Unit a,Unit b)
        {
            if(a==null||b==null||!a.Alive||!b.Alive||a.Id==b.Id||a.Team==b.Team)return false;
            if(a.Team==Team.Neutral)return b.IsHero;
            if(b.Team==Team.Neutral)return a.IsHero;
            if(!w.Visible(a.Team,b))return false;
            if(b.Kind==Kind.Tower)
                foreach(var t in w.Units)if(t.Alive&&t.Kind==Kind.Tower&&t.Team==b.Team&&t.Lane==b.Lane&&t.Tier<b.Tier)return false;
            if(b.Kind==Kind.Core)
            {
                for(int lane=0;lane<3;lane++)
                {
                    bool open=true;foreach(var t in w.Units)if(t.Alive&&t.Team==b.Team&&t.Kind==Kind.Tower&&t.Lane==lane){open=false;break;}
                    if(open)return true;
                }
                return false;
            }
            return true;
        }
        public bool Attack(Unit a,Unit b)
        {
            if(!CanTarget(a,b)||w.Clock.Time+1e-5<a.NextAttack||V2.Distance(a.Position,b.Position)>a.Range)return false;
            a.NextAttack=w.Clock.Time+a.AttackPeriod/Math.Max(.2f,a.Stat(Stat.AttackSpeed,w.Clock.Time));
            float damage=a.Stat(Stat.Damage,w.Clock.Time);
            if(b.IsStructure&&a.SiegeBlessing)damage*=1.1f;
            if(b.IsStructure&&a.Kind==Kind.Destroyer)damage*=1.7f;
            Hit(a,b,damage,a.Kind==Kind.Mage||a.Kind==Kind.Caster?DamageType.Magical:DamageType.Physical);
            if(a.IsHero&&b.Alive)
                foreach(var m in a.Modifiers)if(m.Definition.Id=="magma")
                {w.Modifiers.Apply(b,Buffs.Burn,a.Id,w.Clock.Time);w.Modifiers.Apply(b,Buffs.Slow,a.Id,w.Clock.Time);break;}
            return true;
        }
        public void Hit(Unit a,Unit b,float amount,DamageType type)
        {
            if(b==null||!b.Alive||amount<=0||w.Phase!=MatchPhase.Playing)return;
            // All damage, including abilities, respects tower/core progression.
            if(a!=null&&!CanTarget(a,b))return;
            if(type!=DamageType.True)amount*=100/(100+Math.Max(0,b.Stat(Stat.Armor,w.Clock.Time)));
            b.Health=Math.Max(0,b.Health-amount);b.LastCombat=(float)w.Clock.Time;
            if(a!=null)
            {
                a.LastCombat=(float)w.Clock.Time;
                if(a.IsHero&&a.Team!=b.Team){b.RecallUntil=0;w.Objectives.InterruptPortal(b.Id);}
                if(a.IsHero&&b.IsHero)
                    foreach(var t in w.Units)if(t.Alive&&t.Kind==Kind.Tower&&t.Team==b.Team&&V2.Distance(t.Position,a.Position)<=t.Range)t.Target=a.Id;
            }
            if(b.Alive)return;
            b.DeadAt=w.Clock.Time;b.HasDestination=false;b.Path.Clear();
            if(b.Kind==Kind.Core){w.Finish(a==null?(b.Team==Team.Blue?Team.Red:Team.Blue):a.Team);return;}
            if(b.IsHero)
            {
                b.RespawnAt=(float)w.Clock.Time+w.Rules.HeroRespawn+b.Level*1.5f;
                if(a!=null&&a.Team!=Team.Neutral)w.Kills[(int)a.Team]++;
            }
            if(b.Camp>=0){w.Objectives.OnDeath(a,b);return;}
            if(a!=null)
            {
                Unit recipient=a.IsHero?a:w.ClosestHero(a.Team,b.Position,16);
                if(recipient!=null){recipient.Gold+=b.IsHero?180:b.Kind==Kind.Tower?100:22;w.GainXp(recipient,b.IsHero?150:40);}
            }
        }
        public bool Ability(Unit a,int slot,V2 point)
        {
            if(a==null||!a.IsHero||!a.Alive||slot<0||slot>2||a.Mana<w.Rules.AbilityCost[slot]||w.Clock.Time+1e-5<a.Cooldowns[slot])return false;
            if(V2.Distance(a.Position,point)>15)return false;
            a.Mana-=w.Rules.AbilityCost[slot];a.Cooldowns[slot]=w.Clock.Time+w.Rules.AbilityCooldown[slot]*(1-Math.Min(.4f,a.Stat(Stat.CooldownReduction,w.Clock.Time)));
            if(slot==0&&a.Kind==Kind.Warrior)
            {
                V2 end=a.Position+(point-a.Position).Normalized*Math.Min(7,V2.Distance(a.Position,point));
                if(w.Navigation.SegmentClear(a.Position,end))a.Position=end;
                w.AddTelegraph(a,a.Position,3,125,.12f,false);return true;
            }
            float radius=slot==2?6:slot==1?4:1.8f;
            w.AddTelegraph(a,a.Kind==Kind.Warrior?a.Position:point,radius,slot==2?330:slot==1?155:125,slot==2?.85f:.45f,slot==1);
            return true;
        }
    }
}
