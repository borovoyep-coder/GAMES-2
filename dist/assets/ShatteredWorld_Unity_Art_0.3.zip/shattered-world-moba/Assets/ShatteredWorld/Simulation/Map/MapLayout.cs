using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    [Serializable]
    public struct MapBlock
    {
        public V2 Center, Size;
        public float Angle;
        public MapBlock(V2 c, V2 s, float angle=0) { Center=c; Size=s; Angle=angle; }
        public bool Contains(V2 p, float pad=0)
        {
            float radians=Angle*(float)Math.PI/180;
            var d=p-Center;
            float x=d.X*(float)Math.Cos(radians)+d.Y*(float)Math.Sin(radians);
            float y=-d.X*(float)Math.Sin(radians)+d.Y*(float)Math.Cos(radians);
            return Math.Abs(x)<Size.X/2+pad && Math.Abs(y)<Size.Y/2+pad;
        }
    }
    [Serializable]
    public sealed class LaneRoute
    {
        public V2[] Points;
        public int Length=>Points.Length;
        public V2 this[int index]=>Points[index];
        public LaneRoute(params V2[] points){Points=points;}
    }
    [Serializable]
    public sealed class MapLayout
    {
        public float HalfSize = 68;
        public V2[] Bases = {new V2(-48,-48), new V2(48,48)};
        public V2[] TreeObstacles = ForestLayout.Positions;
        public LaneRoute[] Lanes = {
            new LaneRoute(new V2(-48,-48),new V2(-48,48),new V2(48,48)),
            new LaneRoute(new V2(-48,-48),new V2(48,48)),
            new LaneRoute(new V2(-48,-48),new V2(48,-48),new V2(48,48))
        };
        public V2[] Bridges = {new V2(-20,20),new V2(20,-20)};
        public V2[] Crystals = {new V2(-34f,22f), new V2(-26f,-14f), new V2(14f,-36f), new V2(-16f,0f), new V2(34f,-22f), new V2(26f,14f), new V2(-14f,36f), new V2(16f,0f)};
        // Numbering: magma, wolves, ghosts, azure, centipedes, crab; red side is a 180-degree rotation.
        public V2[] Camps = {new V2(-36f,-20f), new V2(-36f,8f), new V2(-18f,-4f), new V2(-28f,-38f), new V2(4f,-36f), new V2(28f,-36f), new V2(36f,20f), new V2(36f,-8f), new V2(18f,4f), new V2(28f,38f), new V2(-4f,36f), new V2(-28f,36f)};
        public V2[] RiftCreatures = {new V2(-10,17),new V2(10,-17)};
        public V2[] Bosses = {new V2(-54,54),new V2(54,-54)};
        public LaneRoute[] BossEntrances = {new LaneRoute(new V2(-48,32),new V2(-32,48)),new LaneRoute(new V2(48,-32),new V2(32,-48))};
        public V2[] Bushes = {new V2(-41f,17f), new V2(-38f,-9f), new V2(-25f,-8f), new V2(-17f,-26f), new V2(8f,-28f), new V2(36f,-29f), new V2(-5f,-39f), new V2(41f,-17f), new V2(38f,9f), new V2(25f,8f), new V2(17f,26f), new V2(-8f,28f), new V2(-36f,29f), new V2(5f,39f)};
        public MapBlock[] Walls = {
            new MapBlock(new V2(-39f,-4f),new V2(1.6f,12f),0f),
            new MapBlock(new V2(-30f,1.5f),new V2(12f,1.6f),0f),
            new MapBlock(new V2(-23f,-6f),new V2(1.6f,9f),0f),
            new MapBlock(new V2(-32f,-15f),new V2(9f,1.6f),0f),
            new MapBlock(new V2(-40f,21f),new V2(1.6f,11f),0f),
            new MapBlock(new V2(-30f,29f),new V2(12f,1.6f),0f),
            new MapBlock(new V2(-27f,16f),new V2(1.6f,7f),0f),
            new MapBlock(new V2(-41f,-28f),new V2(1.6f,8f),0f),
            new MapBlock(new V2(-33f,-29f),new V2(10f,1.6f),0f),
            new MapBlock(new V2(-21f,-30f),new V2(1.6f,12f),0f),
            new MapBlock(new V2(-12f,-39f),new V2(10f,1.6f),0f),
            new MapBlock(new V2(-7f,-29f),new V2(8f,1.6f),0f),
            new MapBlock(new V2(6f,-26f),new V2(12f,1.6f),0f),
            new MapBlock(new V2(21f,-29f),new V2(1.6f,9f),0f),
            new MapBlock(new V2(34f,-33f),new V2(1.6f,11f),0f),
            new MapBlock(new V2(30f,-25f),new V2(8f,1.6f),0f),
            new MapBlock(new V2(-4f,-20f),new V2(1.5f,7f),0f),
            new MapBlock(new V2(-38.8f,22.0f),new V2(4.5f,1.35f),0f),
            new MapBlock(new V2(-29.2f,22.0f),new V2(4.5f,1.35f),0f),
            new MapBlock(new V2(-29.394f,-17.394f),new V2(4.5f,1.35f),45f),
            new MapBlock(new V2(-22.606f,-10.606f),new V2(4.5f,1.35f),45f),
            new MapBlock(new V2(14.0f,-40.8f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(14.0f,-31.2f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(-16.0f,-4.8f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(-16.0f,4.8f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(39f,4f),new V2(1.6f,12f),0f),
            new MapBlock(new V2(30f,-1.5f),new V2(12f,1.6f),0f),
            new MapBlock(new V2(23f,6f),new V2(1.6f,9f),0f),
            new MapBlock(new V2(32f,15f),new V2(9f,1.6f),0f),
            new MapBlock(new V2(40f,-21f),new V2(1.6f,11f),0f),
            new MapBlock(new V2(30f,-29f),new V2(12f,1.6f),0f),
            new MapBlock(new V2(27f,-16f),new V2(1.6f,7f),0f),
            new MapBlock(new V2(41f,28f),new V2(1.6f,8f),0f),
            new MapBlock(new V2(33f,29f),new V2(10f,1.6f),0f),
            new MapBlock(new V2(21f,30f),new V2(1.6f,12f),0f),
            new MapBlock(new V2(12f,39f),new V2(10f,1.6f),0f),
            new MapBlock(new V2(7f,29f),new V2(8f,1.6f),0f),
            new MapBlock(new V2(-6f,26f),new V2(12f,1.6f),0f),
            new MapBlock(new V2(-21f,29f),new V2(1.6f,9f),0f),
            new MapBlock(new V2(-34f,33f),new V2(1.6f,11f),0f),
            new MapBlock(new V2(-30f,25f),new V2(8f,1.6f),0f),
            new MapBlock(new V2(4f,20f),new V2(1.5f,7f),0f),
            new MapBlock(new V2(38.8f,-22.0f),new V2(4.5f,1.35f),0f),
            new MapBlock(new V2(29.2f,-22.0f),new V2(4.5f,1.35f),0f),
            new MapBlock(new V2(29.394f,17.394f),new V2(4.5f,1.35f),45f),
            new MapBlock(new V2(22.606f,10.606f),new V2(4.5f,1.35f),45f),
            new MapBlock(new V2(-14.0f,40.8f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(-14.0f,31.2f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(16.0f,4.8f),new V2(4.5f,1.35f),90f),
            new MapBlock(new V2(16.0f,-4.8f),new V2(4.5f,1.35f),90f)
        };
        public V2 LanePoint(int lane, float distance)
        {
            var p=Lanes[lane];
            for(int i=1;i<p.Length;i++) {float length=V2.Distance(p[i-1],p[i]); if(distance<=length)return p[i-1]+(p[i]-p[i-1]).Normalized*distance; distance-=length;}
            return p[p.Length-1];
        }
        public float LaneLength(int lane) {float d=0;var p=Lanes[lane];for(int i=1;i<p.Length;i++)d+=V2.Distance(p[i-1],p[i]);return d;}
        public float NearestLaneDistance(int lane,V2 point)
        {
            float best=float.MaxValue,result=0,travel=0;var route=Lanes[lane];
            for(int i=1;i<route.Length;i++)
            {
                var a=route[i-1];var delta=route[i]-a;float length=delta.Length;
                float projection=Math.Max(0,Math.Min(length,((point.X-a.X)*delta.X+(point.Y-a.Y)*delta.Y)/Math.Max(.001f,length)));
                float distance=V2.Distance(point,a+delta.Normalized*projection);
                if(distance<best){best=distance;result=travel+projection;}travel+=length;
            }
            return result;
        }
        public bool OnLane(V2 p,float width=4)
        {
            foreach(var lane in Lanes)for(int i=1;i<lane.Length;i++)if(V2.SegmentDistance(p,lane[i-1],lane[i])<=width)return true;
            return false;
        }
        public V2 TowerPosition(int team,int lane,int tier) => LanePoint(lane,team==0 ? 14+(2-tier)*15 : LaneLength(lane)-14-(2-tier)*15);
    }
}
