import bpy,os,math
from pathlib import Path
from mathutils import Vector,Matrix
root=Path(os.environ.get('VALLEY_PROJECT',str(Path(__file__).resolve().parents[1])));out=root/'docs/Art';out.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'SourceArt/ValleyOfShards.blend'));scene=bpy.context.scene;camera=scene.camera
scene.cycles.use_denoising=False;scene.cycles.samples=int(os.environ.get('VALLEY_SAMPLES','40'));scene.render.resolution_x=1600;scene.render.resolution_y=1600
bpy.ops.wm.save_as_mainfile(filepath=str(root/'SourceArt/ValleyOfShards.blend'),compress=True)
scene.render.filepath=str(out/'Valley_Overview.png');bpy.ops.render.render(write_still=True)
if os.environ.get('VALLEY_OVERVIEW_ONLY')!='1':
 camera.location=(-27,-48,52);target=Vector((-22,-4,0));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=58;scene.render.resolution_x=1600;scene.render.resolution_y=1100;scene.render.filepath=str(out/'Valley_Closeup.png');bpy.ops.render.render(write_still=True)
 bpy.data.collections['Environment'].hide_render=True;bpy.data.collections['PreviewUnits'].hide_render=True
 gallery=bpy.data.collections.new('Creature Gallery');scene.collection.children.link(gallery)
 names=['MagmaGuardian','AzureGolem','MoonWolf','StoneCentipede','RiftGhost','CrystalCrab','ObserverFirefly','RiftRay','SolarColossus','NightLeviathan']
 for i,name in enumerate(names):
  x=(i%5-2)*7.8;y=(i//5)*8;scale=.7 if i>=8 else 1
  for src in bpy.data.collections[name].objects:
   copy=src.copy();copy.data=src.data;copy.matrix_world=Matrix.Translation(Vector((x,y,0)))@Matrix.Scale(scale,4)@src.matrix_world;gallery.objects.link(copy)
  bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=3,depth=.3,location=(x,y,-.2));o=bpy.context.object;o.color=(.15,.18,.17,1);o.data.materials.append(bpy.data.materials['Stone'])
 camera.location=(0,-35,38);target=Vector((0,3.7,1));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=43;scene.render.resolution_x=1800;scene.render.resolution_y=1000;scene.render.filepath=str(out/'Creature_Collection.png');bpy.ops.render.render(write_still=True)
print('RENDERING COMPLETE',flush=True)
