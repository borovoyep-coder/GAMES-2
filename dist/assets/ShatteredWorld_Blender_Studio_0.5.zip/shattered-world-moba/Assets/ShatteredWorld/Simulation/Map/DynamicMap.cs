using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    public sealed class BridgeState {public bool Open, Warning;}
    public sealed class CrystalState {public int Durability=24;public double RestoreAt;public bool Broken=>Durability<=0;}
    public sealed class DynamicMap
    {
        public readonly MapLayout Layout;
        public readonly BridgeState[] Bridges={new BridgeState(),new BridgeState()};
        public readonly CrystalState[] Crystals=new CrystalState[8];
        public int Revision {get;private set;}
        readonly MatchRules rules;
        readonly Dictionary<long,List<V2>> forestGrid=new Dictionary<long,List<V2>>();
        struct RiverSegment {public V2 A,B;}
        readonly Dictionary<long,List<RiverSegment>> riverGrid=new Dictionary<long,List<RiverSegment>>();
        static long TreeKey(int x,int y)=>((long)x<<32)^(uint)y;
        public DynamicMap(MapLayout layout,MatchRules rules)
        {
            Layout=layout;this.rules=rules;for(int i=0;i<8;i++)Crystals[i]=new CrystalState();
            if(layout.TreeObstacles!=null)foreach(var tree in layout.TreeObstacles)
            {
                long key=TreeKey((int)Math.Floor(tree.X/4),(int)Math.Floor(tree.Y/4));
                if(!forestGrid.TryGetValue(key,out var group)){group=new List<V2>();forestGrid.Add(key,group);}group.Add(tree);
            }
            for(int i=1;i<layout.River.Length;i++)
            {
                var a=layout.River[i-1];var b=layout.River[i];float w=layout.RiverHalfWidth;
                for(int x=(int)Math.Floor((Math.Min(a.X,b.X)-w)/4);x<=(int)Math.Floor((Math.Max(a.X,b.X)+w)/4);x++)
                for(int y=(int)Math.Floor((Math.Min(a.Y,b.Y)-w)/4);y<=(int)Math.Floor((Math.Max(a.Y,b.Y)+w)/4);y++)
                {long key=TreeKey(x,y);if(!riverGrid.TryGetValue(key,out var list)){list=new List<RiverSegment>();riverGrid.Add(key,list);}list.Add(new RiverSegment{A=a,B=b});}
            }
        }
        bool RiverBlocked(V2 p)
        {
            if(riverGrid.TryGetValue(TreeKey((int)Math.Floor(p.X/4),(int)Math.Floor(p.Y/4)),out var list))
                foreach(var segment in list)if(V2.SegmentDistance(p,segment.A,segment.B)<=Layout.RiverHalfWidth)return true;
            return false;
        }
        bool TreeBlocked(V2 p)
        {
            int x=(int)Math.Floor(p.X/4),y=(int)Math.Floor(p.Y/4);
            for(int dx=-1;dx<=1;dx++)for(int dy=-1;dy<=1;dy++)
                if(forestGrid.TryGetValue(TreeKey(x+dx,y+dy),out var trees))foreach(var tree in trees)
                    if(V2.Distance(p,tree)<.7f)return true;
            return false;
        }
        public void Update(double time,IReadOnlyList<Unit> units,Action<string> emit)
        {
            int active=time+1e-5<rules.BridgeStart ? -1 : ((int)Math.Floor((time-rules.BridgeStart+1e-5)/rules.BridgePeriod))%2;
            for(int i=0;i<2;i++)
            {
                bool next=active==i;
                if(Bridges[i].Open!=next)
                {
                    if(!next)foreach(var u in units)if(u.Alive && (u.IsHero||u.IsMinion) && OnBridge(u.Position,i))
                    {
                        var c=Layout.Bridges[i];var direction=Layout.BridgeDirections[i].Normalized;var d=u.Position-c;
                        float sign=d.X*direction.X+d.Y*direction.Y>=0?1:-1;
                        var safe=c+direction*(7*sign);
                        if(!Walkable(safe))
                        {
                            float best=float.MaxValue;var across=new V2(-direction.Y,direction.X);
                            for(int n=7;n<=15;n++)for(int t=-5;t<=5;t++)
                            {
                                var candidate=c+direction*(n*sign)+across*t;
                                float distance=V2.Distance(candidate,u.Position);
                                if(distance<best&&Walkable(candidate)){best=distance;safe=candidate;}
                            }
                        }
                        u.Position=safe;u.Path.Clear();
                    }
                    Bridges[i].Open=next;Revision++;emit((i==0?"Мост Рассвета":"Мост Сумерек")+(next?" открыт":" закрыт"));
                }
                double phase=(time-rules.BridgeStart)%rules.BridgePeriod;
                bool warning=next && phase>=rules.BridgePeriod-rules.BridgeWarning;
                if(warning&&!Bridges[i].Warning)emit("Мост закроется через 15 секунд");
                Bridges[i].Warning=warning;
            }
            for(int i=0;i<8;i++)if(Crystals[i].Broken && time+1e-5>=Crystals[i].RestoreAt)
            {
                bool occupied=false;foreach(var u in units)if(u.Alive&&u.IsHero&&V2.Distance(u.Position,Layout.Crystals[i])<3){occupied=true;break;}
                if(!occupied){Crystals[i].Durability=24;Revision++;emit("Кристальный проход восстановлен");}
            }
        }
        public bool HitCrystal(int index,bool melee,bool basic,double time)
        {
            if(index<0||index>=8||!basic||Crystals[index].Broken)return false;
            var c=Crystals[index];c.Durability=Math.Max(0,c.Durability-(melee?4:3));
            if(c.Broken){c.RestoreAt=time+rules.CrystalRespawn;Revision++;}return true;
        }
        public bool OnBridge(V2 p,int i)
        {var d=p-Layout.Bridges[i];var axis=Layout.BridgeDirections[i];return Math.Abs(d.X*axis.X+d.Y*axis.Y)<=7&&Math.Abs(d.X*axis.Y-d.Y*axis.X)<=2.45f;}
        public bool Walkable(V2 p)
        {
            if(!Layout.OnSurface(p))return false;
            if(RiverBlocked(p))
            {
                if(Layout.OnLane(p,3.2f)||Layout.OnBypass(p,1.25f))return true;
                for(int i=0;i<2;i++)if(Bridges[i].Open&&OnBridge(p,i))return true;
                return false;
            }
            if(Layout.OnLane(p)||Layout.OnBypass(p))return true;
            for(int i=0;i<8;i++)if(!Crystals[i].Broken&&V2.Distance(p,Layout.Crystals[i])<2.4f)return false;
            if(TreeBlocked(p))return false;
            foreach(var w in Layout.Walls)if(w.Contains(p,.55f))return false;
            foreach(var w in Layout.BankWalls)if(w.Contains(p,.45f))return false;
            return true;
        }
    }
}
