using System;
namespace ShatteredWorld.Simulation
{
    [Serializable] public struct MapBlock
    {
        public V2 Center,Size;public float Angle;
        public MapBlock(V2 center,V2 size,float angle=0){Center=center;Size=size;Angle=angle;}
        public bool Contains(V2 p,float pad=0)
        {
            double a=Angle*Math.PI/180;var d=p-Center;
            return Math.Abs(d.X*Math.Cos(a)+d.Y*Math.Sin(a))<Size.X/2+pad&&Math.Abs(-d.X*Math.Sin(a)+d.Y*Math.Cos(a))<Size.Y/2+pad;
        }
    }
    [Serializable] public sealed class LaneRoute
    {
        public V2[] Points;public int Length=>Points.Length;public V2 this[int i]=>Points[i];
        public LaneRoute(params V2[] points){Points=points;}
    }
    [Serializable] public sealed class TowerSlot {public int Team,Lane,Tier;public V2 Position;}
    [Serializable] public sealed class MapLayout
    {
        public float HalfSize=80,BossRadius=16,RiverHalfWidth=2.65f;
        public V2[] Bases,Bridges,BridgeDirections,Crystals,Camps,RiftCreatures,Bosses,Bushes;
        public V2[] Fountains,CrystalDirections;
        public V2[] TreeObstacles=ForestLayout.Positions;
        public LaneRoute[] Lanes,BypassRoutes,JunglePaths,TowerPassages,BossEntrances,BushZones,TreeIslands;
        public LaneRoute[] CrystalShortcuts,RiverRailings;
        public LaneRoute River;
        public TowerSlot[] TowerSlots;
        public MapBlock[] Walls;
        public MapBlock[] BankWalls=Array.Empty<MapBlock>();
        public MapLayout(){ReferenceMapData.Apply(this);if(Fountains==null)Fountains=new[]{Bases[0]+new V2(-6.8f,-6.8f),Bases[1]+new V2(6.8f,6.8f)};}
        public static float RouteLength(LaneRoute route){float result=0;for(int i=1;i<route.Length;i++)result+=V2.Distance(route[i-1],route[i]);return result;}
        public static V2 RoutePoint(LaneRoute route,float distance)
        {
            for(int i=1;i<route.Length;i++){float length=V2.Distance(route[i-1],route[i]);if(distance<=length)return route[i-1]+(route[i]-route[i-1]).Normalized*Math.Max(0,distance);distance-=length;}
            return route[route.Length-1];
        }
        public float LaneLength(int lane)=>RouteLength(Lanes[lane]);
        public V2 LanePoint(int lane,float d)=>RoutePoint(Lanes[lane],d);
        public float NearestLaneDistance(int lane,V2 p)
        {
            float best=float.MaxValue,result=0,travel=0;var route=Lanes[lane];
            for(int i=1;i<route.Length;i++){var a=route[i-1];var d=route[i]-a;float length=d.Length;float t=Math.Max(0,Math.Min(length,((p.X-a.X)*d.X+(p.Y-a.Y)*d.Y)/Math.Max(.001f,length)));float dist=V2.Distance(p,a+d.Normalized*t);if(dist<best){best=dist;result=travel+t;}travel+=length;}return result;
        }
        public static bool NearRoute(V2 p,LaneRoute route,float width)
        {if(route==null||route.Points==null)return false;for(int i=1;i<route.Length;i++)if(V2.SegmentDistance(p,route[i-1],route[i])<=width)return true;return false;}
        public static bool NearRoutes(V2 p,LaneRoute[] routes,float width)
        {if(routes==null)return false;foreach(var route in routes)if(NearRoute(p,route,width))return true;return false;}
        public bool OnLane(V2 p,float width=4)=>NearRoutes(p,Lanes,width);
        public bool OnBypass(V2 p,float width=1.65f)=>NearRoutes(p,BypassRoutes,width);
        public bool OnJunglePath(V2 p,float width=1.6f)=>NearRoutes(p,JunglePaths,width);
        public bool InRiver(V2 p)=>NearRoute(p,River,RiverHalfWidth);
        public bool OnSurface(V2 p)
        {
            if(Math.Abs(p.X)>HalfSize||Math.Abs(p.Y)>HalfSize)return false;
            if(Math.Abs(p.X)<=62&&Math.Abs(p.Y)<=62)return true;
            foreach(var boss in Bosses)if(V2.Distance(p,boss)<BossRadius)return true;
            return false;
        }
        public static bool Inside(V2 p,LaneRoute polygon)
        {
            bool inside=false;var points=polygon.Points;
            for(int i=0,j=points.Length-1;i<points.Length;j=i++)
            {var a=points[i];var b=points[j];if((a.Y>p.Y)!=(b.Y>p.Y)&&p.X<(b.X-a.X)*(p.Y-a.Y)/(b.Y-a.Y)+a.X)inside=!inside;}
            return inside;
        }
        public bool IsInBush(V2 p)
        {if(BushZones!=null)foreach(var zone in BushZones)if(Inside(p,zone))return true;return false;}
        public V2 TowerPosition(int team,int lane,int tier)
        {foreach(var slot in TowerSlots)if(slot.Team==team&&slot.Lane==lane&&slot.Tier==tier)return slot.Position;throw new InvalidOperationException("Missing photo-traced tower marker");}
    }
}
