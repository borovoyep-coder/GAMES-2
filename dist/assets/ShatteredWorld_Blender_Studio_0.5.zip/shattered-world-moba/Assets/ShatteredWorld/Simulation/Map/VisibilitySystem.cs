using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    /// <summary>Enemy vision history advances with simulation time, independently of render queries.</summary>
    public sealed class VisibilitySystem
    {
        sealed class Memory
        {
            public bool InBush;
            public readonly double[] LastSeen={-10000,-10000},RevealUntil={-10000,-10000};
        }
        readonly MatchWorld world;
        readonly Dictionary<int,Memory> heroes=new Dictionary<int,Memory>();
        public VisibilitySystem(MatchWorld world){this.world=world;}
        public void Forget(Unit unit){heroes.Remove(unit.Id);}
        public bool DirectSight(Team team,Unit target,bool bush)
        {
            float radius=bush?world.Rules.BushDetectionRadius:world.Rules.VisionRadius;
            foreach(var source in world.Units)
                if(source.Alive&&source.Team==team&&(source.IsHero||source.IsMinion||source.IsStructure)&&V2.Distance(source.Position,target.Position)<radius)return true;
            foreach(var zone in world.Objectives.Zones)
                if(zone.Vision&&zone.Team==team&&zone.Until>world.Clock.Time&&V2.Distance(zone.Position,target.Position)<world.Rules.VisionRadius)return true;
            return false;
        }
        public void Update()
        {
            double now=world.Clock.Time;
            foreach(var target in world.Units)
            {
                if(!target.IsHero||!target.Alive)continue;
                if(!heroes.TryGetValue(target.Id,out var memory)){memory=new Memory();heroes.Add(target.Id,memory);}
                bool bush=world.Layout.IsInBush(target.Position);
                for(int team=0;team<2;team++)
                {
                    if((int)target.Team==team)continue;
                    if(bush&&!memory.InBush)
                        memory.RevealUntil[team]=now-memory.LastSeen[team]<=world.Rules.BushVisionHistory+1e-5?now+world.Rules.BushEntryReveal:now;
                    if(DirectSight((Team)team,target,bush)||bush&&now+1e-5<memory.RevealUntil[team])memory.LastSeen[team]=now;
                }
                memory.InBush=bush;
            }
        }
        public bool Visible(Team observer,Unit target)
        {
            if(observer==Team.Neutral||target.Team==observer||target.IsStructure)return true;
            bool bush=world.Layout.IsInBush(target.Position);
            if(DirectSight(observer,target,bush))return true;
            return bush&&target.IsHero&&heroes.TryGetValue(target.Id,out var memory)&&world.Clock.Time+1e-5<memory.RevealUntil[(int)observer];
        }
    }
}
