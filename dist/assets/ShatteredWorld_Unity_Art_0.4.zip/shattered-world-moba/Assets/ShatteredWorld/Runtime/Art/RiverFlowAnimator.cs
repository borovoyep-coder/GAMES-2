using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    /// <summary>Moves a Blender-authored foam mesh along the same river route as gameplay.</summary>
    public sealed class RiverFlowAnimator:MonoBehaviour
    {
        public GameObject FoamPrefab;
        public V2[] Points;
        public int Count=42;
        public float Speed=1.6f,WaterHeight=-.34f;
        Transform[] instances;
        LaneRoute route;
        float length;
        public void Configure(GameObject foam,V2[] points){FoamPrefab=foam;Points=points;Initialize();}
        void Start(){if(instances==null)Initialize();}
        void Initialize()
        {
            if(!FoamPrefab||Points==null||Points.Length<2||instances!=null)return;
            route=new LaneRoute(Points);length=MapLayout.RouteLength(route);instances=new Transform[Count];
            for(int i=0;i<Count;i++)
            {
                var go=Instantiate(FoamPrefab,transform,false);go.name="Blender river foam "+i;instances[i]=go.transform;
            }
        }
        void Update()
        {
            if(instances==null||length<=0)return;
            for(int i=0;i<instances.Length;i++)
            {
                float distance=(Time.time*Speed+i*length/instances.Length)%length;
                var p=MapLayout.RoutePoint(route,distance);var q=MapLayout.RoutePoint(route,Mathf.Min(length,distance+.3f));var d=(q-p).Normalized;
                var side=new V2(-d.Y,d.X)*(Mathf.Sin(i*2.1f)*.8f);var target=p+side;
                instances[i].localPosition=WorldRenderer.P(target,WaterHeight);
                instances[i].localRotation=Quaternion.Euler(0,Mathf.Atan2(d.X,d.Y)*Mathf.Rad2Deg,0);
            }
        }
    }
}
