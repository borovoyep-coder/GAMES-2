using System;
using UnityEngine;
using UnityEngine.InputSystem;
using ShatteredWorld.Simulation;
namespace ShatteredWorld.Unity
{
    public sealed partial class GameApp:MonoBehaviour
    {
        public MatchConfig Configuration;
        public MatchWorld World{get;private set;}
        WorldRenderer worldRenderer;Camera viewCamera;
        bool menu=true,settings,paused,training,dev,shop,mage,overview;
        float accumulator,simulationSpeed=1,zoom=30;V2 aim,joystick;
        Vector2 stickOrigin;bool draggingStick;
        static readonly Plane Ground=new Plane(Vector3.up,Vector3.zero);
        void Awake()
        {
            Application.targetFrameRate=60;
            Screen.orientation=ScreenOrientation.LandscapeLeft;
            viewCamera=Camera.main;
            if(!viewCamera){var cameraObject=new GameObject("Main Camera");viewCamera=cameraObject.AddComponent<Camera>();cameraObject.tag="MainCamera";cameraObject.AddComponent<AudioListener>();}
            viewCamera.orthographic=true;viewCamera.nearClipPlane=.1f;viewCamera.farClipPlane=400;
            viewCamera.backgroundColor=new Color(.025f,.06f,.08f);
            BuildWorld();
        }
        void BuildWorld()
        {
            if(worldRenderer!=null)worldRenderer.Dispose();
            // Copy serialized definitions: a new match never mutates the asset.
            MatchRules rules=Configuration?JsonUtility.FromJson<MatchRules>(JsonUtility.ToJson(Configuration.Rules)):new MatchRules();
            MapLayout layout=Configuration?JsonUtility.FromJson<MapLayout>(JsonUtility.ToJson(Configuration.Layout)):new MapLayout();
            World=new MatchWorld(rules,layout);
            if(mage){var u=World.Player;u.Kind=Kind.Mage;u.BaseHealth=rules.MageHealth;u.Health=u.BaseHealth;u.Damage=rules.MageDamage;u.Range=9;}
            var root=new GameObject("Valley of Shards · runtime");worldRenderer=new WorldRenderer(root.transform);worldRenderer.Build(World.Layout);worldRenderer.Sync(World);
            accumulator=0;simulationSpeed=1;paused=false;shop=false;dev=false;draggingStick=false;joystick=new V2();aim=World.Player.Position;
            UpdateCamera(true);
        }
        void StartMatch(bool isTraining){training=isTraining;menu=false;settings=false;BuildWorld();}
        void Send(CommandType type,V2 point=default,int target=0,int slot=0)
        {World.Enqueue(new GameCommand{Actor=World.PlayerId,Type=type,Point=point,Target=target,Slot=slot});}
        void Update()
        {
            if(World==null)return;
            if(menu){UpdateCamera(false);return;}
            ReadInput();
            if(!paused&&World.Phase==MatchPhase.Playing)
            {
                accumulator+=Mathf.Min(Time.unscaledDeltaTime,.2f)*simulationSpeed;
                int steps=0;while(accumulator>=GameClock.Step&&steps++<80){World.Step();accumulator-=GameClock.Step;}
            }
            worldRenderer.Sync(World);UpdateCamera(false);
        }
        void UpdateCamera(bool snap)
        {
            Vector3 focus=menu?Vector3.zero:WorldRenderer.P(World.Player.Position);
            if(overview)focus=Vector3.zero;
            float limit=World.Layout.HalfSize-8;focus.x=Mathf.Clamp(focus.x,-limit,limit);focus.z=Mathf.Clamp(focus.z,-limit,limit);
            var position=focus+new Vector3(0,65,-42);
            viewCamera.transform.position=snap?position:Vector3.Lerp(viewCamera.transform.position,position,1-Mathf.Exp(-Time.unscaledDeltaTime*7));
            viewCamera.transform.rotation=Quaternion.Euler(57,0,0);
            viewCamera.orthographicSize=menu||overview?(worldRenderer!=null&&worldRenderer.UsesDetailedArt?Mathf.Max(64,78/viewCamera.aspect):83):zoom;
        }
        bool InHud(Vector2 point)
        {
            float x=point.x*1600/Screen.width,y=(Screen.height-point.y)*900/Screen.height;
            return y<85||y>680||x<255&&y>420||shop||dev&&x>1160;
        }
        V2 WorldPoint(Vector2 point)
        {
            Ray ray=viewCamera.ScreenPointToRay(point);return Ground.Raycast(ray,out float distance)?new V2(ray.GetPoint(distance).x,ray.GetPoint(distance).z):World.Player.Position;
        }
        void ReadInput()
        {
            var keyboard=Keyboard.current;var mouse=Mouse.current;
            if(keyboard!=null)
            {
                if(keyboard.escapeKey.wasPressedThisFrame)paused=!paused;
                if(keyboard.tabKey.wasPressedThisFrame)overview=!overview;
                if(keyboard.f1Key.wasPressedThisFrame&&training)dev=!dev;
                if(keyboard.iKey.wasPressedThisFrame)shop=!shop;
            }
            if(paused||World.Phase!=MatchPhase.Playing)return;
            if(mouse!=null)
            {
                var point=mouse.position.ReadValue();aim=WorldPoint(point);
                if(!InHud(point)&&mouse.rightButton.wasPressedThisFrame)Send(CommandType.Move,aim);
                if(!InHud(point)&&mouse.leftButton.wasPressedThisFrame)
                {
                    Unit best=null;float range=3;
                    foreach(var u in World.Units)if(World.Combat.CanTarget(World.Player,u)){float d=V2.Distance(u.Position,aim);if(d<range){best=u;range=d;}}
                    if(best!=null){Send(CommandType.Attack,target:best.Id);}
                    else Send(CommandType.Move,aim);
                }
                zoom=Mathf.Clamp(zoom-mouse.scroll.ReadValue().y*.02f,18,55);
            }
            V2 direction=joystick;
            if(keyboard!=null)
            {
                direction+=new V2((keyboard.dKey.isPressed?1:0)-(keyboard.aKey.isPressed?1:0),(keyboard.wKey.isPressed?1:0)-(keyboard.sKey.isPressed?1:0));
                if(keyboard.spaceKey.isPressed)Send(CommandType.Attack);
                if(keyboard.qKey.wasPressedThisFrame)Send(CommandType.Ability,AimPoint(),slot:0);
                if(keyboard.eKey.wasPressedThisFrame)Send(CommandType.Ability,AimPoint(),slot:1);
                if(keyboard.rKey.wasPressedThisFrame)Send(CommandType.Ability,AimPoint(),slot:2);
                if(keyboard.bKey.wasPressedThisFrame)Send(CommandType.Recall);
                if(keyboard.fKey.wasPressedThisFrame)World.Objectives.UsePortal(World.Player);
            }
            if(direction.Length>.15f)
            {
                var p=World.Player.Position+direction.Normalized*2;
                if(World.Map.Walkable(p))Send(CommandType.Move,p);
            }
            ReadTouch();
        }
        V2 AimPoint()
        {
            if(Touchscreen.current!=null&&Touchscreen.current.primaryTouch.press.isPressed)
            {var target=World.FindTarget(World.Player,14,false);return target!=null?target.Position:World.Player.Position+new V2(5,5);}
            var delta=aim-World.Player.Position;return World.Player.Position+delta.Normalized*Mathf.Min(14,delta.Length);
        }
        void ReadTouch()
        {
            var touch=Touchscreen.current;if(touch==null)return;
            // Stable touch identity keeps the joystick working while another finger attacks.
            bool found=false;
            foreach(var finger in touch.touches)
            {
                if(!finger.press.isPressed)continue;
                var p=finger.position.ReadValue();var scaled=new Vector2(p.x*1600/Screen.width,(Screen.height-p.y)*900/Screen.height);
                if(scaled.x>320||scaled.y<650)continue;
                found=true;
                if(!draggingStick){draggingStick=true;stickOrigin=scaled;}
                var delta=scaled-stickOrigin;joystick=new V2(delta.x,-delta.y)/65;
                if(joystick.Length>1)joystick=joystick.Normalized;break;
            }
            if(!found){joystick=new V2();draggingStick=false;}
        }
        void OnDestroy(){if(worldRenderer!=null)worldRenderer.Dispose();}
    }
}
