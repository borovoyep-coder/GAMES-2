using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    public sealed class GridNavigation
    {
        const int N=81; const float Cell=2, Offset=80;
        readonly DynamicMap map;
        readonly float[] cost=new float[N*N]; readonly int[] parent=new int[N*N]; readonly bool[] closed=new bool[N*N];
        readonly List<int> open=new List<int>(512);
        public GridNavigation(DynamicMap map){this.map=map;}
        int Index(V2 p) => Math.Max(0,Math.Min(N-1,(int)Math.Round((p.X+Offset)/Cell)))+N*Math.Max(0,Math.Min(N-1,(int)Math.Round((p.Y+Offset)/Cell)));
        V2 Point(int index)=>new V2((index%N)*Cell-Offset,(index/N)*Cell-Offset);
        int Nearest(V2 p)
        {
            int start=Index(p);if(map.Walkable(Point(start)))return start;
            float best=float.MaxValue;int result=-1;
            for(int i=0;i<N*N;i++)if(map.Walkable(Point(i))){float d=V2.Distance(Point(i),p);if(d<best){best=d;result=i;}}
            return result;
        }
        public bool SegmentClear(V2 a,V2 b)
        {
            int count=(int)Math.Ceiling(V2.Distance(a,b)/.5f);
            for(int i=1;i<=count;i++)if(!map.Walkable(a+(b-a)*((float)i/count)))return false;
            return true;
        }
        public bool Find(V2 from,V2 to,List<V2> path)
        {
            path.Clear();int start=Nearest(from),end=Nearest(to);if(start<0||end<0)return false;
            if(SegmentClear(from,to)){path.Add(to);return true;}
            for(int i=0;i<cost.Length;i++){cost[i]=float.MaxValue;closed[i]=false;parent[i]=-1;}
            open.Clear();open.Add(start);cost[start]=0;
            while(open.Count>0)
            {
                int best=0;float value=float.MaxValue;
                for(int i=0;i<open.Count;i++){int id=open[i];float f=cost[id]+V2.Distance(Point(id),Point(end));if(f<value){value=f;best=i;}}
                int current=open[best];open.RemoveAt(best);if(closed[current])continue;closed[current]=true;
                if(current==end){for(int id=end;id!=start;id=parent[id])path.Add(Point(id));path.Reverse();if(map.Walkable(to)&&SegmentClear(Point(end),to))path.Add(to);return true;}
                int x=current%N,y=current/N;
                for(int dx=-1;dx<=1;dx++)for(int dy=-1;dy<=1;dy++)
                {
                    if((dx==0&&dy==0)||x+dx<0||x+dx>=N||y+dy<0||y+dy>=N)continue;
                    int next=x+dx+N*(y+dy);if(closed[next]||!map.Walkable(Point(next)))continue;
                    if(!SegmentClear(Point(current),Point(next)))continue;
                    float candidate=cost[current]+(dx!=0&&dy!=0?2.828427f:2);
                    if(candidate>=cost[next])continue;cost[next]=candidate;parent[next]=current;open.Add(next);
                }
            }
            return false;
        }
    }
}
