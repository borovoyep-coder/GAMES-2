using System;
using System.Collections.Generic;
namespace ShatteredWorld.Simulation
{
    public sealed class Telegraph
    {
        public int Source;public Team Team;public V2 Point;public float Radius,Damage;public double ResolveAt;public bool Slow;
    }
    public sealed class MatchWorld
    {
        public readonly MatchRules Rules;public readonly MapLayout Layout;public readonly GameClock Clock=new GameClock();
        public readonly DynamicMap Map;public readonly GridNavigation Navigation;public readonly CombatSystem Combat;public readonly BotSystem Bots;
        public readonly WaveSystem Waves;public readonly ObjectiveSystem Objectives;public readonly ModifierSystem Modifiers=new ModifierSystem();
        public readonly List<Unit> Units=new List<Unit>();public readonly List<Telegraph> Telegraphs=new List<Telegraph>();
        public readonly List<GameEvent> Events=new List<GameEvent>();public readonly int[] Kills=new int[2];
        public MatchPhase Phase{get;private set;}public Team Winner{get;private set;}=Team.Neutral;public int PlayerId{get;private set;}
        readonly Dictionary<int,Unit> byId=new Dictionary<int,Unit>();
        readonly Queue<GameCommand> commands=new Queue<GameCommand>();int nextId=1;
        public MatchWorld(MatchRules rules=null,MapLayout layout=null)
        {
            Rules=rules??new MatchRules();Layout=layout??new MapLayout();Map=new DynamicMap(Layout,Rules);Navigation=new GridNavigation(Map);
            Combat=new CombatSystem(this);Bots=new BotSystem(this);Waves=new WaveSystem(this);Objectives=new ObjectiveSystem(this);
            for(int t=0;t<2;t++)
            {
                Spawn(Kind.Core,(Team)t,Layout.Bases[t]);
                for(int lane=0;lane<3;lane++)for(int tier=0;tier<3;tier++){var tower=Spawn(Kind.Tower,(Team)t,Layout.TowerPosition(t,lane,tier));tower.Lane=lane;tower.Tier=tier;}
                for(int i=0;i<5;i++)
                {
                    var hero=Spawn(i%2==0?Kind.Warrior:Kind.Mage,(Team)t,Layout.Bases[t]+new V2(t==0?i:-i,0));
                    hero.Lane=i==4?3:i%3;hero.IsPlayer=t==0&&i==0;if(hero.IsPlayer)PlayerId=hero.Id;
                }
            }
            Emit("Долина осколков · Оба моста закрыты до 2:00");
        }
        public Unit Player=>Get(PlayerId);
        public Unit Get(int id)=>byId.TryGetValue(id,out var unit)?unit:null;
        public Unit Spawn(Kind kind,Team team,V2 point)
        {
            var u=new Unit{Id=nextId++,Kind=kind,Team=team,Position=point,Spawn=point,Speed=Rules.HeroSpeed,Damage=Rules.HeroDamage,Range=2.8f,BaseHealth=Rules.HeroHealth};
            if(kind==Kind.Mage){u.BaseHealth=Rules.MageHealth;u.Damage=Rules.MageDamage;u.Range=9;}
            if(u.IsMinion){u.BaseHealth=Rules.MinionHealth;u.Damage=Rules.MinionDamage;u.Speed=4.2f;u.Range=kind==Kind.Guard?2.2f:7;u.Gold=0;u.Armor=8;if(kind==Kind.Destroyer)u.BaseHealth*=1.8f;}
            if(u.IsStructure){u.BaseHealth=kind==Kind.Core?Rules.CoreHealth:Rules.TowerHealth;u.Damage=Rules.TowerDamage;u.Range=11;u.Speed=0;u.Armor=30;}
            u.Health=u.BaseHealth;Units.Add(u);byId.Add(u.Id,u);return u;
        }
        public void Enqueue(GameCommand command){commands.Enqueue(command);}
        public bool Execute(GameCommand c)
        {
            if(Phase!=MatchPhase.Playing)return false;var u=Get(c.Actor);if(u==null||!u.Alive||!u.IsHero)return false;
            if(c.Type==CommandType.Move){if(!Map.Walkable(c.Point))return false;u.RecallUntil=0;u.Target=0;Bots.SetDestination(u,c.Point);return true;}
            if(c.Type==CommandType.Stop){u.HasDestination=false;u.Path.Clear();u.Target=0;return true;}
            if(c.Type==CommandType.Ability)return Combat.Ability(u,c.Slot,c.Point);
            if(c.Type==CommandType.Recall){u.RecallUntil=(float)Clock.Time+5;u.HasDestination=false;u.Path.Clear();return true;}
            if(c.Type==CommandType.Buy)
            {
                int slot=c.Slot;if(slot<0||slot>2||V2.Distance(u.Position,Layout.Bases[(int)u.Team])>9||u.Gold<200||u.Items[slot]>=3)return false;
                u.Gold-=200;u.Items[slot]++;
                if(slot==0)u.Damage+=20;
                if(slot==1){u.BaseHealth+=200;u.Health+=200;}
                if(slot==2)Modifiers.Apply(u,new ModifierDefinition{Id="item-mana",Name="Кристалл потока",Stat=Stat.ManaRegen,Flat=3*u.Items[slot],Duration=100000,RemoveOnDeath=false,Stacking=StackRule.Replace},u.Id,Clock.Time);
                return true;
            }
            if(c.Type==CommandType.Attack)
            {
                u.RecallUntil=0;var enemy=Get(c.Target)??FindTarget(u,u.Range,false);
                if(enemy!=null){u.Target=enemy.Id;return Combat.Attack(u,enemy);}
                for(int i=0;i<8;i++)if(V2.Distance(u.Position,Layout.Crystals[i])<=u.Range&&!Map.Crystals[i].Broken&&Clock.Time>=u.NextAttack)
                {u.NextAttack=Clock.Time+u.AttackPeriod;return Map.HitCrystal(i,u.Kind==Kind.Warrior,true,Clock.Time);}
            }
            return false;
        }
        public void Step()
        {
            if(Phase!=MatchPhase.Playing)return;Clock.Advance();
            Map.Update(Clock.Time,Units,Emit);
            while(commands.Count>0)Execute(commands.Dequeue());
            Waves.Update();Objectives.Update();
            for(int i=Telegraphs.Count-1;i>=0;i--)
            {
                var t=Telegraphs[i];if(Clock.Time<t.ResolveAt)continue;
                var source=Get(t.Source);
                if(source!=null&&source.Alive)
                    for(int j=0;j<Units.Count;j++)
                    {
                        var target=Units[j];if(target.Alive&&Combat.CanTarget(source,target)&&V2.Distance(target.Position,t.Point)<=t.Radius)
                        {Combat.Hit(source,target,t.Damage,DamageType.Magical);if(t.Slow&&target.Alive)Modifiers.Apply(target,Buffs.Slow,source.Id,Clock.Time);}
                    }
                Telegraphs.RemoveAt(i);
            }
            for(int i=0;i<Units.Count;i++)
            {
                var u=Units[i];Modifiers.Update(this,u);
                if(!u.Alive)
                {
                    if(u.IsHero&&Clock.Time>=u.RespawnAt){u.Health=u.Stat(Stat.Health,Clock.Time);u.Mana=u.MaxMana;u.Position=u.Spawn;u.Target=0;u.Modifiers.RemoveAll(m=>m.Definition.RemoveOnDeath);}
                    continue;
                }
                if(u.IsHero)
                {
                    u.Gold+=Rules.PassiveGold*GameClock.Step;u.Mana=Math.Min(u.MaxMana,u.Mana+u.Stat(Stat.ManaRegen,Clock.Time)*GameClock.Step);
                    if(V2.Distance(u.Position,Layout.Bases[(int)u.Team])<9)u.Health=Math.Min(u.Stat(Stat.Health,Clock.Time),u.Health+u.BaseHealth*.18f*GameClock.Step);
                    if(u.RecallUntil>0&&Clock.Time>=u.RecallUntil){u.Position=Layout.Bases[(int)u.Team];u.RecallUntil=0;u.HasDestination=false;u.Path.Clear();}
                    if(u.IsPlayer)FollowPath(u);
                }
                Bots.Update(u);
                if(Phase==MatchPhase.Finished)break;
            }
            for(int i=Units.Count-1;i>=0;i--)if(!Units[i].Alive&&!Units[i].IsHero&&!Units[i].IsStructure&&Clock.Time-Units[i].DeadAt>2)
            {byId.Remove(Units[i].Id);Units.RemoveAt(i);}
        }
        public void MoveDirect(Unit u,V2 point)
        {
            var delta=point-u.Position;float amount=Math.Min(delta.Length,u.Stat(Stat.Speed,Clock.Time)*GameClock.Step);
            var next=u.Position+delta.Normalized*amount;if(Navigation.SegmentClear(u.Position,next))u.Position=next;
        }
        public void FollowPath(Unit u)
        {
            if(!u.HasDestination)return;
            if(u.PathRevision!=Map.Revision||Clock.Time>=u.RepathAt)
            {Navigation.Find(u.Position,u.Destination,u.Path);u.PathIndex=0;u.PathRevision=Map.Revision;u.RepathAt=Clock.Time+1;}
            if(u.PathIndex>=u.Path.Count)return;
            var p=u.Path[u.PathIndex];MoveDirect(u,p);
            if(V2.Distance(u.Position,p)<.3f){u.PathIndex++;if(u.PathIndex>=u.Path.Count&&V2.Distance(u.Position,u.Destination)<1)u.HasDestination=false;}
        }
        public Unit FindTarget(Unit actor,float range,bool preferMinions)
        {
            Unit best=null;float score=float.MaxValue;
            foreach(var u in Units)
            {
                float d=V2.Distance(actor.Position,u.Position);if(d>range||!Combat.CanTarget(actor,u))continue;
                if(u.Team==Team.Neutral&&(actor.IsMinion||actor.IsStructure||actor.Lane!=3))continue;
                float candidate=d+(preferMinions&&!u.IsMinion?20:0);if(candidate<score){score=candidate;best=u;}
            }
            return best;
        }
        public Unit ClosestHero(Team team,V2 point,float range)
        {Unit best=null;foreach(var u in Units)if(u.IsHero&&u.Alive&&u.Team==team){float d=V2.Distance(point,u.Position);if(d<range){range=d;best=u;}}return best;}
        public Unit NextStructure(Team attacker,int lane)
        {
            Unit best=null;
            foreach(var u in Units)if(u.Alive&&u.Team!=attacker&&u.Kind==Kind.Tower&&u.Lane==lane&&(best==null||u.Tier<best.Tier))best=u;
            if(best!=null)return best;foreach(var u in Units)if(u.Kind==Kind.Core&&u.Team!=attacker)return u;return null;
        }
        public bool Visible(Team observer,Unit target)
        {
            if(observer==Team.Neutral||target.Team==observer||target.IsStructure)return true;
            bool bush=Layout.IsInBush(target.Position);
            foreach(var u in Units)if(u.Alive&&u.Team==observer&&(u.IsHero||u.IsMinion||u.IsStructure)&&V2.Distance(u.Position,target.Position)<(bush?3:16))return true;
            if(!bush)foreach(var z in Objectives.Zones)if(z.Vision&&z.Team==observer&&z.Until>Clock.Time&&V2.Distance(z.Position,target.Position)<16)return true;
            return false;
        }
        public void AddTelegraph(Unit a,V2 point,float radius,float damage,float delay,bool slow)
        {Telegraphs.Add(new Telegraph{Source=a.Id,Team=a.Team,Point=point,Radius=radius,Damage=damage,ResolveAt=Clock.Time+delay,Slow=slow});}
        public void GainXp(Unit u,int amount)
        {
            u.Xp+=amount;
            while(u.Level<18&&u.Xp>=Rules.LevelXp*u.Level){u.Xp-=(int)(Rules.LevelXp*u.Level);u.Level++;u.BaseHealth+=80;u.Health=Math.Min(u.BaseHealth,u.Health+80);u.Damage+=6;}
        }
        public void Emit(string message){Events.Add(new GameEvent(Clock.Time,message));if(Events.Count>40)Events.RemoveAt(0);}
        public void Finish(Team winner){if(Phase==MatchPhase.Finished)return;Winner=winner;Phase=MatchPhase.Finished;commands.Clear();}
        public WorldSnapshot Snapshot(Team observer)
        {
            var units=new List<UnitSnapshot>();foreach(var u in Units)if(u.Alive&&Visible(observer,u))units.Add(new UnitSnapshot{Id=u.Id,Position=u.Position,Team=u.Team,Kind=u.Kind,Health=u.Health,MaxHealth=u.Stat(Stat.Health,Clock.Time),Level=u.Level});
            return new WorldSnapshot{Tick=Clock.Tick,Time=Clock.Time,Phase=Phase,NavigationRevision=Map.Revision,Units=units.ToArray()};
        }
    }
}
