using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using ShatteredWorld.Unity;
using ShatteredWorld.Simulation;
namespace ShatteredWorld.Tests
{
    public sealed class RuntimeTests
    {
        [UnityTest]
        public IEnumerator PrototypeBootsWithTenHeroesAndCamera()
        {
            var go=new GameObject("Test application");var app=go.AddComponent<GameApp>();yield return null;
            Assert.NotNull(app.World);Assert.NotNull(Camera.main);
            int heroes=0;foreach(var u in app.World.Units)if(u.IsHero)heroes++;
            Assert.AreEqual(10,heroes);Object.Destroy(go);yield return null;
        }
        [UnityTest]
        public IEnumerator DynamicMapUpdatesPresentationWithoutPhysics()
        {
            var root=new GameObject("Test world");var renderer=new WorldRenderer(root.transform);var world=new MatchWorld();
            renderer.Build(world.Layout);renderer.Sync(world);world.Map.Update(120,world.Units,_=>{});renderer.Sync(world);
            Assert.IsTrue(world.Map.Bridges[0].Open);Assert.Greater(root.transform.childCount,100);renderer.Dispose();yield return null;
        }
    }
}
