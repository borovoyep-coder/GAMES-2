using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    public sealed class BridgeState {public bool Open, Warning;}
    public sealed class CrystalState {public int Durability=24;public double RestoreAt;public bool Broken=>Durability<=0;}
    public sealed class DynamicMap
    {
        public readonly MapLayout Layout;
        public readonly BridgeState[] Bridges={new BridgeState(),new BridgeState()};
        public readonly CrystalState[] Crystals=new CrystalState[8];
        public int Revision {get;private set;}
        readonly MatchRules rules;
        public DynamicMap(MapLayout layout,MatchRules rules) {Layout=layout;this.rules=rules;for(int i=0;i<8;i++)Crystals[i]=new CrystalState();}
        public void Update(double time,IReadOnlyList<Unit> units,Action<string> emit)
        {
            int active=time+1e-5<rules.BridgeStart ? -1 : ((int)Math.Floor((time-rules.BridgeStart+1e-5)/rules.BridgePeriod))%2;
            for(int i=0;i<2;i++)
            {
                bool next=active==i;
                if(Bridges[i].Open!=next)
                {
                    if(!next)foreach(var u in units)if(u.Alive && u.IsHero && OnBridge(u.Position,i))
                    {
                        var c=Layout.Bridges[i];float sign=u.Position.X+u.Position.Y>=0 ? 1:-1;
                        u.Position=c+new V2(1,1).Normalized*(7*sign);u.Path.Clear();
                    }
                    Bridges[i].Open=next;Revision++;emit((i==0?"Мост Рассвета":"Мост Сумерек")+(next?" открыт":" закрыт"));
                }
                double phase=(time-rules.BridgeStart)%rules.BridgePeriod;
                bool warning=next && phase>=rules.BridgePeriod-rules.BridgeWarning;
                if(warning&&!Bridges[i].Warning)emit("Мост закроется через 15 секунд");
                Bridges[i].Warning=warning;
            }
            for(int i=0;i<8;i++)if(Crystals[i].Broken && time+1e-5>=Crystals[i].RestoreAt)
            {
                bool occupied=false;foreach(var u in units)if(u.Alive&&u.IsHero&&V2.Distance(u.Position,Layout.Crystals[i])<3){occupied=true;break;}
                if(!occupied){Crystals[i].Durability=24;Revision++;emit("Кристальный проход восстановлен");}
            }
        }
        public bool HitCrystal(int index,bool melee,bool basic,double time)
        {
            if(index<0||index>=8||!basic||Crystals[index].Broken)return false;
            var c=Crystals[index];c.Durability=Math.Max(0,c.Durability-(melee?4:3));
            if(c.Broken){c.RestoreAt=time+rules.CrystalRespawn;Revision++;}return true;
        }
        public bool OnBridge(V2 p,int i) => V2.Distance(p,Layout.Bridges[i])<5.5f;
        public bool Walkable(V2 p)
        {
            if(Math.Abs(p.X)>Layout.HalfSize||Math.Abs(p.Y)>Layout.HalfSize)return false;
            if((Math.Abs(p.X)>56||Math.Abs(p.Y)>56)&&V2.Distance(p,Layout.Bosses[0])>12&&V2.Distance(p,Layout.Bosses[1])>12)return false;
            if(Layout.OnLane(p))return true;
            foreach(var w in Layout.Walls)if(w.Contains(p,.55f))return false;
            for(int i=0;i<8;i++)if(!Crystals[i].Broken&&V2.Distance(p,Layout.Crystals[i])<2.4f)return false;
            if(Math.Abs(p.X+p.Y)<5 && Math.Abs(p.X)<43 && Math.Abs(p.Y)<43)
            {
                for(int i=0;i<2;i++)if(Bridges[i].Open&&OnBridge(p,i))return true;
                return false;
            }
            return true;
        }
    }
}
