using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    [Serializable]
    public struct MapBlock
    {
        public V2 Center, Size;
        public MapBlock(V2 c, V2 s) { Center=c; Size=s; }
        public bool Contains(V2 p, float pad=0) => Math.Abs(p.X-Center.X)<Size.X/2+pad && Math.Abs(p.Y-Center.Y)<Size.Y/2+pad;
    }
    [Serializable]
    public sealed class LaneRoute
    {
        public V2[] Points;
        public int Length=>Points.Length;
        public V2 this[int index]=>Points[index];
        public LaneRoute(params V2[] points){Points=points;}
    }
    [Serializable]
    public sealed class MapLayout
    {
        public float HalfSize = 68;
        public V2[] Bases = {new V2(-48,-48), new V2(48,48)};
        public LaneRoute[] Lanes = {
            new LaneRoute(new V2(-48,-48),new V2(-48,48),new V2(48,48)),
            new LaneRoute(new V2(-48,-48),new V2(48,48)),
            new LaneRoute(new V2(-48,-48),new V2(48,-48),new V2(48,48))
        };
        public V2[] Bridges = {new V2(-20,20),new V2(20,-20)};
        public V2[] Crystals = {new V2(-36,12),new V2(-24,-12),new V2(12,-36),new V2(-12,0),
            new V2(36,-12),new V2(24,12),new V2(-12,36),new V2(12,0)};
        // Numbering: magma, wolves, ghosts, azure, centipedes, crab; red side is a 180-degree rotation.
        public V2[] Camps = {new V2(-32,-22),new V2(-36,28),new V2(-16,-4),new V2(-22,-34),new V2(-2,-28),new V2(28,-38),
            new V2(32,22),new V2(36,-28),new V2(16,4),new V2(22,34),new V2(2,28),new V2(-28,38)};
        public V2[] RiftCreatures = {new V2(-10,17),new V2(10,-17)};
        public V2[] Bosses = {new V2(-54,54),new V2(54,-54)};
        public LaneRoute[] BossEntrances = {new LaneRoute(new V2(-48,32),new V2(-32,48)),new LaneRoute(new V2(48,-32),new V2(32,-48))};
        public V2[] Bushes = {new V2(-40,20),new V2(-14,-20),new V2(40,-20),new V2(14,20),new V2(-6,22),new V2(6,-22)};
        public MapBlock[] Walls = {
            new MapBlock(new V2(-30,4),new V2(16,5)),new MapBlock(new V2(-30,20),new V2(16,5)),
            new MapBlock(new V2(4,-30),new V2(5,16)),new MapBlock(new V2(20,-30),new V2(5,16)),
            new MapBlock(new V2(30,-4),new V2(16,5)),new MapBlock(new V2(30,-20),new V2(16,5)),
            new MapBlock(new V2(-4,30),new V2(5,16)),new MapBlock(new V2(-20,30),new V2(5,16))
        };
        public V2 LanePoint(int lane, float distance)
        {
            var p=Lanes[lane];
            for(int i=1;i<p.Length;i++) {float length=V2.Distance(p[i-1],p[i]); if(distance<=length)return p[i-1]+(p[i]-p[i-1]).Normalized*distance; distance-=length;}
            return p[p.Length-1];
        }
        public float LaneLength(int lane) {float d=0;var p=Lanes[lane];for(int i=1;i<p.Length;i++)d+=V2.Distance(p[i-1],p[i]);return d;}
        public float NearestLaneDistance(int lane,V2 point)
        {
            float best=float.MaxValue,result=0,travel=0;var route=Lanes[lane];
            for(int i=1;i<route.Length;i++)
            {
                var a=route[i-1];var delta=route[i]-a;float length=delta.Length;
                float projection=Math.Max(0,Math.Min(length,((point.X-a.X)*delta.X+(point.Y-a.Y)*delta.Y)/Math.Max(.001f,length)));
                float distance=V2.Distance(point,a+delta.Normalized*projection);
                if(distance<best){best=distance;result=travel+projection;}travel+=length;
            }
            return result;
        }
        public bool OnLane(V2 p,float width=4)
        {
            foreach(var lane in Lanes)for(int i=1;i<lane.Length;i++)if(V2.SegmentDistance(p,lane[i-1],lane[i])<=width)return true;
            return false;
        }
        public V2 TowerPosition(int team,int lane,int tier) => LanePoint(lane,team==0 ? 14+(2-tier)*15 : LaneLength(lane)-14-(2-tier)*15);
    }
}
