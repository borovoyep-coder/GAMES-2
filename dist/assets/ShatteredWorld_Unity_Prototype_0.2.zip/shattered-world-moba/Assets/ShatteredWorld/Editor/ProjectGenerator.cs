using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using ShatteredWorld.Unity;
namespace ShatteredWorld.Editor
{
    public static class ProjectGenerator
    {
        const string ScenePath="Assets/ShatteredWorld/Scenes/Valley.unity";
        [InitializeOnLoadMethod]
        static void Initialize(){EditorApplication.delayCall+=()=>{if(!Application.isBatchMode&&!File.Exists(ScenePath))Generate();};}
        [MenuItem("Shattered World/Generate or open prototype")]
        public static void Generate()
        {
            Directory.CreateDirectory("Assets/ShatteredWorld/Scenes");Directory.CreateDirectory("Assets/ShatteredWorld/Settings");
            AssetDatabase.Refresh();
            string configPath="Assets/ShatteredWorld/Settings/MatchConfig.asset";
            var config=AssetDatabase.LoadAssetAtPath<MatchConfig>(configPath);
            if(!config){config=ScriptableObject.CreateInstance<MatchConfig>();AssetDatabase.CreateAsset(config,configPath);}
            var renderer=AssetDatabase.LoadAssetAtPath<UniversalRendererData>("Assets/ShatteredWorld/Settings/Renderer.asset");
            if(!renderer){renderer=ScriptableObject.CreateInstance<UniversalRendererData>();AssetDatabase.CreateAsset(renderer,"Assets/ShatteredWorld/Settings/Renderer.asset");}
            var pipeline=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/ShatteredWorld/Settings/Pipeline.asset");
            if(!pipeline)
            {
                pipeline=UniversalRenderPipelineAsset.Create(renderer);
                AssetDatabase.CreateAsset(pipeline,"Assets/ShatteredWorld/Settings/Pipeline.asset");
            }
            GraphicsSettings.defaultRenderPipeline=pipeline;QualitySettings.renderPipeline=pipeline;
            PlayerSettings.companyName="Valley Prototype";PlayerSettings.productName="Расколотый мир — Долина осколков";
            PlayerSettings.defaultScreenWidth=1600;PlayerSettings.defaultScreenHeight=900;PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToPortrait=false;PlayerSettings.allowedAutorotateToPortraitUpsideDown=false;
            // Enable the package's input backend without a manual Project Settings step.
            var settings=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
            if(settings.Length>0)
            {
                var serialized=new SerializedObject(settings[0]);var handler=serialized.FindProperty("activeInputHandler");
                if(handler!=null&&handler.intValue!=1){handler.intValue=1;serialized.ApplyModifiedPropertiesWithoutUndo();}
            }
            AssetDatabase.SaveAssets();
            if(File.Exists(ScenePath)){EditorSceneManager.OpenScene(ScenePath);return;}
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var light=new GameObject("Sun").AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.5f;light.shadows=LightShadows.Soft;
            light.transform.rotation=Quaternion.Euler(50,-35,0);
            RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.ambientLight=new Color(.5f,.57f,.59f);
            var app=new GameObject("Shattered World").AddComponent<GameApp>();app.Configuration=config;
            EditorSceneManager.SaveScene(scene,ScenePath);EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true)};
            Debug.Log("Shattered World: сцена создана. Нажмите Play.");
        }
        public static void BuildAndroid()
        {
            Generate();Directory.CreateDirectory("Builds");
            var result=BuildPipeline.BuildPlayer(new[]{ScenePath},"Builds/ShatteredWorld.apk",BuildTarget.Android,BuildOptions.Development);
            if(result.summary.result!=UnityEditor.Build.Reporting.BuildResult.Succeeded)throw new System.Exception("Android build failed");
        }
    }
}
