# Blender Studio 0.5

`ValleyOfShards.blend` и FBX поставляются в отдельном архиве Blender Studio. Шесть текстур упакованы внутрь `.blend`. В Unity-архиве уже есть готовые mesh-данные и текстуры, поэтому Blender не нужен для запуска генератора Unity.

Коллекции Environment и Backdrop содержат игровую область и окружающую долину. PreviewUnits — размещённые копии, RiverFlow — 64 анимированные модели пены. Оригиналы 36 отдельных моделей скрыты от рендера; включайте коллекции в Outliner.

У шести миньонов составная иерархия с анимированными частями. Actions именуются `GuardBlue.Walk.LegL` и аналогично для других клипов и частей. В FBX/Animations — по одному файлу на клип: Idle, Walk, Attack, Death, Spawn. Это не Humanoid rig; для ручного импорта используйте transform/Legacy animation. Native Unity importer создаёт те же клипы из записанных ключей и связывает их с событиями симуляции.

Порядок полной пересборки после распаковки обоих архивов в одну папку:

```sh
python SourceArt/trace_reference.py
python SourceArt/upgrade_layout05.py
blender -b -t 8 --python SourceArt/build_ultra_valley.py
blender -b -t 8 --python SourceArt/polish_ultra_scene.py
blender -b -t 8 --python SourceArt/finish_river_banks.py
python Tools/ValidateArt.py
blender -b --python SourceArt/validate_ultra_blender.py
blender -b --factory-startup --python SourceArt/validate_ultra_fbx.py
```

Для Python-разметки нужен NumPy. Blender содержит свой NumPy. Текстуры включены; paint_textures.py воспроизводит их с Pillow и NumPy. `VALLEY_SKIP_RENDER=1` пропускает рендеры. Файлы build_valley.py и build_reference_valley.py служат библиотекой и историческими этапами; отдельно запускать их для финальной сцены не нужно.

polish_ultra_scene.py объединяет соседние визуальные пролёты кладки, убирает перекрывающиеся карнизы, уточняет гранёные скалы, размещает презентационных героев вокруг фонтанов и повторно экспортирует Environment/Backdrop. Финальная сцена сохраняется перед созданием временных галерей для рендеров.

Разметка по изображению — Reference/ReferenceTrace.json. Upgrade 0.5 добавляет фонтаны, береговые ограждения и полноценные кристальные короткие пути; два неясных положения кристаллов отодвинуты от обязательных линий. Невидимые на картинке детали реконструированы.

Координаты: Blender `(x,y,z)` → Unity `(x,z,y)` с обратным порядком треугольников. Локальные pivots и quaternion-ключи сохраняются для миньонов. В FBX есть UV и цвета вершин; для правильного отображения используйте материал, умножающий текстуру на vertex color. Автоматический Unity importer делает это сам.
