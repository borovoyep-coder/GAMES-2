# Blender Studio 0.6

`ValleyOfShards.blend` — сохранённая сцена с 41 редактируемой коллекцией моделей, шестью упакованными текстурами, картой, нейтральными существами и презентационными экземплярами. Графические элементы сделаны мешами Blender; карта не является картинкой на плоскости.

В `FBX` — 39 статических моделей; в `FBX/Animations` — 100 самостоятельных файлов клипов. Анимации составных частей используют Empty-пивоты, ключи положения/поворота/масштаба и собственную иерархию; это не Humanoid-риг.

## Воспроизводимая сборка

Запускайте из корня проекта с Blender 4.3.2 и Python 3 с numpy. Исходный Word-документ находится в `docs/Source` основного Unity-архива. Для переносимого редактирования библиотеки достаточно Studio-архива, для полной сборки распакуйте оба.

```sh
python SourceArt/upgrade_layout06.py
blender --background --python-exit-code 1 --threads 8 --python SourceArt/build_celestial_valley.py
blender --background --python-exit-code 1 --threads 8 --python SourceArt/finish_celestial_scene.py
blender --background --python-exit-code 1 --threads 2 --python SourceArt/repair_caster_chamfers.py
blender --background --python-exit-code 1 --threads 8 --python SourceArt/finish_lane_paving.py
blender --background --python-exit-code 1 --threads 8 --python SourceArt/finish_living_water.py
blender --background --python-exit-code 1 --threads 8 --python SourceArt/render_celestial_valley.py
python Tools/ValidateArt.py
blender --background --python-exit-code 1 --python SourceArt/validate_celestial_blender.py
blender --background --python-exit-code 1 --python SourceArt/validate_celestial_fbx.py
```

`celestial_models.py` содержит авторские модели по концептам нового документа. `build_reference_valley.py`, `ultra_models.py` и `build_valley.py` сохраняют низкоуровневые помощники; их старые самостоятельные точки входа выпускают предыдущие версии. Для версии 0.6 используйте последовательность выше.

`Reference/ReferenceTrace.json` хранит калибровку изображения 1254×1254, башни, боковые проходы, кусты, острова леса и руины. `Reference/ValleyLayout05.json` — стабильная база для последних исправлений; повторный запуск upgrade не добавляет второй набор проходов.

Native-экспорт меняет координаты Blender `(x,y,z)` на Unity `(x,z,y)`, переставляет winding и отражает кватернионы. В файл меша записываются UV, нормали, цвета, пивоты и те же трансформации, что в исходных Action. Ключи и pivots проверяются независимо.

В `.blend` сохранены реальные ключи 64 полос пены реки и 90 брызг/колец водопадов, а также анимация UV воды. В Unity это соответствующие mesh-prefab, AnimationClip и адаптеры течения. Источником боевого урона остаётся C#-симуляция.
