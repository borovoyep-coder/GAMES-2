Shader "Shattered World/Painted World"
{
    Properties
    {
        [MainTexture] _BaseMap("Painted texture",2D)="white"{}
        [MainColor] _BaseColor("Tint",Color)=(1,1,1,1)
        _EmissionStrength("Crystal emission",Range(0,3))=0
        _WindStrength("Foliage wind",Range(0,.3))=0
        _FlowSpeed("Water flow",Range(0,.2))=0
        _FlowDirection("Flow UV direction",Vector)=(0,-1,0,0)
        _ShadeStrength("Painted shadows",Range(0,1))=.7
        _WaterSurface("Water ripples and shore foam",Range(0,1))=0
        _SpecularStrength("Sculpted surface highlights",Range(0,1))=.22
    }
    SubShader
    {
        Tags {"RenderPipeline"="UniversalPipeline" "RenderType"="Opaque" "Queue"="Geometry"}
        Cull Off
        Pass
        {
            Name "PaintedForward"
            Tags {"LightMode"="UniversalForward"}
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma target 3.0
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile_fragment _ _SHADOWS_SOFT
            #pragma multi_compile_fog
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
            TEXTURE2D(_BaseMap);SAMPLER(sampler_BaseMap);
            CBUFFER_START(UnityPerMaterial)
                float4 _BaseMap_ST;half4 _BaseColor;float4 _FlowDirection;half _EmissionStrength,_WindStrength,_FlowSpeed,_ShadeStrength,_WaterSurface,_SpecularStrength;
            CBUFFER_END
            struct Attributes {float4 positionOS:POSITION;float3 normalOS:NORMAL;float2 uv:TEXCOORD0;half4 color:COLOR;UNITY_VERTEX_INPUT_INSTANCE_ID};
            struct Varyings {float4 positionCS:SV_POSITION;float3 positionWS:TEXCOORD0;half3 normalWS:TEXCOORD1;float2 uv:TEXCOORD2;half4 color:COLOR;half fog:TEXCOORD3;UNITY_VERTEX_INPUT_INSTANCE_ID UNITY_VERTEX_OUTPUT_STEREO};
            Varyings Vert(Attributes input)
            {
                Varyings o=(Varyings)0;UNITY_SETUP_INSTANCE_ID(input);UNITY_TRANSFER_INSTANCE_ID(input,o);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                float3 p=TransformObjectToWorld(input.positionOS.xyz);
                float weight=saturate(input.positionOS.y*.16);
                p.x+=sin(_Time.y*1.3+p.x*.43+p.z*.25)*_WindStrength*weight;
                p.z+=cos(_Time.y+p.x*.21+p.z*.39)*_WindStrength*weight*.5;
                p.y+=sin(input.uv.y*9-_Time.y*2.1)*.018*_WaterSurface;
                o.positionWS=p;o.positionCS=TransformWorldToHClip(p);o.normalWS=TransformObjectToWorldNormal(input.normalOS);o.uv=TRANSFORM_TEX(input.uv,_BaseMap);o.color=input.color*_BaseColor;o.fog=ComputeFogFactor(o.positionCS.z);return o;
            }
            half4 Frag(Varyings input):SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                half3 n=normalize(input.normalWS);
                n=normalize(n+half3(sin(input.uv.y*17-_Time.y*2)*.13,0,cos(input.uv.x*21+_Time.y)*.08)*_WaterSurface);
                half3 tex=SAMPLE_TEXTURE2D(_BaseMap,sampler_BaseMap,input.uv+_FlowDirection.xy*_Time.y*_FlowSpeed).rgb;
                half current=sin(input.uv.y*31-_Time.y*2.4+sin(input.uv.x*19+_Time.y*.4)*.9)*.5+.5;
                half3 paint=input.color.rgb*tex*lerp(1,.92+current*.16,_WaterSurface);
                Light sun=GetMainLight(TransformWorldToShadowCoord(input.positionWS));
                half ramp=smoothstep(-.12,.9,dot(n,sun.direction));
                half shadow=lerp(1,sun.shadowAttenuation,_ShadeStrength);
                half3 ambient=max(SampleSH(n),half3(.18,.23,.23));
                half3 color=paint*(ambient*.8+sun.color*(.25+ramp*.75)*shadow);
                color+=paint*_EmissionStrength;
                half3 view=GetWorldSpaceNormalizeViewDir(input.positionWS);half3 halfVector=normalize(sun.direction+view);
                half highlight=pow(saturate(dot(n,halfVector)),lerp(34,90,_WaterSurface))*_SpecularStrength*shadow;
                color+=sun.color*highlight;
                half shore=smoothstep(.43,.5,abs(frac(input.uv.x)-.5));half lace=smoothstep(.55,.95,sin(input.uv.y*15-_Time.y*3+sin(input.uv.x*20))*.5+.5);
                half fresnel=pow(1-saturate(dot(n,view)),3);
                color+=_WaterSurface*(half3(.45,.85,.8)*smoothstep(.87,.98,current)*.07+half3(.45,.85,.8)*shore*lace*.45+half3(.1,.25,.3)*fresnel*.45);
                return half4(MixFog(color,input.fog),1);
            }
            ENDHLSL
        }
        Pass
        {
            Name "ShadowCaster"
            Tags {"LightMode"="ShadowCaster"}
            ZWrite On ZTest LEqual ColorMask 0 Cull Off
            HLSLPROGRAM
            #pragma vertex ShadowVert
            #pragma fragment ShadowFrag
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Shadows.hlsl"
            float3 _LightDirection,_LightPosition;
            struct A {float4 positionOS:POSITION;float3 normalOS:NORMAL;UNITY_VERTEX_INPUT_INSTANCE_ID};
            float4 ShadowVert(A input):SV_POSITION
            {
                UNITY_SETUP_INSTANCE_ID(input);float3 p=TransformObjectToWorld(input.positionOS.xyz);float3 n=TransformObjectToWorldNormal(input.normalOS);
                #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                float3 direction=normalize(_LightPosition-p);
                #else
                float3 direction=_LightDirection;
                #endif
                float4 clip=TransformWorldToHClip(ApplyShadowBias(p,n,direction));
                #if UNITY_REVERSED_Z
                clip.z=min(clip.z,UNITY_NEAR_CLIP_VALUE);
                #else
                clip.z=max(clip.z,UNITY_NEAR_CLIP_VALUE);
                #endif
                return clip;
            }
            half4 ShadowFrag():SV_Target{return 0;}
            ENDHLSL
        }
    }
}
