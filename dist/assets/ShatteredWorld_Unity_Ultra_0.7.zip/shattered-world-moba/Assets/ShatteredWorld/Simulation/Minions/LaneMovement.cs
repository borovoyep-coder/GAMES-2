using System;
namespace ShatteredWorld.Simulation
{
    /// <summary>Continuous swept circles keep bodies separated without leaving their lane.</summary>
    public static class LaneMovement
    {
        public static float Radius(MatchWorld w,Unit unit)=>unit.Kind==Kind.Destroyer?w.Rules.SiegeRadius:unit.Kind==Kind.Caster?w.Rules.CasterRadius:w.Rules.GuardRadius;
        public static bool SpawnClear(MatchWorld w,Unit unit)
        {foreach(var other in w.Units)if(other.Id!=unit.Id&&other.Alive&&other.IsMinion&&V2.Distance(other.Position,unit.Position)<Radius(w,other)+Radius(w,unit)+w.Rules.MinionBodyGap)return false;return true;}
        public static float ClampProgress(MatchWorld w,Unit actor,float desired)
        {
            // A live lane fortification is a progression gate, even when the selected enemy stands behind it.
            var fort=w.NextStructure(actor.Team,actor.Lane);
            if(fort!=null&&fort.Alive)
            {
                float gate=w.Layout.NearestLaneDistance(actor.Lane,fort.Position);
                if(actor.Team==Team.Blue&&actor.LaneDistance<=gate)desired=Math.Min(desired,gate-.12f);
                if(actor.Team==Team.Red&&actor.LaneDistance>=gate)desired=Math.Max(desired,gate+.12f);
            }
            var start=actor.Position;var end=w.Layout.LanePoint(actor.Lane,desired);var delta=end-start;float length2=delta.X*delta.X+delta.Y*delta.Y;
            if(length2<.0000001f)return desired;
            float allowed=1;
            foreach(var other in w.Units)
            {
                if(other.Id==actor.Id||!other.Alive||!other.IsMinion)continue;
                float radius=Radius(w,actor)+Radius(w,other)+w.Rules.MinionBodyGap;var separation=start-other.Position;
                float c=separation.X*separation.X+separation.Y*separation.Y-radius*radius;
                float dot=separation.X*delta.X+separation.Y*delta.Y;
                if(dot>=0)continue; // Moving apart is permitted, including a recovery from an imported overlap.
                if(c<=0){allowed=0;break;}
                float discriminant=dot*dot-length2*c;
                if(discriminant>=0){float hit=(-dot-(float)Math.Sqrt(discriminant))/length2;if(hit>=0&&hit<allowed)allowed=Math.Max(0,hit-.0005f);}
            }
            return actor.LaneDistance+(desired-actor.LaneDistance)*allowed;
        }
    }
}
