using System;
namespace ShatteredWorld.Simulation
{
    public enum Stat { Health,Damage,Speed,Armor,AttackSpeed,ManaRegen,CooldownReduction,IncomingDamage }
    public enum StackRule { Refresh, Stack, Replace }
    [Serializable]
    public sealed class ModifierDefinition
    {
        public string Id, Name;public Stat Stat;public float Flat,Percent,Duration,Period,PeriodicDamage;
        public bool OutOfCombat,RemoveOnDeath=true;public StackRule Stacking;public int MaxStacks=1;
    }
    public sealed class Modifier
    {
        public ModifierDefinition Definition;public int Source,Stacks=1;public double Started,Expires,NextTick;
    }
    public sealed class ModifierSystem
    {
        public void Apply(Unit owner,ModifierDefinition definition,int source,double now)
        {
            foreach(var m in owner.Modifiers)if(m.Definition.Id==definition.Id)
            {
                m.Expires=now+definition.Duration;m.Source=source;
                if(definition.Stacking==StackRule.Stack)m.Stacks=Math.Min(definition.MaxStacks,m.Stacks+1);
                if(definition.Stacking==StackRule.Replace){m.Definition=definition;m.Stacks=1;}
                return;
            }
            owner.Modifiers.Add(new Modifier{Definition=definition,Source=source,Started=now,Expires=now+definition.Duration,NextTick=now+definition.Period});
        }
        public void Update(MatchWorld world,Unit u)
        {
            double now=world.Clock.Time;
            for(int i=u.Modifiers.Count-1;i>=0;i--)
            {
                var m=u.Modifiers[i];
                if(m.Expires<=now||(!u.Alive&&m.Definition.RemoveOnDeath)){u.Modifiers.RemoveAt(i);continue;}
                if(m.Definition.Period>0 && now>=m.NextTick){m.NextTick+=m.Definition.Period;world.Combat.Hit(world.Get(m.Source),u,m.Definition.PeriodicDamage,DamageType.Magical);}
            }
        }
    }
    public static class Buffs
    {
        public static readonly ModifierDefinition Slow=new ModifierDefinition{Id="slow",Name="Замедление",Stat=Stat.Speed,Percent=-.3f,Duration=2};
        public static readonly ModifierDefinition Burn=new ModifierDefinition{Id="burn",Name="Поджог",Duration=3,Period=1,PeriodicDamage=18};
        public static readonly ModifierDefinition Magma=new ModifierDefinition{Id="magma",Name="Пламя разрушения",Duration=75};
        public static readonly ModifierDefinition Azure=new ModifierDefinition{Id="azure",Name="Энергия лазури",Stat=Stat.ManaRegen,Percent=1,Duration=75};
        public static readonly ModifierDefinition AzureCooldown=new ModifierDefinition{Id="azure-cdr",Name="Лазурь: перезарядка",Stat=Stat.CooldownReduction,Flat=.1f,Duration=75};
        public static readonly ModifierDefinition RiftSpeed=new ModifierDefinition{Id="rift-speed",Name="Поток разлома",Stat=Stat.Speed,Percent=.2f,Duration=4,OutOfCombat=true};
        public static readonly ModifierDefinition PortalSpeed=new ModifierDefinition{Id="portal-speed",Name="Шаг Бездны",Stat=Stat.Speed,Percent=.08f,Duration=6,OutOfCombat=true};
        public static readonly ModifierDefinition DawnHealth=new ModifierDefinition{Id="dawn-health",Name="Благословение Рассвета",Stat=Stat.Health,Percent=.15f,Duration=3600};
    }
}
