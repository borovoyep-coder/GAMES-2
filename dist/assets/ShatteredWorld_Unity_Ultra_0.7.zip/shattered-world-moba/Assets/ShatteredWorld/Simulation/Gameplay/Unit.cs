using System;
using System.Collections.Generic;
namespace ShatteredWorld.Simulation
{
    public sealed class Unit
    {
        public int Id, Lane, Tier, Camp=-1, Level=1, Xp, PathRevision=-1, PathIndex, Target;
        public Team Team; public Kind Kind;
        public V2 Position, Spawn, Destination;
        public float Health, BaseHealth, Mana=250, MaxMana=250, Damage, Range, Speed, Armor=15, Gold=300, LaneDistance;
        public float AttackPeriod=1, RespawnAt, LastCombat=-100, RecallUntil, PortalCooldown;
        public double NextAttack, NextThink, RepathAt, DeadAt;
        public double SpawnedAt,LastAttackAt=-1000,AggroUntil;
        public bool IsPlayer, HasDestination, SiegeBlessing, Retreating;
        public readonly double[] Cooldowns=new double[3];
        public readonly List<V2> Path=new List<V2>();
        public readonly List<Modifier> Modifiers=new List<Modifier>();
        public readonly int[] Items=new int[3];
        public bool Alive=>Health>0;
        public bool IsHero=>Kind==Kind.Warrior||Kind==Kind.Mage;
        public bool IsMinion=>Kind==Kind.Guard||Kind==Kind.Caster||Kind==Kind.Destroyer;
        public bool IsStructure=>Kind==Kind.Tower||Kind==Kind.Core;
        public float Stat(Stat stat,double now)
        {
            float baseValue=stat==Simulation.Stat.Health?BaseHealth:stat==Simulation.Stat.Damage?Damage:stat==Simulation.Stat.Speed?Speed:stat==Simulation.Stat.Armor?Armor:stat==Simulation.Stat.AttackSpeed?1:stat==Simulation.Stat.ManaRegen?6:0;
            float flat=0,percent=0;
            foreach(var m in Modifiers)if(m.Definition.Stat==stat&&m.Expires>now&&(!m.Definition.OutOfCombat||now-LastCombat>3))
            {flat+=m.Definition.Flat*m.Stacks;percent+=m.Definition.Percent*m.Stacks;}
            return (baseValue+flat)*(1+percent);
        }
    }
}
