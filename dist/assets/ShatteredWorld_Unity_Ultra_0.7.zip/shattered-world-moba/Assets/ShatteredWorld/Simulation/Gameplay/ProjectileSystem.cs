using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    public sealed class ProjectileState
    {
        public int Id,Source,Target;
        public Team Team;
        public Kind Kind;
        public V2 Position;
        public float Damage,Speed,Travelled,TotalDistance,StartHeight;
        public DamageType DamageType;
    }
    public sealed class AttackImpact
    {
        public int Source,Target;
        public float Damage;
        public double At;
        public bool Ranged;
        public DamageType Type;
    }
    public sealed class ProjectileSystem
    {
        readonly MatchWorld world;
        readonly List<AttackImpact> pending=new List<AttackImpact>();
        public readonly List<ProjectileState> Active=new List<ProjectileState>();
        int nextId=1;
        public ProjectileSystem(MatchWorld world){this.world=world;}
        public void Schedule(Unit source,Unit target,float damage,DamageType type)
        {
            float windup=source.IsStructure?world.Rules.StructureWindup:source.Kind==Kind.Destroyer?world.Rules.MinionSiegeWindup:source.Kind==Kind.Caster?world.Rules.MinionCasterWindup:world.Rules.MinionMeleeWindup;
            pending.Add(new AttackImpact{Source=source.Id,Target=target.Id,Damage=damage,Type=type,Ranged=source.Kind!=Kind.Guard,At=world.Clock.Time+windup});
        }
        public void Update()
        {
            for(int i=pending.Count-1;i>=0;i--)
            {
                var hit=pending[i];if(world.Clock.Time+1e-5<hit.At)continue;pending.RemoveAt(i);
                var source=world.Get(hit.Source);var target=world.Get(hit.Target);
                if(source==null||target==null||!world.Combat.CanTarget(source,target))continue;
                if(hit.Ranged)Active.Add(new ProjectileState{Id=nextId++,Source=source.Id,Target=target.Id,Team=source.Team,Kind=source.Kind,Position=source.Position,Damage=hit.Damage,DamageType=hit.Type,Speed=source.IsStructure?world.Rules.StructureProjectileSpeed:source.Kind==Kind.Caster?world.Rules.CasterProjectileSpeed:world.Rules.SiegeProjectileSpeed,TotalDistance=V2.Distance(source.Position,target.Position),StartHeight=source.Kind==Kind.Core?7:source.Kind==Kind.Tower?4.4f:1.35f});
                else if(world.Combat.InAttackRange(source,target,.6f))world.Combat.Hit(source,target,hit.Damage,hit.Type);
            }
            for(int i=Active.Count-1;i>=0;i--)
            {
                var p=Active[i];var source=world.Get(p.Source);var target=world.Get(p.Target);
                if(target==null||!target.Alive){Active.RemoveAt(i);continue;}
                var delta=target.Position-p.Position;float step=p.Speed*GameClock.Step;
                if(delta.Length<=step+.25f)
                {world.Combat.Hit(source,target,p.Damage,p.DamageType,true);Active.RemoveAt(i);}
                else {p.Position+=delta.Normalized*step;p.Travelled+=step;}
            }
        }
    }
}
