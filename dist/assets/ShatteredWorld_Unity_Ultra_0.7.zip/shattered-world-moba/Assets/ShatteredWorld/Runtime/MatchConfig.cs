using UnityEngine;
using ShatteredWorld.Simulation;
namespace ShatteredWorld.Unity
{
    [CreateAssetMenu(menuName="Shattered World/Match Config")]
    public sealed class MatchConfig:ScriptableObject
    {
        public MatchRules Rules=new MatchRules();
        public MapLayout Layout=new MapLayout();
    }
}
