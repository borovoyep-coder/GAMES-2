using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    /// <summary>Collision opens immediately in simulation; the Blender fragments finish falling visually.</summary>
    public sealed class CrystalPresentation:MonoBehaviour
    {
        Animation clips;
        bool initialized,broken;
        double transition;
        string current;
        Renderer[] meshes;
        public void Sync(CrystalState state,double time,float respawnDuration,float speed)
        {
            if(!clips){clips=GetComponent<Animation>();meshes=GetComponentsInChildren<Renderer>(true);}
            if(!initialized||broken!=state.Broken)
            {
                bool first=!initialized;initialized=true;broken=state.Broken;transition=broken?state.RestoreAt-respawnDuration:time;
                current=broken?"Death":first?"Idle":"Spawn";
                if(clips&&clips.GetClip(current))clips.Play(current);
            }
            double age=time-transition;
            bool visible=!broken||age<1.35;
            foreach(var mesh in meshes)mesh.enabled=visible;
            if(!visible||!clips)return;
            if(current=="Spawn"&&age>=.8){current="Idle";clips.Play(current);}
            var animation=clips[current];if(animation!=null)
            {animation.speed=0;animation.time=current=="Idle"?(float)(time%animation.length):Mathf.Clamp((float)age,0,animation.length);clips.Sample();}
        }
    }
}
