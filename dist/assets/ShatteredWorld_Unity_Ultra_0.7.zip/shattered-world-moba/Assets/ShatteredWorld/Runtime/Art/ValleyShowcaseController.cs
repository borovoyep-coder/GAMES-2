using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    /// <summary>Art inspection scene. Combat lives in the separate Valley match scene.</summary>
    public sealed class ValleyShowcaseController:MonoBehaviour
    {
        public MatchConfig Configuration;
        public GameObject EditTimePreview;
        public MatchWorld World{get;private set;}
        WorldRenderer presentation;
        Camera cameraView;
        Vector3 focus;
        float yaw,pitch=55,zoom=46,accumulator;
        bool panel=true,paths;
        int selectedCrystal;
        string selection="Нажмите на монстра, башню или кристалл";
        GUIStyle title,body,small,button;

        void Awake()
        {
            if(!FindFirstObjectByType<ValleyGraphicsSettings>())new GameObject("Valley graphics quality").AddComponent<ValleyGraphicsSettings>();
            if(EditTimePreview)EditTimePreview.SetActive(false);
            cameraView=Camera.main;
            if(!cameraView){cameraView=new GameObject("Showcase camera").AddComponent<Camera>();cameraView.tag="MainCamera";}
            cameraView.orthographic=true;cameraView.farClipPlane=400;cameraView.nearClipPlane=.1f;Application.targetFrameRate=60;
            Rebuild(0);Overview();
        }
        public void Rebuild(double time)
        {
            if(presentation!=null)presentation.Dispose();
            var layout=Configuration?JsonUtility.FromJson<MapLayout>(JsonUtility.ToJson(Configuration.Layout)):new MapLayout();
            var rules=Configuration?JsonUtility.FromJson<MatchRules>(JsonUtility.ToJson(Configuration.Rules)):new MatchRules();
            World=new MatchWorld(rules,layout);
            // Gallery population only. The match scene keeps the canonical spawn schedule.
            foreach(var camp in World.Objectives.Camps)camp.SpawnAt=0;
            World.Objectives.Update();
            while(World.Clock.Time+1e-5<time)World.Clock.Advance();
            World.Map.Update(World.Clock.Time,World.Units,World.Emit);
            var root=new GameObject("Valley art laboratory");presentation=new WorldRenderer(root.transform,true);presentation.Build(World.Layout);presentation.Sync(World);
            accumulator=0;
        }
        void Jump(double time)
        {
            if(time<World.Clock.Time){Rebuild(time);return;}
            while(World.Clock.Time+1e-5<time)World.Clock.Advance();
            World.Map.Update(World.Clock.Time,World.Units,World.Emit);presentation.Sync(World);
        }
        void Overview(){focus=Vector3.zero;zoom=Mathf.Max(64,78/cameraView.aspect);yaw=0;pitch=55;}
        void LookAt(V2 point,float size){focus=WorldRenderer.P(point);zoom=size;}
        void Update()
        {
            if(World==null)return;
            accumulator+=Mathf.Min(Time.deltaTime,.2f);
            while(accumulator>=GameClock.Step){World.Clock.Advance();World.Map.Update(World.Clock.Time,World.Units,World.Emit);accumulator-=GameClock.Step;}
            var keyboard=Keyboard.current;var mouse=Mouse.current;
            if(keyboard!=null)
            {
                if(keyboard.hKey.wasPressedThisFrame)panel=!panel;
                if(keyboard.digit1Key.wasPressedThisFrame)Overview();
                if(keyboard.digit2Key.wasPressedThisFrame)LookAt(new V2(-30,-6),18);
                if(keyboard.digit3Key.wasPressedThisFrame)LookAt(World.Layout.Bosses[0],16);
                if(keyboard.digit4Key.wasPressedThisFrame)LookAt(World.Layout.Bosses[1],16);
                float x=(keyboard.dKey.isPressed?1:0)-(keyboard.aKey.isPressed?1:0),z=(keyboard.wKey.isPressed?1:0)-(keyboard.sKey.isPressed?1:0);
                focus+=Quaternion.Euler(0,yaw,0)*new Vector3(x,0,z)*Time.deltaTime*zoom*.8f;
            }
            if(mouse!=null)
            {
                zoom=Mathf.Clamp(zoom-mouse.scroll.ReadValue().y*.025f,5,120);
                if(mouse.rightButton.isPressed){var delta=mouse.delta.ReadValue();yaw+=delta.x*.15f;pitch=Mathf.Clamp(pitch-delta.y*.1f,25,82);}
                var p=mouse.position.ReadValue();
                if(mouse.leftButton.wasPressedThisFrame&&(!panel||p.x>325*Screen.width/1600f))Select(p);
            }
            focus.x=Mathf.Clamp(focus.x,-World.Layout.HalfSize,World.Layout.HalfSize);focus.z=Mathf.Clamp(focus.z,-World.Layout.HalfSize,World.Layout.HalfSize);
            var orientation=Quaternion.Euler(pitch,yaw,0);cameraView.transform.position=focus+orientation*Vector3.back*150;cameraView.transform.rotation=orientation;cameraView.orthographicSize=zoom;
            presentation.Sync(World);
        }
        void Select(Vector2 screen)
        {
            var plane=new Plane(Vector3.up,Vector3.zero);var ray=cameraView.ScreenPointToRay(screen);if(!plane.Raycast(ray,out float d))return;
            var p=ray.GetPoint(d);var point=new V2(p.x,p.z);Unit best=null;float closest=5;
            foreach(var unit in World.Units){float candidate=V2.Distance(point,unit.Position);if(candidate<closest){closest=candidate;best=unit;}}
            if(best!=null)
            {
                string[] names={"Магмовый страж","Лунный волк","Призрак разлома","Лазурный голем","Каменная сколопендра","Хрустальный краб"};
                string name=best.Camp==14?"Солнечный колосс":best.Camp==15?"Ночной левиафан":best.Camp==12?"Светляк-наблюдатель":best.Camp==13?"Скат разлома":best.Camp>=0?names[best.Camp%6]:best.Kind==Kind.Tower?"Башня T"+(best.Tier+1):best.Kind==Kind.Core?"Главное ядро":best.Kind==Kind.Mage?"Тестовый маг":"Тестовый воин";
                selection=name+"\nЗдоровье: "+best.Health.ToString("F0")+" / "+best.BaseHealth.ToString("F0")+"\nСторона: "+(best.Team==Team.Blue?"синяя":best.Team==Team.Red?"красная":"нейтральная");return;
            }
            for(int i=0;i<8;i++)if(V2.Distance(point,World.Layout.Crystals[i])<4){selectedCrystal=i;selection="Кристалл "+(i+1)+"\nПрочность: "+World.Map.Crystals[i].Durability+" / 24\nОбычная ближняя атака: 4\nОбычная дальняя атака: 3";return;}
            selection="Координаты: "+point.X.ToString("F1")+", "+point.Y.ToString("F1");
        }
        void Styles()
        {
            if(title!=null)return;
            title=new GUIStyle(GUI.skin.label){fontSize=23,fontStyle=FontStyle.Bold,wordWrap=true};title.normal.textColor=new Color(.94f,.82f,.53f);
            body=new GUIStyle(GUI.skin.label){fontSize=16,wordWrap=true};body.normal.textColor=new Color(.86f,.9f,.82f);
            small=new GUIStyle(body){fontSize=13};small.normal.textColor=new Color(.57f,.7f,.66f);
            button=new GUIStyle(GUI.skin.button){fontSize=15,wordWrap=true};
        }
        bool Button(float x,float y,float w,string text)=>GUI.Button(new Rect(x,y,w,35),text,button);
        void OnGUI()
        {
            if(World==null)return;Styles();GUI.matrix=Matrix4x4.Scale(new Vector3(Screen.width/1600f,Screen.height/900f,1));
            GUI.Label(new Rect(350,20,950,40),"ДОЛИНА ОСКОЛКОВ   /   ОСМОТР 3D-КАРТЫ",title);
            if(Button(1405,20,170,panel?"Скрыть панель · H":"Панель · H"))panel=!panel;
            GUI.Label(new Rect(350,845,1150,40),"WASD — перемещение камеры · ПКМ + мышь — поворот · колесо — масштаб · 1–4 — ракурсы",small);
            BattleAnnouncements.Draw(World);
            if(!panel)return;
            var old=GUI.color;GUI.color=new Color(.035f,.08f,.09f,.96f);GUI.DrawTexture(new Rect(15,15,310,870),Texture2D.whiteTexture);GUI.color=old;
            GUI.Label(new Rect(32,30,275,35),"ДОЛИНА ОСКОЛКОВ",title);
            GUI.Label(new Rect(32,69,270,44),"Авторская карта: лес, руины, разлом, арены и 3D-существа.",small);
            if(Button(32,127,270,"Вся карта · 1"))Overview();
            if(Button(32,169,270,"Лес и Мост Рассвета · 2"))LookAt(new V2(-30,7),19);
            if(Button(32,211,270,"Солнечный колосс · 3"))LookAt(World.Layout.Bosses[0],16);
            if(Button(32,253,270,"Ночной левиафан · 4"))LookAt(World.Layout.Bosses[1],16);
            GUI.Label(new Rect(32,310,265,30),"Проверка динамических объектов",body);
            if(Button(32,349,130,"Рассвет 2:00"))Jump(120);
            if(Button(172,349,130,"Сумерки 4:00"))Jump(240);
            if(Button(32,391,270,"Сбросить в 0:00 · оба закрыты"))Rebuild(0);
            GUI.Label(new Rect(32,442,270,30),"Кристалл "+(selectedCrystal+1)+" · "+World.Map.Crystals[selectedCrystal].Durability+" / 24",body);
            if(Button(32,480,130,"Ближняя −4"))World.Map.HitCrystal(selectedCrystal,true,true,World.Clock.Time);
            if(Button(172,480,130,"Дальняя −3"))World.Map.HitCrystal(selectedCrystal,false,true,World.Clock.Time);
            if(Button(32,522,130,"Следующий")){selectedCrystal=(selectedCrystal+1)%8;LookAt(World.Layout.Crystals[selectedCrystal],11);}
            if(Button(172,522,130,"+60 секунд"))Jump(World.Clock.Time+60);
            GUI.Label(new Rect(32,576,270,120),selection,body);
            GUI.Label(new Rect(32,705,270,60),"Режим осмотра: все нейтральные существа показаны сразу. Бой запускается отдельно.",small);
            if(Button(32,782,270,"Запустить локальный матч"))SceneManager.LoadScene("Valley");
            GUI.Label(new Rect(32,836,270,28),"Игровые часы: "+((int)World.Clock.Time/60).ToString("00")+":"+((int)World.Clock.Time%60).ToString("00"),small);
        }
        void OnDestroy(){if(presentation!=null)presentation.Dispose();}
    }
}
