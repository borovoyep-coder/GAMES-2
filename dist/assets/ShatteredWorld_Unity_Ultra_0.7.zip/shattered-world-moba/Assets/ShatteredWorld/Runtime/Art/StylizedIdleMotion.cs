using UnityEngine;

namespace ShatteredWorld.Unity
{
    /// <summary>Presentation only. Never changes a simulation position or collider.</summary>
    public sealed class StylizedIdleMotion:MonoBehaviour
    {
        public Transform Visual;
        public bool Floating;
        public float Phase,Amplitude=.035f;
        Vector3 origin;
        void Awake(){if(!Visual&&transform.childCount>0)Visual=transform.GetChild(0);if(Visual)origin=Visual.localPosition;}
        void LateUpdate()
        {
            if(!Visual)return;
            float wave=Mathf.Sin(Time.time*(Floating?1.6f:2.2f)+Phase);
            Visual.localPosition=origin+Vector3.up*wave*(Floating?.17f:Amplitude);
            if(Floating)Visual.localRotation=Quaternion.Euler(Mathf.Sin(Time.time*.8f+Phase)*2,0,Mathf.Sin(Time.time*.7f+Phase)*2);
        }
    }
}
