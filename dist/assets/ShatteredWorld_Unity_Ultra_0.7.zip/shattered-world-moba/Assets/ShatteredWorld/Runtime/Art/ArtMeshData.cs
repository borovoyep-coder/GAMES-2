using System;

namespace ShatteredWorld.Unity
{
    // Import-only plain data. The built player uses native Unity Mesh and Prefab assets.
    [Serializable] public sealed class ArtMaterialData {public string Name,Texture;public float Emission;}
    [Serializable] public sealed class ArtModelData {public string Name,File;public int Triangles,Chunks;}
    [Serializable] public sealed class ArtManifestData {public string Version,AmbientFile;public ArtModelData[] Models;public ArtMaterialData[] Materials;}
    [Serializable] public sealed class ArtSubmeshData {public string Material;public int[] Triangles;}
    [Serializable] public sealed class ArtChunkData {public string Name;public float[] Position,Vertices,Normals,UV,Colors;public ArtSubmeshData[] Submeshes;}
    [Serializable] public sealed class ArtAnimationKey {public float Time;public float[] Position,Rotation,Scale;}
    [Serializable] public sealed class ArtAnimationTrack {public string Path;public ArtAnimationKey[] Keys;}
    [Serializable] public sealed class ArtAnimationClip {public string Name;public float Duration;public bool Loop;public ArtAnimationTrack[] Tracks;}
    [Serializable] public sealed class ArtBundleData {public string Name;public ArtChunkData[] Chunks;public ArtAnimationClip[] Clips;}
    [Serializable] public sealed class ArtPoint {public float X,Y,Z;}
    [Serializable] public sealed class ArtFlowPath {public ArtPoint[] Points;public int Count=12;public float Speed=3.2f;}
    [Serializable] public sealed class ArtAmbientData {public ArtFlowPath[] Flows;public ArtPoint[] Splashes;}
}
