using System;
using System.Collections.Generic;
using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    [Serializable]
    public sealed class ArtModelReference
    {
        public string Name;
        public GameObject Prefab;
        public int Triangles;
    }

    [CreateAssetMenu(menuName="Shattered World/Valley Art Catalog")]
    public sealed class ValleyArtCatalog:ScriptableObject
    {
        public string Version="0.7";
        public GameObject Environment;
        public ArtModelReference[] Models=Array.Empty<ArtModelReference>();
        public ArtFlowPath[] AmbientFlows=Array.Empty<ArtFlowPath>();
        public ArtPoint[] AmbientSplashes=Array.Empty<ArtPoint>();
        Dictionary<string,GameObject> lookup;
        public void InvalidateCache(){lookup=null;}
        void OnEnable(){lookup=null;}
        void OnValidate(){lookup=null;}
        public GameObject Find(string name)
        {
            if(lookup==null)
            {
                lookup=new Dictionary<string,GameObject>();
                foreach(var entry in Models)if(entry!=null&&entry.Prefab)lookup[entry.Name]=entry.Prefab;
            }
            return lookup.TryGetValue(name,out var prefab)?prefab:null;
        }
        public string ModelFor(Unit unit)
        {
            if(unit.Kind==Kind.Monster)
            {
                if(unit.Camp==12)return "ObserverFirefly";
                if(unit.Camp==13)return "RiftRay";
                if(unit.Camp==14)return "SolarColossus";
                if(unit.Camp==15)return "NightLeviathan";
                string[] camps={"MagmaGuardian","MoonWolf","RiftGhost","AzureGolem","StoneCentipede","CrystalCrab"};
                return camps[Math.Max(0,unit.Camp)%6];
            }
            string name=unit.Kind==Kind.Warrior?"Warrior":unit.Kind==Kind.Mage?"Mage":unit.Kind==Kind.Guard?"Guard":unit.Kind==Kind.Caster?"Caster":unit.Kind==Kind.Destroyer?"Destroyer":unit.Kind==Kind.Tower?"Tower":"Core";
            return name+(unit.Team==Team.Red?"Red":"Blue");
        }
    }

    public enum ArtObjectKind { Scenery,Tower,Core,Camp,RiftCreature,Boss,Bridge,Crystal,Hero,Fountain }

}
