using UnityEngine;

namespace ShatteredWorld.Unity
{
    public sealed class AmbientFlowAnimator:MonoBehaviour
    {
        ArtFlowPath[] paths;
        Transform[][] foam;
        float[][] distances;
        public void Configure(GameObject prefab,ArtFlowPath[] data)
        {
            if(!prefab||data==null)return;paths=data;foam=new Transform[data.Length][];distances=new float[data.Length][];
            for(int i=0;i<data.Length;i++)
            {
                var p=data[i];foam[i]=new Transform[p.Count];distances[i]=new float[p.Points.Length];
                for(int j=1;j<p.Points.Length;j++)distances[i][j]=distances[i][j-1]+Vector3.Distance(V(p.Points[j-1]),V(p.Points[j]));
                for(int j=0;j<p.Count;j++){foam[i][j]=Instantiate(prefab,transform,false).transform;foam[i][j].localScale=new Vector3(1.3f,1,1.5f);}
            }
        }
        static Vector3 V(ArtPoint p)=>new Vector3(p.X,p.Y,p.Z);
        void Update()
        {
            if(paths==null)return;
            for(int i=0;i<paths.Length;i++)
            {
                var path=paths[i];float length=distances[i][distances[i].Length-1];if(length<=0)continue;
                for(int j=0;j<foam[i].Length;j++)
                {
                    float d=(Time.time*path.Speed+j*length/foam[i].Length)%length;int k=1;while(k<distances[i].Length-1&&distances[i][k]<d)k++;
                    var a=V(path.Points[k-1]);var b=V(path.Points[k]);float t=(d-distances[i][k-1])/Mathf.Max(.01f,distances[i][k]-distances[i][k-1]);
                    foam[i][j].localPosition=Vector3.Lerp(a,b,t)+new Vector3(Mathf.Sin(j*2.4f)*.65f,.08f,0);
                    var direction=(b-a).normalized;var up=Mathf.Abs(Vector3.Dot(direction,Vector3.up))>.9f?Vector3.forward:Vector3.up;foam[i][j].localRotation=Quaternion.LookRotation(direction,up);
                }
            }
        }
    }
}
