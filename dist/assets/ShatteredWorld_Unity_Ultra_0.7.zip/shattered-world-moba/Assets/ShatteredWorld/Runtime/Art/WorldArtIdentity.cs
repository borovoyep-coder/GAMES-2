using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    public sealed class WorldArtIdentity:MonoBehaviour
    {
        public ArtObjectKind Kind;
        public int Index;
        public Team Team=Team.Neutral;
        public string DisplayName;
    }
}
