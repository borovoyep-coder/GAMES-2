using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace ShatteredWorld.Unity
{
    public enum ValleyGraphicsQuality { Balanced,High,Ultra }
    public sealed class ValleyGraphicsSettings:MonoBehaviour
    {
        public static ValleyGraphicsQuality Current{get;private set;}=ValleyGraphicsQuality.Ultra;
        static UniversalRenderPipelineAsset original,runtime;
        public static void Apply(ValleyGraphicsQuality quality)
        {
            Current=quality;PlayerPrefs.SetInt("ValleyGraphicsQuality",(int)quality);
            if(!runtime)
            {
                original=GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;
                if(original){runtime=Instantiate(original);runtime.name="Valley runtime quality";GraphicsSettings.defaultRenderPipeline=runtime;QualitySettings.renderPipeline=runtime;}
            }
            bool ultra=quality==ValleyGraphicsQuality.Ultra,high=quality!=ValleyGraphicsQuality.Balanced;
            if(runtime){runtime.msaaSampleCount=ultra?4:high?2:1;runtime.renderScale=ultra?1.15f:1;runtime.supportsHDR=high;runtime.shadowDistance=ultra?190:high?130:80;runtime.mainLightShadowmapResolution=ultra?4096:high?2048:1024;runtime.shadowCascadeCount=ultra?4:2;}
            QualitySettings.lodBias=ultra?2:high?1.5f:1;QualitySettings.anisotropicFiltering=AnisotropicFiltering.ForceEnable;QualitySettings.shadows=high?ShadowQuality.All:ShadowQuality.HardOnly;QualitySettings.shadowResolution=ultra?ShadowResolution.VeryHigh:ShadowResolution.High;
            foreach(var camera in Camera.allCameras){camera.allowHDR=high;camera.allowMSAA=high;}
        }
        void Awake(){Apply((ValleyGraphicsQuality)Mathf.Clamp(PlayerPrefs.GetInt("ValleyGraphicsQuality",2),0,2));}
        void OnGUI()
        {
            var previous=GUI.matrix;GUI.matrix=Matrix4x4.identity;
            var rect=new Rect(Screen.width-220,Screen.height-40,210,30);string label=Current==ValleyGraphicsQuality.Ultra?"Ультра":Current==ValleyGraphicsQuality.High?"Высокая":"Сбалансированная";
            if(GUI.Button(rect,"Графика: "+label))Apply((ValleyGraphicsQuality)(((int)Current+1)%3));
            GUI.matrix=previous;
        }
        void OnApplicationQuit(){if(original){GraphicsSettings.defaultRenderPipeline=original;QualitySettings.renderPipeline=original;}if(runtime)Destroy(runtime);}
    }
}
