using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    /// <summary>Plays Blender-authored articulated clips. Simulation owns movement, hits and death.</summary>
    public sealed class MinionAnimationPlayer:MonoBehaviour
    {
        public Animation Animation;
        public float DeathDuration=1.35f;
        Vector3 previous;
        bool initialized;
        string current;
        double lastAttack=-1000;
        double lastMovedAt=-1000;
        public void ResetPresentation(){current=null;initialized=false;lastAttack=-1000;lastMovedAt=-1000;if(Animation)Animation.Stop();}
        public void Sync(Unit unit,MatchWorld world,float playbackSpeed=1)
        {
            if(!Animation)return;
            float movement=initialized?Vector3.Distance(previous,transform.position):0;previous=transform.position;initialized=true;
            if(movement>.001f)lastMovedAt=world.Clock.Time;
            string next=!unit.Alive?"Death":world.Clock.Time-unit.SpawnedAt<.8?"Spawn":world.Clock.Time-unit.LastAttackAt<.85?"Attack":world.Clock.Time-lastMovedAt<.12?"Walk":"Idle";
            bool freshAttack=next=="Attack"&&lastAttack!=unit.LastAttackAt;
            if(next!=current||freshAttack)
            {
                if(Animation.GetClip(next))
                {
                    if(current==null||next=="Spawn")Animation.Play(next);else Animation.CrossFade(next,next=="Death"?.06f:.12f);
                    var state=Animation[next];double age=next=="Death"?world.Clock.Time-unit.DeadAt:next=="Spawn"?world.Clock.Time-unit.SpawnedAt:next=="Attack"?world.Clock.Time-unit.LastAttackAt:0;
                    if(state!=null&&!state.wrapMode.Equals(WrapMode.Loop))state.time=Mathf.Clamp((float)age,0,state.length);
                    if(current==null||next=="Spawn")Animation.Sample();
                }
                current=next;
            }
            lastAttack=unit.LastAttackAt;
            foreach(AnimationState state in Animation)state.speed=playbackSpeed;
        }
    }
}
