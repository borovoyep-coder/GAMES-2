using System.Collections.Generic;
using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    public sealed partial class WorldRenderer
    {
        readonly Dictionary<int,GameObject> projectileViews=new Dictionary<int,GameObject>();
        readonly HashSet<int> activeProjectiles=new HashSet<int>();
        void SyncProjectiles(MatchWorld world)
        {
            activeProjectiles.Clear();
            foreach(var p in world.Projectiles.Active)
            {
                var source=world.Get(p.Source);if(!ShowAll&&p.Team!=world.Player.Team&&(source==null||!world.Visible(world.Player.Team,source)))continue;
                var prefab=artCatalog.Find(p.Kind==Kind.Tower||p.Kind==Kind.Core?(p.Team==Team.Red?"RoyalProjectileRed":"RoyalProjectileBlue"):"MagicProjectile");if(!prefab)continue;
                activeProjectiles.Add(p.Id);if(!projectileViews.TryGetValue(p.Id,out var go)){go=Object.Instantiate(prefab,root,false);projectileViews.Add(p.Id,go);}
                float progress=Mathf.Clamp01(p.Travelled/Mathf.Max(.01f,p.TotalDistance));float height=Mathf.Lerp(p.StartHeight,1.1f,progress)+(p.Kind==Kind.Destroyer?Mathf.Sin(progress*Mathf.PI)*1.8f:0);
                go.transform.localPosition=P(p.Position,height);var target=world.Get(p.Target);if(target!=null)go.transform.localRotation=Quaternion.LookRotation(P(target.Position-p.Position))*Quaternion.Euler(0,180,0);
                go.transform.localScale=Vector3.one*(p.Kind==Kind.Destroyer?1.65f:1);
            }
            var remove=new List<int>();foreach(var pair in projectileViews)if(!activeProjectiles.Contains(pair.Key))remove.Add(pair.Key);
            foreach(int id in remove){Object.Destroy(projectileViews[id]);projectileViews.Remove(id);}
        }
    }
}
