using UnityEngine;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Unity
{
    /// <summary>Both match and inspection scenes use the same simulation notices and game clock.</summary>
    public static class BattleAnnouncements
    {
        static GUIStyle heading,caption;
        public static void Draw(MatchWorld world)
        {
            if(heading==null)
            {
                heading=new GUIStyle(GUI.skin.label){fontSize=28,fontStyle=FontStyle.Bold,alignment=TextAnchor.MiddleCenter,wordWrap=true};
                heading.normal.textColor=new Color(1,.88f,.57f);
                caption=new GUIStyle(heading){fontSize=14};caption.normal.textColor=new Color(.73f,.83f,.84f);
            }
            int shown=0;
            for(int i=world.Notices.Count-1;i>=0&&shown<3;i--)
            {
                var notice=world.Notices[i];double age=world.Clock.Time-notice.Time;if(age>=4.5||age<0)continue;
                float y=355+shown*88,alpha=Mathf.Clamp01((float)(4.5-age));var old=GUI.color;
                GUI.color=new Color(.025f,.07f,.09f,.94f*alpha);GUI.DrawTexture(new Rect(390,y,820,78),Texture2D.whiteTexture);
                GUI.color=new Color(.94f,.76f,.37f,alpha);GUI.DrawTexture(new Rect(390,y,820,2),Texture2D.whiteTexture);GUI.color=new Color(1,1,1,alpha);
                GUI.Label(new Rect(407,y+4,786,42),notice.Text,heading);
                string detail=notice.Kind==NoticeKind.Bridge?"Следующая смена через 2 минуты":notice.Kind==NoticeKind.BridgeWarning?"Покиньте закрывающийся мост":notice.Kind==NoticeKind.Tower?"Путь к следующему укреплению открыт":"Команда получила награду за босса";
                GUI.Label(new Rect(407,y+46,786,25),detail,caption);GUI.color=old;shown++;
            }
        }
    }
}
