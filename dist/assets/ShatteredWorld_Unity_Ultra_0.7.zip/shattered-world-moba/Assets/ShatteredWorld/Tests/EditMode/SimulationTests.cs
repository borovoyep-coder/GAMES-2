using NUnit.Framework;
namespace ShatteredWorld.Tests
{
    public sealed class SimulationTests
    {
        public static System.Collections.Generic.IEnumerable<string> Names=>ScenarioSuite.Cases.Keys;
        [TestCaseSource(nameof(Names))]
        public void SimulationRules(string scenario){ScenarioSuite.Cases[scenario]();}
    }
}
