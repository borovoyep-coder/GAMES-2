using System;
using ShatteredWorld.Simulation;
namespace ShatteredWorld.Tests
{
 public static partial class ScenarioSuite
 {
  static void MinionBodies()
  {
   Unit front;var w=EmptyLane(out front);var rear=w.Spawn(Kind.Guard,Team.Blue,w.Layout.LanePoint(1,40));rear.Lane=1;rear.LaneDistance=40;front.Speed=0;
   for(int i=0;i<200;i++){w.Clock.Advance();w.Bots.Update(rear);Check(V2.Distance(front.Position,rear.Position)>=LaneMovement.Radius(w,front)+LaneMovement.Radius(w,rear)+w.Rules.MinionBodyGap-.002,"ally bodies overlap");}
   Check(rear.LaneDistance<front.LaneDistance,"rear minion overtook stopped ally");front.Health=0;float before=rear.LaneDistance;for(int i=0;i<20;i++){w.Clock.Advance();w.Bots.Update(rear);}Check(rear.LaneDistance>before+1,"dead body blocks road");
  }
  static void WavesFightAndDoNotCross()
  {
   Unit blue;var w=EmptyLane(out blue);var red=LaneEnemy(w,Kind.Guard,54);float blueHp=blue.Health,redHp=red.Health;
   for(int i=0;i<200&&blue.Alive&&red.Alive;i++)
   {w.Clock.Advance();w.Bots.Update(blue);w.Bots.Update(red);w.Projectiles.Update();Check(blue.LaneDistance<red.LaneDistance,"enemies crossed");Check(V2.Distance(blue.Position,red.Position)>=LaneMovement.Radius(w,blue)+LaneMovement.Radius(w,red),"enemy bodies overlap");}
   Check(blue.Health<blueHp&&red.Health<redHp,"opposing waves don't exchange damage");
  }
  static void AllActualTowersFightBack()
  {
   foreach(var slot in new MapLayout().TowerSlots)
   {
    var w=new MatchWorld();Unit tower=null;foreach(var u in w.Units){if(u.Kind==Kind.Tower&&(int)u.Team==slot.Team&&u.Lane==slot.Lane&&u.Tier==slot.Tier)tower=u;else u.Health=0;}
    float station=w.Layout.NearestLaneDistance(slot.Lane,tower.Position);var team=(Team)(1-slot.Team);float from=station+(team==Team.Blue?-5:5);var guard=w.Spawn(Kind.Guard,team,w.Layout.LanePoint(slot.Lane,from));guard.Lane=slot.Lane;guard.LaneDistance=from;float hp=tower.Health,ghp=guard.Health;
    for(int i=0;i<150&&guard.Alive;i++){w.Clock.Advance();w.Bots.Update(guard);w.Bots.Update(tower);w.Projectiles.Update();Check(team==Team.Blue?guard.LaneDistance<station:guard.LaneDistance>station,"guard passed live tower");}
    Check(tower.Health<hp,"actual photo tower unreachable T"+slot.Tier+" L"+slot.Lane+" team "+slot.Team);Check(guard.Health<ghp,"tower didn't shoot back team="+slot.Team+" L="+slot.Lane+" tier="+slot.Tier);
   }
  }
  static void RepeatedWaveSpacing()
  {
   var w=new MatchWorld();foreach(var u in w.Units)u.Health=0;
   for(int i=0;i<1400;i++)
   {
    w.Clock.Advance();w.Waves.Update();w.Projectiles.Update();foreach(var u in w.Units)if(u.IsMinion&&u.Alive)w.Bots.Update(u);
    if(i%5!=0)continue;
    for(int a=0;a<w.Units.Count;a++){var x=w.Units[a];if(!x.Alive||!x.IsMinion)continue;for(int b=a+1;b<w.Units.Count;b++){var y=w.Units[b];if(y.Alive&&y.IsMinion)Check(V2.Distance(x.Position,y.Position)>=LaneMovement.Radius(w,x)+LaneMovement.Radius(w,y)-.003,"repeated wave bodies overlap");}}
   }
  }
 }
}
