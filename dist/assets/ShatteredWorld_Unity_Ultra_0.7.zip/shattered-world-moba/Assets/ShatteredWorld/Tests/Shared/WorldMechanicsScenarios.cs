using System;
using System.Collections.Generic;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Tests
{
    public static partial class ScenarioSuite
    {
        static V2 BrushCenter(MapLayout layout)
        {var zone=layout.BushZones[0];V2 p=new V2();foreach(var v in zone.Points)p+=v;return p/zone.Length;}
        static void Fountains()
        {
            var w=new MatchWorld();
            for(int team=0;team<2;team++)
            {
                var center=w.Layout.Fountains[team];var core=w.Layout.Bases[team];
                Check((center-core).X*(team==0?-1:1)>5&&(center-core).Y*(team==0?-1:1)>5,"fountain isn't behind nexus");
                foreach(var hero in w.Units)if(hero.IsHero&&(int)hero.Team==team)Check(V2.Distance(hero.Position,center)<w.Rules.FountainRadius,"hero didn't spawn in fountain");
            }
            var player=w.Player;player.Health=100;player.Mana=0;float hp=player.Health;w.Step();Check(player.Health>hp&&player.Mana>0,"fountain doesn't restore resources");
            player.Position=w.Layout.Bases[0];player.Health=100;w.Step();Near(player.Health,100);
            player.Position=new V2(-20,-25);player.RecallUntil=(float)w.Clock.Time+.05f;w.Step();Check(V2.Distance(player.Position,w.Layout.Fountains[0])<w.Rules.FountainRadius,"recall misses fountain");
            player.Health=0;player.RespawnAt=(float)w.Clock.Time+.05f;w.Step();Check(player.Alive&&V2.Distance(player.Position,w.Layout.Fountains[0])<w.Rules.FountainRadius,"respawn misses fountain");
        }
        static MatchWorld VisionWorld(out Unit target)
        {var w=new MatchWorld();target=w.Player;foreach(var u in w.Units)if(u.Id!=target.Id)u.Health=0;target.Position=BrushCenter(w.Layout)+new V2(0,6);w.Vision.Forget(target);return w;}
        static void BushHistory()
        {
            foreach(var kind in new[]{Kind.Warrior,Kind.Guard,Kind.Tower})
            {
                Unit hero;var w=VisionWorld(out hero);var center=BrushCenter(w.Layout);w.Spawn(kind,Team.Red,center+new V2(8,0));
                w.Vision.Update();Check(w.Visible(Team.Red,hero),"source doesn't grant ordinary sight");
                Clock(w,1);hero.Position=center;w.Vision.Update();Check(w.Visible(Team.Red,hero),"recent vision lost before two seconds");
                Clock(w,2.95);w.Vision.Update();Check(w.Visible(Team.Red,hero),"entry grace cut short");
                Clock(w,3);w.Vision.Update();Check(!w.Visible(Team.Red,hero),"entry grace refreshed itself indefinitely");
                foreach(var unit in w.Snapshot(Team.Red).Units)Check(unit.Id!=hero.Id,"snapshot leaks concealed hero");
                Check(w.Visible(Team.Blue,hero),"own team loses bush hero");
            }
        }
        static void BushUnseen()
        {
            Unit hero;var w=VisionWorld(out hero);var center=BrushCenter(w.Layout);var source=w.Spawn(Kind.Warrior,Team.Red,center+new V2(8,0));w.Vision.Update();
            source.Health=0;Clock(w,5.1);w.Vision.Update();hero.Position=center;w.Vision.Update();
            source.Health=source.BaseHealth;Check(!w.Visible(Team.Red,hero),"stale vision grants entry reveal");
            source.Position=center+new V2(1,0);w.Vision.Update();Check(w.Visible(Team.Red,hero),"close observer cannot see hero in same brush");
            source.Position=center+new V2(8,0);Clock(w,8);w.Vision.Update();Check(!w.Visible(Team.Red,hero),"close observer leaves a permanent reveal");
        }
        static void RiverBoundaries()
        {
            var w=new MatchWorld();int checkedPoints=0;
            for(int phase=0;phase<3;phase++)
            {
                w.Map.Update(phase*120,w.Units,_=>{});
                foreach(var p in w.Layout.River.Points)
                {
                    if(w.Layout.OnLane(p,3.2f)||w.Layout.OnBypass(p,1.25f))continue;
                    bool bridge=false;for(int i=0;i<2;i++)if(w.Map.Bridges[i].Open&&w.Map.OnBridge(p,i))bridge=true;
                    if(!bridge){Check(!w.Map.Walkable(p),"walkable water away from road/bridge");checkedPoints++;}
                }
            }
            Check(checkedPoints>100,"river test didn't cover its length");
            w.Map.Update(0,w.Units,_=>{});
            for(int i=1;i<w.Layout.River.Length-1;i++)
            {
                var p=w.Layout.River[i];if(w.Layout.OnLane(p,8))continue;var d=(w.Layout.River[i+1]-w.Layout.River[i-1]).Normalized;var n=new V2(-d.Y,d.X);var a=p+n*4;var b=p-n*4;
                if(!w.Map.Walkable(a)||!w.Map.Walkable(b))continue;
                Check(!w.Navigation.SegmentClear(a,b),"movement clips across water");var minion=w.Spawn(Kind.Guard,Team.Blue,a);
                for(int step=0;step<100;step++)w.MoveDirect(minion,b);
                Check(!w.Layout.InRiver(minion.Position),"minion entered water");return;
            }
            Check(false,"couldn't find a shore for river movement test");
        }
        static void CrystalShortcuts()
        {
            for(int i=0;i<8;i++)
            {
                var w=new MatchWorld();var route=w.Layout.CrystalShortcuts[i];var a=route[0];var b=route[route.Length-1];var path=new List<V2>();
                Check(!w.Navigation.SegmentClear(a,b),"intact crystal doesn't block shortcut "+i);
                Check(w.Navigation.Find(a,b,path),"crystal seals entire area "+i);float closed=0;var last=a;foreach(var p in path){closed+=V2.Distance(last,p);last=p;}
                for(int hit=0;hit<6;hit++)w.Map.HitCrystal(i,true,true,0);
                Check(w.Navigation.SegmentClear(a,b),"destroyed crystal leaves blocked shortcut "+i);
                Check(w.Navigation.Find(a,b,path),"open shortcut has no route");float open=0;last=a;foreach(var p in path){open+=V2.Distance(last,p);last=p;}
                Check(closed>open+1,"destroying crystal doesn't shorten route "+i+" "+closed+" / "+open);
            }
        }
        static void MinionAttacks()
        {
            var w=new MatchWorld();foreach(var u in w.Units)u.Health=0;
            var caster=w.Spawn(Kind.Caster,Team.Blue,new V2(0,0));var target=w.Spawn(Kind.Guard,Team.Red,new V2(6,0));target.Armor=0;float hp=target.Health;
            Check(w.Combat.Attack(caster,target),"caster attack rejected");Near(target.Health,hp);Clock(w,.25);w.Projectiles.Update();Check(w.Projectiles.Active.Count==1,"no magical projectile");
            caster.Health=0; // A launched bolt remains valid when its caster dies.
            for(int i=0;i<12;i++){w.Clock.Advance();w.Projectiles.Update();}Near(hp-target.Health,caster.Damage);
            var guard=w.Spawn(Kind.Guard,Team.Blue,new V2(5,0));hp=target.Health;Check(w.Combat.Attack(guard,target),"guard attack rejected");Near(target.Health,hp);
            Clock(w,w.Clock.Time+.25);w.Projectiles.Update();Near(hp-target.Health,guard.Damage);
            var tower=w.Spawn(Kind.Tower,Team.Red,new V2(10,0));tower.Lane=0;tower.Tier=0;tower.Armor=0;var siege=w.Spawn(Kind.Destroyer,Team.Blue,new V2(5,0));hp=tower.Health;
            Check(w.Combat.Attack(siege,tower),"siege attack rejected");
            for(int i=0;i<30;i++){w.Clock.Advance();w.Projectiles.Update();}Near(hp-tower.Health,siege.Damage*1.7);
        }
        static void MinionTowerApproach()
        {
            var w=new MatchWorld();foreach(var u in w.Units)u.Health=0;
            var point=w.Layout.LanePoint(1,40);var next=w.Layout.LanePoint(1,41);var d=(next-point).Normalized;
            var tower=w.Spawn(Kind.Tower,Team.Red,point+new V2(-d.Y,d.X)*2.8f);tower.Lane=1;tower.Tier=0;
            var guard=w.Spawn(Kind.Guard,Team.Blue,w.Layout.LanePoint(1,35));guard.Lane=1;guard.LaneDistance=35;float hp=tower.Health;
            for(int i=0;i<100;i++)
            {w.Clock.Advance();w.Bots.Update(guard);w.Projectiles.Update();Check(MapLayout.NearRoute(guard.Position,w.Layout.Lanes[1],3.1f),"guard left the lane to attack tower");}
            Check(tower.Health<hp,"melee guard passed offset tower without attacking");
        }
    }
}
