using System.Collections.Generic;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using ShatteredWorld.Editor;
using ShatteredWorld.Unity;

namespace ShatteredWorld.Tests
{
    public sealed class NativeArtTests
    {
        [Test]
        public void AllOriginalCreaturePrefabsUseRealNativeMeshes()
        {
            var catalog=ValleyArtImporter.EnsureGenerated();Assert.NotNull(catalog);
            string[] names={"MagmaGuardian","MoonWolf","RiftGhost","AzureGolem","StoneCentipede","CrystalCrab","ObserverFirefly","RiftRay","SolarColossus","NightLeviathan"};
            foreach(string name in names)
            {
                var prefab=catalog.Find(name);Assert.NotNull(prefab,name);
                var filters=prefab.GetComponentsInChildren<MeshFilter>(true);Assert.Greater(filters.Length,0,name);
                foreach(var filter in filters)
                {
                    Assert.NotNull(filter.sharedMesh,name);Assert.Greater(filter.sharedMesh.vertexCount,100,name);
                    var renderer=filter.GetComponent<MeshRenderer>();Assert.NotNull(renderer,name);
                    Assert.AreEqual(filter.sharedMesh.subMeshCount,renderer.sharedMaterials.Length,name);
                    foreach(var material in renderer.sharedMaterials){Assert.NotNull(material,name);Assert.AreEqual("Shattered World/Painted World",material.shader.name);}
                }
            }
        }
        [Test]
        public void SavedShowcaseContainsCanonicalObjectCounts()
        {
            Assert.IsNotNull(AssetDatabase.LoadAssetAtPath<SceneAsset>(ValleyArtImporter.ShowcasePath),"Run Shattered World/Generate or open prototype before scene tests.");
            var scene=EditorSceneManager.OpenPreviewScene(ValleyArtImporter.ShowcasePath);
            try
            {
                var counts=new Dictionary<ArtObjectKind,int>();
                foreach(var root in scene.GetRootGameObjects())foreach(var id in root.GetComponentsInChildren<WorldArtIdentity>(true))
                {counts.TryGetValue(id.Kind,out int count);counts[id.Kind]=count+1;}
                Assert.AreEqual(18,counts[ArtObjectKind.Tower]);Assert.AreEqual(2,counts[ArtObjectKind.Core]);Assert.AreEqual(22,counts[ArtObjectKind.Camp]);
                Assert.AreEqual(2,counts[ArtObjectKind.RiftCreature]);Assert.AreEqual(2,counts[ArtObjectKind.Boss]);Assert.AreEqual(8,counts[ArtObjectKind.Crystal]);Assert.AreEqual(2,counts[ArtObjectKind.Bridge]);
                Assert.AreEqual(2,counts[ArtObjectKind.Fountain]);
            }
            finally{EditorSceneManager.ClosePreviewScene(scene);}
        }
        [Test]
        public void EveryMinionHasBlenderClipsWithResolvedTransformPaths()
        {
            var catalog=ValleyArtImporter.EnsureGenerated();
            foreach(var name in new[]{"GuardBlue","CasterBlue","DestroyerBlue","GuardRed","CasterRed","DestroyerRed"})
            {
                var prefab=catalog.Find(name);Assert.NotNull(prefab,name);var animation=prefab.GetComponent<Animation>();Assert.NotNull(animation,name);
                Assert.NotNull(prefab.GetComponent<MinionAnimationPlayer>(),name);
                foreach(var clipName in new[]{"Idle","Walk","Attack","Death","Spawn"})
                {
                    var clip=animation.GetClip(clipName);Assert.NotNull(clip,name+" "+clipName);Assert.IsTrue(clip.legacy);Assert.Greater(clip.length,.5f);
                    foreach(var binding in AnimationUtility.GetCurveBindings(clip))Assert.NotNull(prefab.transform.Find(binding.path),binding.path);
                }
            }
        }
    }
}
