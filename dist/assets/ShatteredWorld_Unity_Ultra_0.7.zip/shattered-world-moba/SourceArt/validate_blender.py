"""Read back the saved .blend; run in background Blender after the build."""
import bpy,json,math
from pathlib import Path
root=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(root/'SourceArt/ValleyOfShards.blend'))
layout=json.loads((root/'Assets/ShatteredWorld/Art/Source/ValleyLayout.json').read_text())
manifest=json.loads((root/'Assets/ShatteredWorld/Art/Source/ArtManifest.json').read_text())
for model in manifest['Models']:
 c=bpy.data.collections.get(model['Name']);assert c and any(o.type=='MESH' for o in c.objects),model['Name']
print('PASS',len(manifest['Models']),'editable Blender model collections')
images=[i for i in bpy.data.images if i.source=='FILE'];assert len(images)==6 and all(i.packed_file for i in images)
print('PASS 6 textures packed into portable .blend')
flow=bpy.data.collections['RiverFlow'];assert len(flow.objects)==42
assert all(o.animation_data and o.animation_data.action for o in flow.objects)
water=bpy.data.materials['Water'].node_tree;assert water.animation_data and water.animation_data.action
river=next(o for o in bpy.data.collections['Environment'].objects if o.name.startswith('Curved river surface'))
assert len(river.data.vertices)==len(layout['River']['Points'])*3 and river.data.uv_layers.active
assert max(v.uv.y for v in river.data.uv_layers.active.data)>10
print('PASS curved river centreline parity, longitudinal UVs, animated water and 42 animated foam meshes')
preview=bpy.data.collections['PreviewUnits'];towers=[o for o in preview.objects if o.name.startswith('Tower spear crystal')]
assert len(towers)==18
for slot in layout['TowerSlots']:
 p=slot['Position'];assert any(math.hypot(o.location.x-p['X'],o.location.y-p['Y'])<.001 for o in towers),slot
print('PASS 18 saved preview tower foundations match explicit photo anchors')
assert any(o.name.startswith('Unified forest paths') for o in bpy.data.collections['Environment'].objects)
assert bpy.context.scene.frame_end==240
for model in manifest['Models']:
 if model['Name']=='Environment':continue
 before=set(bpy.data.objects);bpy.ops.import_scene.fbx(filepath=str(root/'SourceArt/FBX'/(model['Name']+'.fbx')),use_image_search=False)
 imported=[o for o in bpy.data.objects if o not in before];count=0
 for obj in imported:
  if obj.type!='MESH':continue
  assert obj.data.uv_layers.active,'Missing FBX UV: '+model['Name']
  assert obj.data.color_attributes,'Missing FBX vertex colors: '+model['Name']
  obj.data.calc_loop_triangles();count+=len(obj.data.loop_triangles)
 assert count==model['Triangles'],(model['Name'],count,model['Triangles'])
 for obj in imported:
  mesh=obj.data if obj.type=='MESH' else None;bpy.data.objects.remove(obj,do_unlink=True)
  if mesh and mesh.users==0:bpy.data.meshes.remove(mesh)
print('PASS 33 FBX round trips: UVs, vertex colors and triangle counts match native models')
print('BLENDER SOURCE VALIDATION COMPLETE')
