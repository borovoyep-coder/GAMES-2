"""Restore the river's traced silhouette and fill only the photo's forest islands."""
import json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';l=json.loads((OUT/'ValleyLayout.json').read_text());base=json.loads((ROOT/'SourceArt/Reference/ValleyLayout04.json').read_text());old=json.loads((ROOT/'SourceArt/Reference/ValleyLayout05.json').read_text())
def xy(p):return p['X'],p['Y']
def v(p):return {'X':round(p[0],5),'Y':round(p[1],5)}
def dist(p,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy or 1)));return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)
def near(p,routes):return min((dist(p,xy(a),xy(b)) for r in routes for a,b in zip(r['Points'],r['Points'][1:])),default=999)
def inside(p,poly):
 result=False
 for i,aa in enumerate(poly):
  a=xy(aa);b=xy(poly[i-1])
  if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0]:result=not result
 return result
l['River']=base['River'];l['Bridges']=base['Bridges'];l['BridgeDirections']=base['BridgeDirections'];l['BankWalls']=[];l['RiverRailings']=[]
def dry(w):
 p=xy(w['Center']);a=math.radians(w['Angle']);n=max(2,math.ceil(w['Size']['X']/.5))
 return all(near((p[0]+math.cos(a)*(i/n-.5)*w['Size']['X'],p[1]+math.sin(a)*(i/n-.5)*w['Size']['X']),[l['River']])>l['RiverHalfWidth']+1.1 for i in range(n+1))
l['Walls']=[w for w in old['Walls'] if dry(w) and near(xy(w['Center']),l['BossApproaches'])>4.6]
trees=[p for p in l['TreeObstacles'] if near(xy(p),[l['River']])>l['RiverHalfWidth']+1.2]
for ix in range(-59,60,2):
 for iy in range(-59,60,2):
  p=(ix+.32*math.sin(ix*5+iy),iy+.3*math.cos(iy*2-ix))
  if not any(inside(p,r['Points']) for r in l['TreeIslands']):continue
  if near(p,l['Lanes'])<5.1 or near(p,l['BypassRoutes'])<2.65 or near(p,l['JunglePaths'])<2.5 or near(p,l['BossApproaches'])<4.8 or near(p,[l['River']])<l['RiverHalfWidth']+1.3:continue
  if any(math.dist(p,xy(q))<4.7 for q in l['Camps']) or any(math.dist(p,xy(q))<3 for q in l['Crystals']) or any(math.dist(p,xy(q))<8 for q in l['Bridges']):continue
  if any(math.dist(p,xy(q['Position']))<3.4 for q in l['TowerSlots']):continue
  if any(near(p,[r])<1.9 for r in l['CrystalShortcuts']):continue
  if all(math.dist(p,xy(q))>1.65 for q in trees):trees.append(v(p))
l['TreeObstacles']=trees;(OUT/'ValleyLayout.json').write_text(json.dumps(l,indent=2));(OUT/'ValleyVegetation.json').write_text(json.dumps({'Positions':trees}))
# Shared C# geometry serializer is extracted from the 0.6 layout tool, without applying its corrections.
source=(ROOT/'SourceArt/upgrade_layout06.py').read_text();start=source.index('def f(x):');exec(source[start:source.index("print('0.6 layout'")])
(ROOT/'Assets/ShatteredWorld/Simulation/Map/ForestLayout.cs').write_text('namespace ShatteredWorld.Simulation { public static class ForestLayout { public static readonly V2[] Positions={'+','.join('new V2(%sf,%sf)'%(p['X'],p['Y']) for p in trees)+'}; } }')
print('PHOTO07',len(trees),'trunks',len(l['Walls']),'forest walls, original finite river, 0 bank walls')
