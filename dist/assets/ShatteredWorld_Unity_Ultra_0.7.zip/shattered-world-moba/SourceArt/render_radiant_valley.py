"""Review renders from the saved Blender master; never substitutes for a Unity screenshot."""
import bpy,math,json,ast,random,time,os
from pathlib import Path
from mathutils import Matrix,Vector
ROOT=Path(__file__).resolve().parents[1];PREVIEW=ROOT/'docs/Art';pi=math.pi
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
COLLECTIONS={c.name:c for c in bpy.data.collections};CURRENT=None;MATERIALS={m.name:m for m in bpy.data.materials}
for file,names in [('build_valley.py',{'lin','rgb','collection','new_object','primitive_mesh','finish','cyl'}),('build_ultra_valley.py',{'author_matrix','instance'})]:
 for node in ast.parse((ROOT/'SourceArt'/file).read_text()).body:
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
PALETTE={'darkstone':'536454'};PRIMITIVES={};scene=bpy.context.scene;camera=scene.camera
scene.cycles.samples=18
try:scene.cycles.denoiser="OPENIMAGEDENOISE";scene.cycles.use_denoising=True
except TypeError:scene.cycles.use_denoising=False;print("CPU render: this Blender build has no denoiser; using 18 samples",flush=True)
scene.cycles.max_bounces=4;scene.cycles.diffuse_bounces=2;scene.cycles.glossy_bounces=2;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.075;scene.cycles.adaptive_min_samples=4;scene.render.resolution_percentage=100;scene.view_settings.exposure=.22
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
# Rest pose for presentation; actions are retained in the saved master.
for obj in bpy.data.objects:
 if obj.type=='EMPTY' and obj.animation_data:
  obj.animation_data.action=None;obj.rotation_euler=(0,0,0);obj.scale=(1,1,1)
  if obj.name.endswith('_Visual'):obj.location=(0,0,0)
# Native pivot metadata is the authoritative rest pose.
source=ROOT/'Assets/ShatteredWorld/Art/Source';manifest=json.loads((source/'ArtManifest.json').read_text())
for model in manifest['Models']:
 if model['Name'] not in ['Environment','Backdrop']:
  data=json.loads((source/model['File']).read_text())
  for chunk in data['Chunks']:
   if chunk.get('Position'):
    node=bpy.data.objects.get(chunk['Name'])
    if node and node.type=='EMPTY':p=chunk['Position'];node.location=(p[0],p[2],p[1])
bpy.context.view_layer.update()
def shot(name,position,target,scale,resolution):
 if os.environ.get("VALLEY_RENDER_ONLY") and os.environ["VALLEY_RENDER_ONLY"]!=name:return
 camera.location=position;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=resolution;scene.render.filepath=str(PREVIEW/(name+'.png'));bpy.ops.render.render(write_still=True);print('RENDER06',name,flush=True)
# Render the newly modelled minions first so their silhouettes can be reviewed at useful size.
for name in ['Environment','Backdrop','PreviewUnits','RiverFlow','AmbientSplashes']:COLLECTIONS[name].hide_render=True
gallery=collection('MinionGallery06')
for i,name in enumerate(['GuardBlue','CasterBlue','DestroyerBlue','GuardRed','CasterRed','DestroyerRed']):
 p=((i%3-1)*4.8,(i//3)*4.6,0);instance(COLLECTIONS[name],p,0,target=gallery);cyl('Minion gallery pedestal',(p[0],p[1],-.22),1.78,.4,'darkstone','Stone',48)
shot('Minion_Collection',(0,-17,12),(0,2.0,1.15),17.5,(1440,960));gallery.hide_render=True
gallery=collection('CreatureGallery06');names=['MagmaGuardian','MoonWolf','RiftGhost','AzureGolem','StoneCentipede','CrystalCrab','ObserverFirefly','RiftRay','SolarColossus','NightLeviathan']
for i,name in enumerate(names):
 p=((i%5-2)*8.5,(i//5)*9,0);instance(COLLECTIONS[name],p,0,.68 if i>=8 else 1,target=gallery);cyl('Creature review pedestal',(p[0],p[1],-.25),3.2,.4,'darkstone','Stone',48)
shot('Creature_Collection',(0,-34,29),(0,4,1.5),46,(1440,900));gallery.hide_render=True
for name in ['Environment','Backdrop','PreviewUnits','RiverFlow','AmbientSplashes']:COLLECTIONS[name].hide_render=False
shot('Valley_Overview',(0,-126,174),(0,1,-2),166,(1320,1320))
shot('Valley_Closeup',(-22,-41,38),(-19,8,0),54,(1320,920))
shot('Fountain_Nexus',(-66,-74,26),(-51,-51,1.2),29,(1320,920))
print('RADIANT07 RENDERS COMPLETE',flush=True)
