"""Additional editable silhouette/detail pass for the reference's bright fantasy style."""
original_rgb=rgb
COLOR_REMAP={'D6C2A5':'E3C7B6','D6C8A5':'E8CFAB','D1C1A0':'E2CDA8','D9C9A7':'E9D9B4','C2B493':'D8C6A3','799E48':'78A74A','9D7955':'A58052','D6A64F':'EDC35C','D7B164':'E8C670','443A45':'4A3B4E','2BD6C4':'22DCC5','58BCE6':'64D4F6','8CB43E':'A4CD38','B8D568':'D0E86A','A2C94D':'B9DC4F','74A440':'8BBC37'}
def rgb(value):return original_rgb(COLOR_REMAP.get(PALETTE.get(value,value),PALETTE.get(value,value)))
PALETTE.update({'grass':'78A74A','stone':'D8C6A3','lightstone':'F2DFB5','gold':'E5B94E','goldlight':'FFE39A','blue':'25C8FF','red':'FF385D','purple':'B446F3','water':'22DCC5'})

def rig_detail(name,label,make):
 global CURRENT
 CURRENT=COLLECTIONS[name];before=set(CURRENT.objects);make();rig=RIGS[name]
 for obj in CURRENT.objects:
  if obj.type=='MESH' and obj not in before:obj['rig_part']=label;obj.parent=rig['objects'][label];obj.location=Vector(obj.location)-Vector(rig['pivots'][label])

def radiant_details():
 for name,rig in list(RIGS.items()):
  kind=rig['kind'];red=name.endswith('Red');team='red' if red else 'blue'
  if kind in ['guard','mage']:
   def trim(kind=kind,team=team):
    for side in [-1,1]:
     for j in range(3):
      x=side*(.31+j*.035);z=1.56-j*.115;limb('Fine gilded breastplate feather',(x,-.445,z),(side*.12,-.445,z-.075),.014,'goldlight','Metal',.008,6)
    ring('Etched waist medallion',(0,0,.96),.25,.019,team,'Glow',segments=32)
   rig_detail(name,'Body',trim)
   if kind=='guard':
    def helmet():
     for side in [-1,1]:polyline('Knight bright helmet side filigree',[(side*.30,-.33,2.16),(side*.34,-.34,2.03),(side*.28,-.34,1.90)],.015,'goldlight','Metal')
    rig_detail(name,'Head',helmet)
  elif kind=='siege':
   def cannon(team=team):
    for side in [-1,1]:
     for j in range(4):shard('Artillery luminous barrel rune',(side*.31,-.93+j*.32,1.73),.035,.13,team,(0,side*.5))
   rig_detail(name,'Weapon',cannon)
  elif kind in ['golem','solar']:
   scale=1.65 if kind=='solar' else 1;glow='goldlight' if kind=='solar' else 'azure' if 'Azure' in name else 'lava'
   def stones(scale=scale,glow=glow):
    for side in [-1,1]:
     for j in range(4):
      p=(side*(.50+j*.10)*scale,-.50*scale,(2.13-j*.20)*scale);shard('Elemental breastplate splinter',p,.065*scale,.19*scale,glow,(pi/2,side*.3))
   rig_detail(name,'Body',stones)
  elif kind=='wolf':
   def ruff():
    for side in [-1,1]:
     for j in range(7):swept('Layered sculpted white neck fur',[(side*.26,-.69+j*.08,1.94),(side*.47,-.61+j*.08,1.64),(side*.39,-.41+j*.08,1.49)],[.07,.10,.004],'D7E8F2',sides=5)
   rig_detail(name,'Body',ruff)
  elif kind=='dragon':
   def scales():
    for side in [-1,1]:
     for j in range(7):armour('Dragon overlapping neck scale',(.55+side*.34,-.52-j*.10,2.31+j*.065),(.22,.15,.24),'9771A3','Creature')
   rig_detail(name,'Head',scales)
  elif kind in ['tower','core']:
   def base(team=team,kind=kind):
    r=2.45 if kind=='core' else 1.28
    for j in range(12):
     a=j*2*pi/12;shard('Foundation inlaid sapphire glyph',(math.cos(a)*r,math.sin(a)*r,.31),.035,.16,team)
   rig_detail(name,'Body',base)
