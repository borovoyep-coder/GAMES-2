"""Blender 4.3: detailed living valley, rear fountains and articulated minion clips."""
from pathlib import Path
reference=Path(__file__).resolve().parent/'build_reference_valley.py'
reference_text=reference.read_text();exec(compile(reference_text[:reference_text.index('start=time.time();build_environment();')],str(reference),'exec'),globals())
exec(compile((ROOT/'SourceArt/ultra_models.py').read_text(),str(ROOT/'SourceArt/ultra_models.py'),'exec'),globals())
R=random.Random(1505)

def author_matrix(obj):
 matrix=Matrix.LocRotScale(obj.location,obj.rotation_euler.to_quaternion(),obj.scale)
 return author_matrix(obj.parent)@matrix if obj.parent else matrix
def instance(source,p,angle=0,scale=1,target=None):
 target=target or COLLECTIONS['PreviewUnits'];objects=[];transform=Matrix.Translation(Vector(p))@Matrix.Rotation(angle,4,'Z')@Matrix.Scale(scale,4)
 for src in source.objects:
  if src.type!='MESH':continue
  copy=src.copy();copy.data=src.data;copy.animation_data_clear();copy.parent=None;copy.matrix_world=transform@author_matrix(src);target.objects.link(copy);objects.append(copy)
 return objects

def terrain():
 water=OLD_TERRAIN()
 for i,point in enumerate(SMOOTH_RIVER):
  t=i/(len(SMOOTH_RIVER)-1)
  for side in range(3):water.data.vertices[i*3+side].co.z=-.25-t*.56+(0 if side!=1 else .012)
 water.data.update()
 return water

def water_ribbon(name,points,width):
 verts=[];uv=[];faces=[];distance=0
 for i,p in enumerate(points):
  a=points[max(0,i-1)];b=points[min(len(points)-1,i+1)];dx=b[0]-a[0];dy=b[1]-a[1];n=math.hypot(dx,dy) or 1;side=(-dy/n*width/2,dx/n*width/2)
  if i:distance+=math.dist(points[i-1],p)
  verts.extend([(p[0]+side[0],p[1]+side[1],p[2]),(p[0]-side[0],p[1]-side[1],p[2])]);uv.extend([(0,distance*.14),(1,distance*.14)])
  if i:faces.append((i*2-2,i*2-1,i*2+1,i*2))
 return mesh_object(name,verts,faces,'38B6B4','Water',uv)

def landscape():
 collection('Backdrop')
 # A continuous sculpted landscape closes the old void around and below the arena plateau.
 verts=[];faces=[];count=128
 for row,(radius,height) in enumerate([(60,-7),(72,-18),(92,-24),(119,-10),(153,8),(190,23)]):
  for i in range(count):
   a=i*2*pi/count;rr=radius+(math.sin(a*7+row)*2+math.cos(a*13)*1.5)*(row/5);x,y=math.cos(a)*rr,math.sin(a)*rr;z=height+math.sin(a*5+.5)*3+math.sin(a*11)*2
   verts.append((x,y,z))
  if row:
   for i in range(count):j=(i+1)%count;faces.append(((row-1)*count+i,(row-1)*count+j,row*count+j,row*count+i))
 mesh_object('Sculpted mountain valley surrounding the arena',verts,faces,'445D59','Stone')
 # Broad turquoise water below the cliffs catches the waterfalls.
 mesh_object('Lower valley lake',[(-205,-205,-25),(205,-205,-25),(205,205,-25),(-205,205,-25)],[(0,1,2,3)],'216B77','Water',[(0,0),(40,0),(40,40),(0,40)])
 for side in range(4):
  for i in range(20):
   t=-88+i*9;depth=76+math.sin(i*2.8)*7;p=(t,depth) if side==0 else (depth,t) if side==1 else (t,-depth) if side==2 else (-depth,t)
   if any(math.dist(p,b)<20 for b in BOSSES):continue
   sphere('Layered valley escarpment',(p[0],p[1],-12),(R.uniform(4,8),R.uniform(4,7),R.uniform(8,15)),['546C68','60756B','697A6B'][i%3],'Stone',1)
   if i%2==0:tree((p[0],p[1]),R.uniform(7,10),i+side*20)
 for i in range(55):
  a=i*2*pi/55;radius=113+7*math.sin(i*4);x,y=math.cos(a)*radius,math.sin(a)*radius;z=-6+5*math.sin(a*5)
  o=sphere('Distant jagged alpine peak',(x,y,z),(R.uniform(8,14),R.uniform(7,12),R.uniform(14,27)),['607B77','456663','73877D'][i%3],'Stone',1)
  if i%3==0:sphere('Pale alpine summit',(x,y,z+11),(5,5,5),'C5D4C8','Stone',1)
 flows=[ [(-35,98,5),(-36,86,1),(-34,75,-1),(-35,66,-.25),(-35,61,-.25)],[(62,-44,-.81),(68,-46,-4),(71,-49,-12),(75,-53,-22),(85,-63,-24.7)], [(-65,22,-1),(-69,20,-3),(-72,16,-13),(-75,12,-24.7)], [(-65,-27,-1),(-69,-28,-6),(-72,-30,-18),(-78,-34,-24.7)], [(25,66,-1),(27,71,-7),(29,75,-18),(34,81,-24.7)], [(65,26,-1),(71,28,-8),(74,31,-18),(80,36,-24.7)] ]
 for index,points in enumerate(flows):
  water_ribbon('Living headwater and cascade '+str(index),points,3.6 if index==0 else 2.7)
  end=points[-1]
  if index==0:continue
  for j in range(13):sphere('Waterfall foam cloud',(end[0]+math.sin(j*2.4)*1.6,end[1]+math.cos(j*2.4)*1.6,end[2]+.05+abs(math.sin(j))*.3),(.45,.55,.2),'A4ECE7','Glow',0)
  for j in range(7):
   a=j*2*pi/7;ring('Waterfall expanding ripple',(end[0],end[1],end[2]+.04+j*.002),.8+j*.3,.025,'91CCC4','Glow',segments=32)
 (OUT/'AmbientFlows.json').write_text(json.dumps({'Flows':[{'Points':[{'X':p[0],'Y':p[2],'Z':p[1]} for p in line],'Count':12,'Speed':3.2} for line in flows]},separators=(',',':')))

def build_environment():
 OLD_ENVIRONMENT()
 for wall in LAYOUT.get('BankWalls',[]):stone_wall(xy(wall['Center']),wall['Size']['X'],math.radians(wall['Angle']),wall['Size']['Y'],.9)
 # Ferns, tiny flowers and scattered stones soften the paths without covering their route.
 for i in range(500):
  p=(R.uniform(-59,59),R.uniform(-59,59))
  if protected(p,.15) or on_paths(p,[RIVER],HALF_RIVER+.5) or any(math.dist(p,b)<10 for b in BASES) or any(math.dist(p,q)<4 for q in CAMPS):continue
  if i%3==0:
   for j in range(3):
    a=j*2*pi/3;limb('Wildflower stem',(*p,.02),(p[0]+math.cos(a)*.15,p[1]+math.sin(a)*.15,.45),.01,'grass','Foliage',.01,4);sphere('Woodland wildflower',(p[0]+math.cos(a)*.15,p[1]+math.sin(a)*.15,.46),(.07,.07,.04),'A8C5E0' if i%2 else 'E1D494','Creature',0)
  elif i%5==0:sphere('Lichen covered trail stone',(*p,.13),(.36,.28,.25),'809378','Stone',0)

def static_rig_fbx(name,c):
 directory=ROOT/'SourceArt/FBX';directory.mkdir(exist_ok=True);c.hide_viewport=False;c.hide_render=False;bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();copies=[];bpy.ops.object.select_all(action='DESELECT')
 for src in c.objects:
  if src.type!='MESH':continue
  mesh=bpy.data.meshes.new_from_object(src.evaluated_get(deps));o=bpy.data.objects.new(src.name,mesh);bpy.context.scene.collection.objects.link(o);o.matrix_world=author_matrix(src)
  color=mesh.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER')
  for value in color.data:value.color=(*src.get('art_color',[.5,.5,.5]),1)
  if not mesh.uv_layers:
   uv=mesh.uv_layers.new(name='PaintedUV')
   for loop in mesh.loops:
    p=o.matrix_world@mesh.vertices[loop.vertex_index].co;uv.data[loop.index].uv=(p.x*.18+p.z*.13,p.y*.18+p.z*.07)
  o.select_set(True);copies.append(o)
 bpy.ops.export_scene.fbx(filepath=str(directory/(name+'.fbx')),use_selection=True,axis_forward='-Z',axis_up='Y',add_leaf_bones=False,bake_anim=False,colors_type='LINEAR',path_mode='RELATIVE')
 for o in copies:mesh=o.data;bpy.data.objects.remove(o,do_unlink=True);bpy.data.meshes.remove(mesh)
 c.hide_viewport=True;c.hide_render=True

start=time.time();build_environment();landscape()
golem('MagmaGuardian');golem('AzureGolem',True);golem('SolarColossus',False,True);wolf();centipede();ghost();crab();firefly();ray();leviathan()
for name in ['MagmaGuardian','AzureGolem','SolarColossus','MoonWolf','StoneCentipede','RiftGhost','CrystalCrab','ObserverFirefly','RiftRay','NightLeviathan']:improve_creature(name)
tower('TowerBlue');tower('TowerRed',True);tower('CoreBlue',False,True);tower('CoreRed',True,True);fountain('FountainBlue');fountain('FountainRed',True);bridge();gate()
for red in [False,True]:
 suffix='Red' if red else 'Blue';hero('Warrior'+suffix,red);hero('Mage'+suffix,red,True);minion('Guard'+suffix,red);minion('Caster'+suffix,red,True);minion('Destroyer'+suffix,red,False,True)
extra_models();collection('MagicProjectile');sphere('Sculpted projectile core',(0,0,0),(.14,.33,.14),'azure','Glow',2);crystal('Projectile trailing shard',(0,.27,-.1),.1,.35,'azure',(.8,0))
for name in RIGS:make_minion_clips(name)
manifest={'Version':'0.5','Models':[],'Materials':[{'Name':name,'Texture':spec[0],'Emission':spec[1]} for name,spec in SPECS.items()],'AmbientFile':'AmbientFlows.json'}
for name,c in list(COLLECTIONS.items()):manifest['Models'].append(animated_export_bundle(name,c) if name in RIGS else export_bundle(name,c,name in ['Environment','Backdrop']))
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2))
for name,c in list(COLLECTIONS.items()):
 if name in ['Environment','Backdrop']:continue
 if name in RIGS:static_rig_fbx(name,c);animated_fbx(name,c)
 else:export_fbx(name,c)
for name,c in COLLECTIONS.items():
 if name not in ['Environment','Backdrop']:c.hide_render=True;c.hide_viewport=True
preview=collection('PreviewUnits')
for team in [0,1]:
 suffix='Red' if team else 'Blue';instance(COLLECTIONS['Core'+suffix],(*BASES[team],.24));instance(COLLECTIONS['Fountain'+suffix],(*xy(LAYOUT['Fountains'][team]),0))
 for i in range(3):
  p=xy(LAYOUT['Fountains'][team]);instance(COLLECTIONS['Warrior'+suffix if i%2==0 else 'Mage'+suffix],(p[0]+(i-1)*1.1,p[1],.65))
 for i,model in enumerate(['Guard','Guard','Caster','Destroyer']):
  points=LANES[1];distance=16+i*2.2 if not team else sum(math.dist(a,b) for a,b in zip(points,points[1:]))-16-i*2.2;p,angle=sample_path(points,distance);instance(COLLECTIONS[model+suffix],(*p,.24),angle+pi/2 if not team else angle-pi/2)
for slot in TOWERS:instance(COLLECTIONS['TowerRed' if slot['Team'] else 'TowerBlue'],(*xy(slot['Position']),.24))
models=['MagmaGuardian','MoonWolf','RiftGhost','AzureGolem','StoneCentipede','CrystalCrab'];counts=[1,3,3,1,2,1]
for i,p in enumerate(CAMPS):
 side=1 if i<6 else -1;typ=i%6
 for j in range(counts[typ]):dx,dy=(0,-j*1.4*side) if typ==2 else (j*1.4*side,0);instance(COLLECTIONS[models[typ]],(p[0]+dx,p[1]+dy,.18),0,1.1 if typ==1 and j==0 else .85 if typ==1 else 1)
for p in CRYSTALS:instance(COLLECTIONS['CrystalGate'],(*p,.02))
for i,p in enumerate(BRIDGES):
 if i==0:
  direction=LAYOUT['BridgeDirections'][i];instance(COLLECTIONS['Bridge'],(*p,-.45),-math.atan2(direction['X'],direction['Y']))
for i,p in enumerate(BOSSES):instance(COLLECTIONS['SolarColossus' if i==0 else 'NightLeviathan'],(*p,.24),0,1.3 if i else 1)
for i,p in enumerate([xy(p) for p in LAYOUT['RiftCreatures']]):instance(COLLECTIONS['ObserverFirefly' if i==0 else 'RiftRay'],(*p,.2))
flow=collection('RiverFlow')
for i in range(64):
 objects=instance(COLLECTIONS['FoamStreak'],(0,0,0),target=flow)
 for o in objects:
  for frame in range(1,242,6):
   d=(i*RIVER_LENGTH/64+(frame-1)/24*1.9)%RIVER_LENGTH;p,a=sample_path(SMOOTH_RIVER,d);o.location=(p[0]-math.sin(a)*math.sin(i)*1.3,p[1]+math.cos(a)*math.sin(i)*1.3,-.16-d/RIVER_LENGTH*.56);o.rotation_euler.z=a-pi/2;o.keyframe_insert('location',frame=frame);o.keyframe_insert('rotation_euler',frame=frame)
  if o.animation_data:
   for curve in o.animation_data.action.fcurves:
    for key in curve.keyframe_points:key.interpolation='LINEAR'
    curve.modifiers.new('CYCLES')
scene,camera=setup_render();scene.frame_end=240;scene.render.fps=24;scene.cycles.samples=32;scene.render.resolution_x=1600;scene.render.resolution_y=1600;camera.data.ortho_scale=180;camera.location=(0,-126,174);camera.rotation_euler=(Vector((0,1,-2))-camera.location).to_track_quat('-Z','Y').to_euler();scene.frame_set(1)
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
if os.environ.get('VALLEY_SKIP_RENDER')!='1':
 scene.render.filepath=str(PREVIEW/'Valley_Overview.png');bpy.ops.render.render(write_still=True)
 camera.location=(-27,-48,42);camera.rotation_euler=(Vector((-24,-3,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=52;scene.render.resolution_x=1500;scene.render.resolution_y=1050;scene.render.filepath=str(PREVIEW/'Valley_Closeup.png');bpy.ops.render.render(write_still=True)
 camera.location=(-64,-74,28);camera.rotation_euler=(Vector((-50,-50,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=30;scene.render.resolution_x=1450;scene.render.resolution_y=1000;scene.render.filepath=str(PREVIEW/'Fountain_Nexus.png');bpy.ops.render.render(write_still=True)
 COLLECTIONS['Environment'].hide_render=True;COLLECTIONS['Backdrop'].hide_render=True;preview.hide_render=True;flow.hide_render=True;gallery=collection('CreatureGallery')
 names=models+['ObserverFirefly','RiftRay','SolarColossus','NightLeviathan']
 for i,name in enumerate(names):
  x=(i%5-2)*8;y=(i//5)*8;instance(COLLECTIONS[name],(x,y,0),0,.7 if i>=8 else 1,target=gallery);cyl('Gallery pedestal',(x,y,-.25),3,.4,'darkstone','Stone',32)
 camera.location=(0,-35,30);camera.rotation_euler=(Vector((0,3.7,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=43;scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.filepath=str(PREVIEW/'Creature_Collection.png');bpy.ops.render.render(write_still=True)
 gallery.hide_render=True;minion_gallery=collection('MinionGallery')
 for i,name in enumerate(['GuardBlue','CasterBlue','DestroyerBlue','GuardRed','CasterRed','DestroyerRed']):
  p=((i%3-1)*4.5,(i//3)*4.5,0);instance(COLLECTIONS[name],p,target=minion_gallery);cyl('Minion gallery pedestal',(p[0],p[1],-.2),1.7,.35,'darkstone','Stone',32)
 camera.location=(0,-16,13);camera.rotation_euler=(Vector((0,2,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=17;scene.render.resolution_x=1500;scene.render.resolution_y=1000;scene.render.filepath=str(PREVIEW/'Minion_Collection.png');bpy.ops.render.render(write_still=True)
print('ULTRA BUILD COMPLETE',time.time()-start,flush=True)
