"""Photo-based authoring map. Pixel anchors refer to the supplied 1254x1254 illustration.
The image itself is not baked into the 3D scene. Re-run after editing pixel traces.
"""
from pathlib import Path
import json,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';REF=ROOT/'SourceArt/Reference';REF.mkdir(exist_ok=True)
control=[([180,930],[-48,-48]),([214,250],[-48,48]),([1040,235],[48,48]),([1042,950],[48,-48])]
a=[];b=[]
for (u,v),(x,y) in control:
 a.extend([[u,v,1,0,0,0,-x*u,-x*v],[0,0,0,u,v,1,-y*u,-y*v]]);b.extend([x,y])
h=np.r_[np.linalg.solve(a,b),1].reshape(3,3)
def world(p):
 q=h@np.array([p[0],p[1],1]);return {'X':round(float(q[0]/q[2]),4),'Y':round(float(q[1]/q[2]),4)}
def xy(p):return (p['X'],p['Y'])
def route(points):return {'Points':[world(p) for p in points]}
def distance(p,a,b):
 d=(b[0]-a[0],b[1]-a[1]);t=max(0,min(1,((p[0]-a[0])*d[0]+(p[1]-a[1])*d[1])/(d[0]*d[0]+d[1]*d[1] or 1)));return math.hypot(p[0]-a[0]-d[0]*t,p[1]-a[1]-d[1]*t)
lanes=[[(180,930),(196,797),(199,685),(198,552),(209,402),(220,330),(253,283),(307,255),(455,253),(630,253),(815,253),(925,251),(1001,241),(1040,235)],[(180,930),(236,852),(302,777),(369,715),(438,656),(502,618),(562,595),(626,581),(699,544),(780,484),(869,414),(945,341),(1002,276),(1040,235)],[(180,930),(280,954),(450,956),(618,956),(795,955),(888,947),(956,917),(1004,863),(1038,802),(1043,652),(1045,493),(1044,354),(1040,235)]]
# Team 0/1, lane top/mid/bottom 0/1/2, tier outer/middle/inner 0/1/2.
tower_pixels=[(0,0,0,(214,375)),(0,0,1,(198,555)),(0,0,2,(196,762)),(0,1,0,(529,620)),(0,1,1,(426,665)),(0,1,2,(329,742)),(0,2,0,(862,957)),(0,2,1,(618,958)),(0,2,2,(361,958)),(1,0,0,(379,257)),(1,0,1,(630,257)),(1,0,2,(883,258)),(1,1,0,(706,563)),(1,1,1,(806,503)),(1,1,2,(920,400)),(1,2,0,(1041,817)),(1,2,1,(1041,620)),(1,2,2,(1046,433))]
# Eighteen lateral links. They curve around the foundations, not through the tower centres.
passages=[[(230,400),(180,410),(140,395),(119,375)],[(220,581),(168,587),(130,567),(110,548)],[(218,789),(163,789),(117,766),(102,751)],[(548,628),(521,647),(488,651),(453,621)],[(443,678),(413,691),(382,680),(361,653)],[(344,756),(318,781),(302,813),(319,840)],[(884,963),(866,986),(878,1011),(890,1027)],[(641,967),(618,989),(621,1010),(633,1026)],[(383,968),(359,987),(347,1011),(350,1026)],[(402,257),(382,231),(379,207),(390,188)],[(650,260),(629,232),(625,207),(635,186)],[(906,259),(884,231),(885,209),(899,192)],[(720,550),(743,570),(765,582),(791,597)],[(821,483),(840,517),(864,541),(905,523)],[(937,385),(941,418),(963,444),(992,462)],[(1035,793),(1071,817),(1100,820),(1120,804)],[(1037,599),(1072,627),(1103,630),(1125,612)],[(1040,413),(1074,442),(1104,444),(1129,427)]]
bypasses=[[(180,930),(120,889),(101,813),(104,724),(107,632),(110,548),(119,451),(130,375),(119,322),(102,287),(117,253),(155,224),(205,201),(286,185),(389,186),(508,189),(635,186),(771,190),(900,193),(980,186),(1041,203),(1090,242),(1125,321),(1128,428),(1125,612),(1121,804),(1110,894),(1079,961),(1003,1009),(891,1027),(763,1025),(634,1027),(500,1028),(349,1027),(247,1005),(180,930)]]
jungle=[[(214,690),(246,688),(281,685),(321,676),(353,684),(392,695)],[(205,511),(246,515),(287,511),(329,529),(359,551),(402,586)],[(452,596),(461,620),(486,635),(515,623)],[(370,882),(341,912),(358,944)],[(631,898),(636,928),(620,953)],[(806,872),(829,899),(862,940)],[(552,834),(511,831),(488,802),(459,767),(432,738)],[(490,338),(463,301),(434,266)],[(635,335),(624,295),(630,262)],[(837,350),(859,308),(883,269)],[(958,499),(990,480),(1035,451)],[(973,721),(998,746),(1039,775)],[(789,604),(762,585),(731,568),(709,549)],[(890,636),(938,628),(982,639),(1041,657)],[(402,492),(370,501),(337,520),(288,512)],[(451,449),(479,431),(510,407),(552,393),(604,388),(653,396),(698,390),(740,388),(790,385),(837,350)],[(719,742),(691,767),(658,786),(611,804),(552,834)],[(783,700),(813,682),(856,661),(890,636)],[(748,389),(763,422),(781,443),(811,463)],[(281,685),(266,731),(286,765),(317,796),(370,882)],[(806,872),(843,846),(882,810),(911,777),(973,721)],[(452,596),(408,576),(379,594),(353,607),(318,607)],[(789,604),(834,589),(859,605),(890,636)]]
river=[(327,315),(325,361),(340,409),(370,447),(410,477),(460,511),(506,541),(554,567),(604,593),(651,627),(700,674),(750,718),(804,742),(861,763),(916,787),(962,822),(981,842)]
bridges=[(426,474),(752,718)]
camps=[(282,686),(288,514),(451,602),(370,887),(631,902),(806,879),(958,507),(974,729),(789,612),(837,355),(635,341),(490,343)]
# Walls are individual visible runs around the clearings. Gaps are kept explicitly.
walls=[[(278,320),(290,345),(315,357)],[(285,382),(305,399),(327,410)],[(346,407),(361,431),(359,451)],[(269,463),(268,492)],[(260,533),(264,569),(283,584)],[(306,516),(338,536),(350,557)],[(379,552),(397,577),(404,597)],[(249,586),(251,623),(280,644)],[(312,625),(345,635),(375,621)],[(248,646),(246,678),(263,708)],[(293,705),(318,711)],[(305,835),(319,806),(351,789)],[(382,788),(411,792),(444,803)],[(445,832),(441,883)],[(331,907),(401,909)],[(476,742),(520,757),(575,754)],[(483,790),(463,814),(452,860)],[(577,798),(605,817),(612,847)],[(488,894),(549,905)],[(597,849),(638,845),(671,868)],[(714,800),(752,813),(776,833)],[(837,802),(861,820),(883,864)],[(751,895),(821,908)],[(409,317),(415,363),(442,375)],[(454,300),(485,286),(514,299)],[(544,316),(550,350),(524,373)],[(576,299),(573,348)],[(596,373),(648,386),(689,369)],[(686,314),(690,347)],[(883,291),(906,312),(912,354)],[(803,376),(850,391),(883,374)],[(696,338),(720,351)],[(830,389),(840,423)],[(706,430),(745,442),(782,426)],[(926,450),(905,481)],[(923,530),(952,548),(997,537)],[(808,575),(848,590)],[(794,628),(812,655),(847,681)],[(969,602),(989,631),(982,670)],[(856,703),(907,712)],[(1010,692),(1005,747)],[(941,752),(976,769)],[(913,702),(916,737)],[(300,746),(329,762),(359,754)],[(396,697),(413,720)],[(688,691),(724,707),(749,723)],[(826,763),(849,778),(878,783)],[(503,458),(537,470),(556,491)],[(541,371),(560,386)],[(723,307),(754,310),(772,332)]]
# Brush patches: ground-level polygon silhouettes, not isolated random shrubs.
bushes=[[(252,369),(270,377),(271,397),(250,391)],[(285,427),(303,420),(318,437),(300,449)],[(349,468),(367,463),(381,474),(365,484)],[(276,545),(296,542),(307,557),(287,565)],[(307,588),(326,580),(340,592),(327,607)],[(374,610),(392,604),(407,616),(389,626)],[(257,712),(278,704),(291,722),(273,738)],[(291,781),(313,778),(324,793),(303,807)],[(353,816),(378,810),(389,825),(369,837)],[(443,749),(464,750),(477,765),(459,778)],[(478,852),(502,843),(515,859),(495,873)],[(572,775),(591,773),(604,786),(584,802)],[(630,820),(652,816),(663,833),(644,846)],[(704,849),(723,843),(738,859),(720,874)],[(834,884),(853,879),(868,892),(850,907)],[(433,292),(455,287),(466,301),(445,309)],[(528,354),(548,350),(560,365),(539,376)],[(592,292),(614,286),(625,300),(605,311)],[(702,366),(725,359),(736,375),(716,387)],[(782,305),(807,300),(820,316),(799,328)],[(868,402),(889,395),(900,414),(880,424)],[(936,457),(957,447),(970,464),(951,479)],[(924,554),(945,550),(959,565),(939,578)],[(842,605),(862,594),(879,608),(861,622)],[(942,657),(963,650),(977,666),(958,680)],[(898,741),(918,735),(932,753),(912,765)],[(994,792),(1010,788),(1018,805),(1002,815)],[(678,444),(699,440),(711,456),(693,468)],[(387,885),(413,884),(425,897),(403,907)],[(656,923),(679,916),(692,929),(670,939)]]
# Selected wooded islands leave the four battle glades empty and match the reference's narrow corridors.
tree_islands=[[(276,304),(310,294),(328,332),(311,384),(277,377)],[(294,384),(332,386),(352,414),(327,456),(291,459)],[(368,299),(412,286),(444,302),(422,350),(392,371),(357,346)],[(452,274),(510,271),(535,296),(506,321),(467,313)],[(530,292),(565,280),(593,315),(571,360),(543,348)],[(600,271),(661,272),(678,301),(650,317),(615,308)],[(686,285),(748,275),(778,302),(754,345),(715,353)],[(767,278),(830,275),(865,301),(827,327),(795,319)],[(904,290),(941,278),(965,314),(944,356),(910,354)],[(421,376),(460,365),(493,385),(475,424),(442,443),(408,423)],[(510,377),(551,369),(588,409),(572,448),(539,448),(505,421)],[(647,398),(680,385),(705,413),(681,446),(648,438)],[(766,432),(804,419),(831,442),(822,473),(794,486)],[(939,369),(973,351),(1003,382),(993,427),(961,439)],[(878,458),(913,446),(934,477),(912,516),(879,511)],[(856,553),(903,543),(927,575),(899,607),(866,595)],[(970,547),(1002,536),(1018,573),(999,600),(972,588)],[(840,677),(879,681),(896,711),(865,738),(833,714)],[(928,766),(976,771),(994,800),(971,838),(928,817)],[(830,794),(855,785),(883,816),(859,848),(831,837)],[(711,762),(755,765),(779,800),(750,828),(713,808)],[(641,753),(675,747),(697,779),(679,806),(645,796)],[(464,723),(504,721),(523,750),(495,779),(463,765)],[(359,695),(394,698),(413,729),(390,757),(358,745)],[(290,738),(326,739),(342,766),(320,797),(292,783)],[(264,822),(298,812),(321,841),(304,873),(273,879)],[(415,851),(454,843),(473,880),(451,912),(416,901)],[(496,904),(548,907),(570,929),(525,937),(485,925)],[(658,878),(704,874),(725,907),(703,936),(666,928)]]
crystals=[(333,451),(304,821),(696,815),(395,543),(728,487),(973,555),(928,746),(697,393)]
trace={'ImageSize':[1254,1254],'Calibration':control,'TowerAnchors':[{'Team':t,'Lane':l,'Tier':tier,'Pixel':p,'Position':world(p)} for t,l,tier,p in tower_pixels],'MainLanes':lanes,'TowerPassages':passages,'OuterBypasses':bypasses,'JunglePaths':jungle,'River':river,'Walls':walls,'BushPolygons':bushes,'TreeIslands':tree_islands,'Bridges':bridges,'Camps':camps,'Crystals':crystals,'Notes':['Foundation anchors are estimated from the perspective illustration, not crystal tips.','Eight crystals retained by the specification; not all eight locations are clear in the image.','Photo-traced positions replace the old ratio formula; perfect rotational symmetry is not imposed on the perspective drawing.']}
(REF/'ReferenceTrace.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
layout={'HalfSize':80,'Bases':[world((180,930)),world((1040,235))],'Lanes':[route(p) for p in lanes],'BypassRoutes':[route(p) for p in bypasses],'JunglePaths':[route(p) for p in jungle+passages],'TowerPassages':[route(p) for p in passages],'TowerSlots':trace['TowerAnchors'],'Bridges':[world(p) for p in bridges],'Crystals':[world(p) for p in crystals],'Camps':[world(p) for p in camps],'RiftCreatures':[world((528,493)),world((812,668))],'Bosses':[world((176,174)),world((1060,1044))],'BossRadius':16,'BossEntrances':[route([(119,322),(348,203)]),route([(1004,861),(1130,858)])],'Bushes':[],'BushZones':[],'River':route(river),'RiverHalfWidth':2.65,'BridgeDirections':[],'Walls':[],'TreeObstacles':[],'TreeIslands':[route(p) for p in tree_islands]}
for p in bushes:
 poly=route(p);layout['BushZones'].append(poly);layout['Bushes'].append({'X':round(sum(v['X'] for v in poly['Points'])/len(p),4),'Y':round(sum(v['Y'] for v in poly['Points'])/len(p),4)})
riverw=[xy(v) for v in layout['River']['Points']]
for p in layout['Bridges']:
 i=min(range(len(riverw)-1),key=lambda i:distance(xy(p),riverw[i],riverw[i+1]));a,b=riverw[i:i+2];d=(b[0]-a[0],b[1]-a[1]);n=math.hypot(*d);layout['BridgeDirections'].append({'X':round(-d[1]/n,6),'Y':round(d[0]/n,6)})
protected=[([xy(p) for p in v['Points']],4.2) for v in layout['Lanes']]+[([xy(p) for p in v['Points']],1.65) for v in layout['BypassRoutes']+layout['JunglePaths']]
campw=[xy(p) for p in layout['Camps']]
def free_of_corridors(p):
 return not any(distance(p,a,b)<width+.6 for line,width in protected for a,b in zip(line,line[1:])) and not any(math.dist(p,c)<3.5 for c in campw)
# Split masonry into short visible blocks. Blockers and geometry use precisely these same runs.
for line in walls:
 line=[xy(world(p)) for p in line]
 for a,b in zip(line,line[1:]):
  length=math.dist(a,b);n=max(1,math.ceil(length/1.3));angle=math.degrees(math.atan2(b[1]-a[1],b[0]-a[0]));run=[]
  def flush():
   if not run:return
   start,end=run[0],run[-1];cx=a[0]+(b[0]-a[0])*(start+end+1)/(2*n);cy=a[1]+(b[1]-a[1])*(start+end+1)/(2*n);layout['Walls'].append({'Center':{'X':round(cx,4),'Y':round(cy,4)},'Size':{'X':round((end-start+1)*length/n,4),'Y':.85},'Angle':round(angle,4)});run.clear()
  for j in range(n):
   p=(a[0]+(b[0]-a[0])*(j+.5)/n,a[1]+(b[1]-a[1])*(j+.5)/n)
   if free_of_corridors(p):run.append(j)
   else:flush()
  flush()
# The mesh and navigation both use this exact sampled centreline.
raw=[np.array(xy(p),dtype=float) for p in layout['River']['Points']];smooth=[]
for i in range(len(raw)-1):
 a=raw[max(0,i-1)];b=raw[i];c=raw[i+1];d=raw[min(len(raw)-1,i+2)]
 for j in range(5):
  t=j/5;q=(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)*.5;smooth.append({'X':round(float(q[0]),5),'Y':round(float(q[1]),5)})
smooth.append(layout['River']['Points'][-1]);layout['River']={'Points':smooth}
vegetation=OUT/'ValleyVegetation.json'
if vegetation.exists():layout['TreeObstacles']=json.loads(vegetation.read_text())['Positions']
(OUT/'ValleyLayout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
# Generate the default C# layout from the same data: one source of positions for Unity, tests and Blender.
def csfloat(v):return f'{float(v):.6f}'.rstrip('0').rstrip('.')+'f'
def csv(v):return f"new V2({csfloat(v['X'])},{csfloat(v['Y'])})"
def csarr(values):return 'new V2[]{'+','.join(csv(v) for v in values)+'}'
def csr(r):return 'new LaneRoute('+','.join(csv(v) for v in r['Points'])+')'
lines=['namespace ShatteredWorld.Simulation { public static class ReferenceMapData { public static void Apply(MapLayout m) {','m.HalfSize=80;m.BossRadius=16;m.RiverHalfWidth=2.65f;']
for name in ['Bases','Bridges','Crystals','Camps','RiftCreatures','Bosses','Bushes','BridgeDirections']:lines.append('m.'+name+'='+csarr(layout[name])+';')
for name in ['Lanes','BypassRoutes','JunglePaths','TowerPassages','BossEntrances','BushZones','TreeIslands']:lines.append('m.'+name+'=new LaneRoute[]{'+','.join(csr(r) for r in layout[name])+'};')
lines.append('m.River='+csr(layout['River'])+';')
lines.append('m.TowerSlots=new TowerSlot[]{'+','.join('new TowerSlot{Team=%s,Lane=%s,Tier=%s,Position=%s}'%(v['Team'],v['Lane'],v['Tier'],csv(v['Position'])) for v in layout['TowerSlots'])+'};')
lines.append('m.Walls=new MapBlock[]{'+','.join('new MapBlock('+csv(w['Center'])+','+csv(w['Size'])+','+csfloat(w['Angle'])+')' for w in layout['Walls'])+'};')
lines.append('} } }');(ROOT/'Assets/ShatteredWorld/Simulation/Map/ReferenceMapData.cs').write_text('\n'.join(lines))
print('Traced:',len(layout['TowerSlots']),'towers,',len(layout['TowerPassages']),'tower-side passages,',len(layout['Walls']),'wall runs,',len(layout['BushZones']),'bush polygons')
