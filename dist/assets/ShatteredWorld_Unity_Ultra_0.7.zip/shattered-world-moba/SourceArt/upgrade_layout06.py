"""Latest user corrections supersede bank railings and the extended 0.5 river."""
from pathlib import Path
import json,math,numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source'
l=json.loads((ROOT/'SourceArt/Reference/ValleyLayout04.json').read_text())
old=json.loads((ROOT/'SourceArt/Reference/ValleyLayout05.json').read_text()) if (ROOT/'SourceArt/Reference/ValleyLayout05.json').exists() else json.loads((OUT/'ValleyLayout.json').read_text())
(ROOT/'SourceArt/Reference/ValleyLayout05.json').write_text(json.dumps(old,indent=2))
def xy(p):return p['X'],p['Y']
def v(p):return {'X':round(p[0],5),'Y':round(p[1],5)}
def dist(p,a,b):
 d=(b[0]-a[0],b[1]-a[1]);t=max(0,min(1,((p[0]-a[0])*d[0]+(p[1]-a[1])*d[1])/(d[0]*d[0]+d[1]*d[1] or 1)));return math.dist(p,(a[0]+t*d[0],a[1]+t*d[1]))
def near(p,routes):return min((dist(p,xy(a),xy(b)) for r in routes for a,b in zip(r['Points'],r['Points'][1:])),default=999)
# Straight diagonal channel, entirely inside the playfield. Both finite ends are springs/pools.
a=xy(l['River']['Points'][0]);b=xy(l['River']['Points'][-1]);delta=(b[0]-a[0],b[1]-a[1]);length=math.hypot(*delta);direction=(delta[0]/length,delta[1]/length);normal=(-direction[1],direction[0])
l['River']={'Points':[v((a[0]+delta[0]*i/120,a[1]+delta[1]*i/120)) for i in range(121)]}
for i,point in enumerate(l['Bridges']):
 p=xy(point);t=((p[0]-a[0])*direction[0]+(p[1]-a[1])*direction[1]);l['Bridges'][i]=v((a[0]+t*direction[0],a[1]+t*direction[1]));l['BridgeDirections'][i]=v(normal)
l['BankWalls']=[];l['RiverRailings']=[]
for name in ['Fountains','Crystals','CrystalDirections','CrystalShortcuts','CrystalDetours']:l[name]=old[name]
# Preserve gates/detours from 0.5, but cut all masonry close to the new river.
def dry_wall(w):
 p=xy(w['Center']);angle=math.radians(w['Angle']);length=w['Size']['X'];n=max(2,math.ceil(length/.4))
 return min(near((p[0]+math.cos(angle)*(i*length/n-length/2),p[1]+math.sin(angle)*(i*length/n-length/2)),[l['River']]) for i in range(n+1))>l['RiverHalfWidth']+1.1
l['Walls']=[w for w in old['Walls'] if dry_wall(w)]
l['JunglePaths']=old['JunglePaths']
trace=json.loads((ROOT/'SourceArt/Reference/ReferenceTrace.json').read_text());aa=[];bb=[]
for (u,y),(x,z) in trace['Calibration']:aa.extend([[u,y,1,0,0,0,-x*u,-x*y],[0,0,0,u,y,1,-z*u,-z*y]]);bb.extend([x,z])
h=np.r_[np.linalg.solve(aa,bb),1].reshape(3,3)
def world(p):q=h@np.array([*p,1]);return v((q[0]/q[2],q[1]/q[2]))
# Two forest approaches per boss, originating in the small paths beside the outer towers.
paths=[[(214,375),(180,360),(140,330),(115,286)],[(379,257),(382,231),(379,207),(335,196),(307,206)],[(862,957),(871,930),(895,912),(925,909),(949,931),(950,944)],[(1041,817),(1071,840),(1092,866),(1126,908),(1146,969),(1139,981)]]
l['BossApproaches']=[{'Points':[world(p) for p in line]+[l['Bosses'][i//2]]} for i,line in enumerate(paths)]
l['BossEntrances']=[{'Points':[l['BossApproaches'][i*2+j]['Points'][-2] for j in range(2)]} for i in range(2)]
# Widening approaches clears their original wall segments and trunks, but keeps nearby forest.
l['Walls']=[w for w in l['Walls'] if near(xy(w['Center']),l['BossApproaches'])>4.6]
trees=[p for p in old['TreeObstacles'] if near(xy(p),[l['River']])>l['RiverHalfWidth']+1.3 and near(xy(p),l['BossApproaches'])>4.7 and all(math.dist(xy(p),xy(q))>8 for q in l['Bridges'])]
# Arena tree belts seal side access; permanent lane and bypass corridors remain clear.
for i,boss in enumerate(l['Bosses']):
 c=xy(boss)
 for j in range(40):
  angle=j*math.tau/40;p=(c[0]+math.cos(angle)*15.9,c[1]+math.sin(angle)*15.9)
  if max(abs(p[0]),abs(p[1]))>78:continue
  if near(p,l['Lanes'])<5.1 or near(p,l['BypassRoutes'])<2.9 or near(p,l['BossApproaches'])<4.7:continue
  if all(math.dist(p,xy(q))>1.9 for q in trees):trees.append(v(p))
l['TreeObstacles']=trees
# Where a straightened channel intersects an old forest spur, the channel wins.
# Mandatory paths are independently tested for all bridge and crystal states.
(OUT/'ValleyLayout.json').write_text(json.dumps(l,indent=2));(OUT/'ValleyVegetation.json').write_text(json.dumps({'Positions':trees}))
(ROOT/'Assets/ShatteredWorld/Simulation/Map/ForestLayout.cs').write_text('namespace ShatteredWorld.Simulation { public static class ForestLayout { public static readonly V2[] Positions={'+','.join('new V2(%sf,%sf)'%(p['X'],p['Y']) for p in trees)+'}; } }')
def f(x):return (f'{float(x):.6f}'.rstrip('0').rstrip('.') or '0')+'f'
def cv(p):return 'new V2('+f(p['X'])+','+f(p['Y'])+')'
def route(r):return 'new LaneRoute('+','.join(cv(p) for p in r['Points'])+')'
lines=['namespace ShatteredWorld.Simulation { public static class ReferenceMapData { public static void Apply(MapLayout m) {','m.HalfSize=80;m.BossRadius=16;m.RiverHalfWidth=2.65f;']
for name in ['Bases','Fountains','Bridges','Crystals','CrystalDirections','Camps','RiftCreatures','Bosses','Bushes','BridgeDirections']:lines.append('m.'+name+'=new V2[]{'+','.join(cv(p) for p in l[name])+'};')
for name in ['Lanes','BypassRoutes','JunglePaths','TowerPassages','BossEntrances','BossApproaches','BushZones','TreeIslands','CrystalShortcuts','RiverRailings']:lines.append('m.'+name+'=new LaneRoute[]{'+','.join(route(r) for r in l[name])+'};')
lines.append('m.River='+route(l['River'])+';')
lines.append('m.TowerSlots=new TowerSlot[]{'+','.join('new TowerSlot{Team=%s,Lane=%s,Tier=%s,Position=%s}'%(p['Team'],p['Lane'],p['Tier'],cv(p['Position'])) for p in l['TowerSlots'])+'};')
for name in ['Walls','BankWalls']:lines.append('m.'+name+'=new MapBlock[]{'+','.join('new MapBlock('+cv(w['Center'])+','+cv(w['Size'])+','+f(w['Angle'])+')' for w in l[name])+'};')
lines.append('} } }');(ROOT/'Assets/ShatteredWorld/Simulation/Map/ReferenceMapData.cs').write_text('\n'.join(lines))
print('0.6 layout',len(trees),'trunks',len(l['Walls']),'walls; no bank walls; straight internal river; 4 wide forest boss routes')
