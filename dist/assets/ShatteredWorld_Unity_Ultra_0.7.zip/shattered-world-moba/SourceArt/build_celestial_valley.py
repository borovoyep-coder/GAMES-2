"""Rebuild the editable 0.6 master, native Unity meshes and animated FBX using Blender 4.3."""
from pathlib import Path
reference=Path(__file__).resolve().parent/'build_reference_valley.py'
reference_text=reference.read_text();exec(compile(reference_text[:reference_text.index('start=time.time();build_environment();')],str(reference),'exec'),globals())
exec(compile((ROOT/'SourceArt/ultra_models.py').read_text(),str(ROOT/'SourceArt/ultra_models.py'),'exec'),globals())
# Preserve efficient export/instance functions; replace every requested model with new concept-based geometry.
import ast
for node in ast.parse((ROOT/'SourceArt/build_ultra_valley.py').read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['author_matrix','instance','water_ribbon','static_rig_fbx']:
  exec(compile(ast.Module(body=[node],type_ignores=[]),'helpers05','exec'),globals())
exec(compile((ROOT/'SourceArt/celestial_models.py').read_text(),str(ROOT/'SourceArt/celestial_models.py'),'exec'),globals())
R=random.Random(1606);PALETTE.update({'water':'2BD6C4','foam':'C0F7E9','grass':'799E48','goldlight':'F4D782','purple':'B353F4'})
# A distinct lighter blue is used only by the water below and outside the playfield.
MATERIALS['SkyWater']=MATERIALS['Water'].copy();MATERIALS['SkyWater'].name='SkyWater';SPECS['SkyWater']=('FlowWater',.25)
for mat in [MATERIALS['Water'],MATERIALS['SkyWater']]:
 shader=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED');shader.inputs['Roughness'].default_value=.22;shader.inputs['Metallic'].default_value=.10

def rest_rig(name,active=False):
 rig=RIGS[name]
 for label,node in rig['objects'].items():
  node.animation_data.action=rig['clips']['Idle']['actions'][label] if active else None;node.location=(0,0,0) if label=='Visual' else rig['pivots'][label];node.rotation_euler=(0,0,0);node.scale=(1,1,1)
 bpy.context.view_layer.update()

def isolated_fbx(name,c):
 # Baking one rig in a tiny scene avoids evaluating the entire forest for every keyframe.
 original=bpy.context.window.scene;temp=bpy.data.scenes.new('FBX isolated '+name);temp.collection.children.link(c);bpy.context.window.scene=temp;c.hide_viewport=False;c.hide_render=False;temp.render.fps=24;bpy.context.view_layer.update()
 for obj in c.objects:
  if obj.type!='MESH':continue
  obj.data=obj.data.copy();mesh=obj.data
  attr=mesh.color_attributes.get('Color') or mesh.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER')
  for value in attr.data:value.color=(*obj.get('art_color',[.5,.5,.5]),1)
  mesh.color_attributes.active_color=attr
  if not mesh.uv_layers:
   layer=mesh.uv_layers.new(name='PaintedUV')
   for loop in mesh.loops:
    p=author_matrix(obj)@mesh.vertices[loop.vertex_index].co;layer.data[loop.index].uv=(p.x*.18+p.z*.13,p.y*.18+p.z*.07)
 if name in RIGS:
  rest_rig(name);static_rig_fbx(name,c);c.hide_viewport=False;c.hide_render=False
  rig=RIGS[name];directory=ROOT/'SourceArt/FBX/Animations';directory.mkdir(exist_ok=True)
  for clip,data in rig['clips'].items():
   for label,node in rig['objects'].items():node.animation_data.action=data['actions'][label]
   temp.frame_start=1;temp.frame_end=data['end'];temp.frame_set(1);bpy.ops.object.select_all(action='DESELECT')
   for obj in c.objects:obj.select_set(True)
   bpy.context.view_layer.objects.active=rig['root'];bpy.ops.export_scene.fbx(filepath=str(directory/(name+'_'+clip+'.fbx')),use_selection=True,axis_forward='-Z',axis_up='Y',add_leaf_bones=False,bake_anim=True,bake_anim_use_all_actions=False,bake_anim_use_nla_strips=False,bake_anim_simplify_factor=0,colors_type='LINEAR',path_mode='RELATIVE')
  rest_rig(name)
 else:export_fbx(name,c)
 bpy.context.window.scene=original;bpy.data.scenes.remove(temp);c.hide_viewport=True;c.hide_render=True

def compact_meshes(objects):
 groups={}
 for obj in objects:
  if obj.type=='MESH' and not obj.modifiers:groups.setdefault((obj.get('art_material'),tuple(obj.get('art_color',[]))),[]).append(obj)
 for (material,color),items in groups.items():
  if len(items)<2:continue
  verts=[];faces=[]
  for obj in items:
   matrix=Matrix.LocRotScale(obj.location,obj.rotation_euler.to_quaternion(),obj.scale);offset=len(verts);verts.extend(tuple(matrix@v.co) for v in obj.data.vertices);faces.extend(tuple(offset+i for i in f.vertices) for f in obj.data.polygons)
  mesh=bpy.data.meshes.new('Merged sculpted foliage');mesh.from_pydata(verts,[],faces);mesh.update();obj=bpy.data.objects.new(items[0].name+' merged',mesh);CURRENT.objects.link(obj);obj.color=(*color,1);obj['art_color']=list(color);obj['art_material']=material;mesh.materials.append(MATERIALS[material])
  for old in items:bpy.data.objects.remove(old,do_unlink=True)

exec(compile((ROOT/'SourceArt/celestial_environment.py').read_text(),'celestial_environment.py','exec'),globals())
def lane_road(points,width=6.7):seamless_lane(points,width)

OLD_MERGE=merge_footpaths
def merge_footpaths():
 vertices=[];edges=[]
 for polygon,color in PATH_SURFACES:
  off=len(vertices);vertices.extend(Vector(p) for p in polygon);edges.extend((off+i,off+(i+1)%len(polygon)) for i in range(len(polygon)))
 v,e,faces,*_=delaunay_2d_cdt(vertices,edges,[],0,.00001);groups={}
 for face in faces:
  p=(sum(v[i].x for i in face)/len(face),sum(v[i].y for i in face)/len(face));hits=[color for polygon,color in PATH_SURFACES if point_in(p,polygon)]
  if not hits or on_paths(p,[RIVER],HALF_RIVER+.05) and not on_lane(p,3.4):continue
  color=hits[-1];groups.setdefault(color,[]).append(tuple(face))
 for color,kept in groups.items():mesh_object('Joined natural earth woodland paths' if color=='9D7955' else 'Shared road foundation',[(p.x,p.y,.041) for p in v],kept,color,'Ground')

def environment06():
 global ROAD_CENTERS
 collection('Environment');water=terrain();water.name='Straight turquoise river entirely within map';water['art_color']=list(rgb('2BD6C4'));water.color=(*rgb('2BD6C4'),1)
 for i,p in enumerate(SMOOTH_RIVER):
  t=i/(len(SMOOTH_RIVER)-1)
  for k in range(3):water.data.vertices[i*3+k].co.z=-.32-t*.14+(0 if k!=1 else .008)
 water.data.update()
 # Natural vertical soil banks close the depression; there are no masonry river walls.
 for side,bank in enumerate([BANK_LEFT,BANK_RIGHT]):
  verts=[];faces=[]
  for i,p in enumerate(bank):
   z=-.32-i/(len(bank)-1)*.14;verts.extend([(p[0],p[1],-.1),(p[0],p[1],z-.03)])
   if i:faces.append((i*2-2,i*2-1,i*2+1,i*2))
  mesh_object('Unwalled natural river earth bank',verts,faces,'8D9A63','Ground')
 ROAD_CENTERS=[]
 for road in LANES:lane_road(road)
 build_joined_pavers()
 for path in BYPASSES:path_strip(path,2.8,'9D7955')
 for path in HERO_PATHS:path_strip(path,2.65,'9D7955')
 for route in LAYOUT['BossApproaches']:path_strip([xy(p) for p in route['Points']],7.2,'9D7955')
 for wall in LAYOUT['Walls']:stone_wall(xy(wall['Center']),wall['Size']['X'],math.radians(wall['Angle']),wall['Size']['Y'])
 for p in BASES:floor_disc(p,8.8,'D6C2A5')
 for i,p in enumerate(BOSSES):
  floor_disc(p,BOSS_RADIUS,'D6C2A5')
  for rr in [3.5,8,12.5,15]:ring('Boss sanctuary inset divine circuit',(*p,.23),rr,.055,'goldlight' if i==0 else 'purple','Glow')
  for j in range(30):
   a=j*2*pi/30;q=(p[0]+math.cos(a)*(BOSS_RADIUS-.3),p[1]+math.sin(a)*(BOSS_RADIUS-.3))
   if on_paths(q,[[xy(p) for p in r['Points']] for r in LAYOUT['BossApproaches']],4) or on_lane(q,4.3) or on_paths(q,BYPASSES,2):continue
   cyl('Arena carved boundary column',(*q,1.7),.43,3.4,'D0BEA0','Stone',10);box('Arena column gold capital',(*q,3.48),(1.04,1.04,.24),'gold','Metal',.04);shard('Arena ward crystal',(*q,3.63),.18,.82,'goldlight' if i==0 else 'purple')
 for i,p in enumerate(CAMPS):
  cyl('Forest camp warm earth',(*p,-.06),3.8,.07,'A58D5A','Ground',32)
  for j in range(7):
   a=j*2*pi/7;q=(p[0]+math.cos(a)*3.8,p[1]+math.sin(a)*3.8)
   if not protected(q,.3):rock('Camp mossy stone',(*q,.12),(.35,.32,.20),'8B997A',j)
 for i,p in enumerate(LAYOUT['TreeObstacles']):tree(xy(p),4.9+(i%7)*.22,i)
 for region in LAYOUT['BushZones']:
  polygon=[xy(p) for p in region['Points']];x0=min(p[0] for p in polygon);x1=max(p[0] for p in polygon);y0=min(p[1] for p in polygon);y1=max(p[1] for p in polygon)
  before=set(CURRENT.objects)
  for i in range(max(8,int((x1-x0)*(y1-y0)*1.3))):
   p=(R.uniform(x0,x1),R.uniform(y0,y1))
   if point_in(p,polygon):bush_geometry(*p,R.uniform(.78,1.1))
  compact_meshes([o for o in CURRENT.objects if o not in before])
 for side in range(4):
  for i in range(43):
   t=-62+i*2.95;p=(t,62) if side==0 else (t,-62) if side==1 else (62,t) if side==2 else (-62,t)
   if any(math.dist(p,b)<BOSS_RADIUS+1 for b in BOSSES):continue
   rock('Layered island edge cliff',(*p,-3.2),(2.5,2.3,4.3+(i%4)*.3),'899A86',i)
  for i in range(27):
   t=-64+i*4.8;depth=66+(i%3)*.7;p=(t,depth) if side==0 else (depth,t) if side==1 else (t,-depth) if side==2 else (-depth,t)
   if not any(math.dist(p,b)<BOSS_RADIUS+3 for b in BOSSES):tree(p,6.0+(i%5)*.5,i+side*31)
 for x in [-27,-8,13,33]:
  y=61.5
  for side in [-1,1]:cyl('Skyline ruin fluted column',(x+side*1.7,y,2.4),.38,4.8,'D9C9A7','Stone',10);box('Skyline ruin capital',(x+side*1.7,y,4.9),(1.05,1.05,.24),'lightstone','Stone',.04)
  for j in range(13):a=(j+.5)*pi/13;o=box('Skyline arch carved wedge',(x+math.cos(a)*1.7,y,4.9+math.sin(a)*1.7),(.45,.70,.45),'lightstone','Stone',.035);o.rotation_euler.y=pi/2-a
 for i in range(500):
  p=(R.uniform(-60,60),R.uniform(-60,60))
  if protected(p,.25) or on_paths(p,[RIVER],HALF_RIVER+.7) or any(math.dist(p,b)<9 for b in BASES):continue
  if i%4==0:
   for j in range(3):a=j*2*pi/3;limb('Woodland flower stem',(*p,0),(p[0]+math.cos(a)*.16,p[1]+math.sin(a)*.16,.40),.012,'719A46','Foliage',.008,5);sphere('Bright wildflower',(p[0]+math.cos(a)*.16,p[1]+math.sin(a)*.16,.41),(.075,.075,.04),'E9D991' if i%2 else '9CBFE5','Creature',0)
  else:grass_clump(*p,.8)
 merge_footpaths()
 print('ENVIRONMENT06',len(LAYOUT['TreeObstacles']),'nav-matched trees;',len(LAYOUT['Walls']),'forest wall segments; 0 river walls',flush=True)

def landscape06():
 collection('Backdrop');verts=[];faces=[];n=96
 for row,(radius,height) in enumerate([(59,-8),(74,-20),(96,-25),(123,-10),(155,8),(191,23)]):
  for i in range(n):
   a=i*2*pi/n;rr=radius+math.sin(a*9+row)*row*.5;verts.append((math.cos(a)*rr,math.sin(a)*rr,height+math.sin(a*7)*3+math.sin(a*11)*2))
  if row:
   for i in range(n):j=(i+1)%n;faces.extend([((row-1)*n+i,(row-1)*n+j,row*n+i),((row-1)*n+j,row*n+j,row*n+i)])
 mesh_object('Sculpted layered alpine valley surrounding playfield',verts,faces,'8A9E8E','Stone')
 mesh_object('Lighter blue lower valley lake',[(-205,-205,-25),(205,-205,-25),(205,205,-25),(-205,205,-25)],[(0,1,2,3)],'58BCE6','SkyWater',[(0,0),(40,0),(40,40),(0,40)])
 for side in range(4):
  for i in range(20):
   t=-88+i*9;depth=77+math.sin(i*2.8)*6;p=(t,depth) if side==0 else (depth,t) if side==1 else (t,-depth) if side==2 else (-depth,t)
   if any(math.dist(p,b)<19 for b in BOSSES):continue
   rock('Dramatic faceted outer escarpment',(*p,-13),(5+(i%3),5,11+(i%5)),['78978F','8DA79A','6B8F86'][i%3],i)
   if i%2==0:tree(p,7+(i%4),i)
 for i in range(48):
  a=i*2*pi/48;r=117+8*math.sin(i*4);p=(math.cos(a)*r,math.sin(a)*r,-3+5*math.sin(a*5));rock('Distant alpine peak',p,(10,9,18+(i%6)),['829C99','708E8D','96AAA1'][i%3],i)
 flows=[[(-65,22,-1),(-69,20,-3),(-72,16,-13),(-75,12,-24.7)],[(-65,-27,-1),(-69,-28,-6),(-72,-30,-18),(-78,-34,-24.7)],[(25,66,-1),(27,71,-7),(29,75,-18),(34,81,-24.7)],[(65,26,-1),(71,28,-8),(74,31,-18),(80,36,-24.7)],[(-3,-64,-1),(-5,-69,-5),(-8,-74,-16),(-14,-80,-24.7)],[(58,-46,-1),(65,-49,-6),(70,-54,-15),(78,-61,-24.7)]]
 for index,points in enumerate(flows):
  obj=water_ribbon('Living blue external waterfall '+str(index),points,3.2);obj.data.materials.clear();obj.data.materials.append(MATERIALS['SkyWater']);obj['art_material']='SkyWater';obj['art_color']=list(rgb('75D4F2'));obj.color=(*rgb('75D4F2'),1)
  end=points[-1]
  for j in range(9):sphere('Waterfall whitewater foam mound',(end[0]+math.sin(j*2.4)*1.5,end[1]+math.cos(j*2.4)*1.5,end[2]+.06),(.40,.51,.15),'B9EDF6','Glow',0)
 (OUT/'AmbientFlows.json').write_text(json.dumps({'Flows':[{'Points':[{'X':p[0],'Y':p[2],'Z':p[1]} for p in line],'Count':14,'Speed':3.8} for line in flows],'Splashes':[{'X':p[-1][0],'Y':p[-1][2]+.06,'Z':p[-1][1]} for p in flows]},separators=(',',':')))
 return flows

start=time.time();print('CELESTIAL06 start',flush=True)
guardian('MagmaGuardian');guardian('AzureGolem',True);guardian('SolarColossus',False,True);moon_wolf();stone_centipede();rift_ghost();crystal_crab();observer();rift_ray();night_dragon()
for red in [False,True]:
 suffix='Red' if red else 'Blue';celestial_building('Tower'+suffix,red);celestial_building('Core'+suffix,red,True);tiled_fountain('Fountain'+suffix,red);knight('Guard'+suffix,red);spirit_mage('Caster'+suffix,red);siege_engine('Destroyer'+suffix,red);hero('Warrior'+suffix,red);hero('Mage'+suffix,red,True)
celestial_bridge();crystal_gate();extra_models();splash_model()
for red in [False,True]:
 name='RoyalProjectileRed' if red else 'RoyalProjectileBlue';collection(name);shard('Royal flying energy spear',(0,0,-.2),.15,.67,'red' if red else 'blue',(pi/2,0))
collection('MagicProjectile');shard('Flying magic energy bolt',(0,0,-.1),.13,.48,'azure',(pi/2,0))
for name in RIGS:animate_rig(name);rest_rig(name)
manifest={'Version':'0.6','Models':[],'Materials':[{'Name':name,'Texture':spec[0],'Emission':spec[1]} for name,spec in SPECS.items()],'AmbientFile':'AmbientFlows.json'}
for name,c in list(COLLECTIONS.items()):
 c.hide_viewport=False;c.hide_render=False;bpy.context.view_layer.update();manifest['Models'].append(animated_export_bundle(name,c) if name in RIGS else export_bundle(name,c));isolated_fbx(name,c);print('MODEL06',name,flush=True)
print('KITS06 complete',time.time()-start,flush=True)
environment06();flows=landscape06()
for name in ['Environment','Backdrop']:manifest['Models'].append(export_bundle(name,COLLECTIONS[name],True))
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2))
for name in RIGS:rest_rig(name)
preview=collection('PreviewUnits')
for team in range(2):
 suffix='Red' if team else 'Blue';instance(COLLECTIONS['Core'+suffix],(*BASES[team],.24));instance(COLLECTIONS['Fountain'+suffix],(*xy(LAYOUT['Fountains'][team]),0))
 for j,model in enumerate(['Guard','Guard','Caster','Destroyer']):
  road=LANES[1];distance=16+j*2.2 if not team else sum(math.dist(a,b) for a,b in zip(road,road[1:]))-16-j*2.2;p,angle=sample_path(road,distance);instance(COLLECTIONS[model+suffix],(*p,.24),angle+pi/2 if not team else angle-pi/2)
for slot in TOWERS:instance(COLLECTIONS['TowerRed' if slot['Team'] else 'TowerBlue'],(*xy(slot['Position']),.24))
models=['MagmaGuardian','MoonWolf','RiftGhost','AzureGolem','StoneCentipede','CrystalCrab'];counts=[1,3,3,1,2,1]
for i,p in enumerate(CAMPS):
 for j in range(counts[i%6]):
  side=1 if i<6 else -1;dx,dy=(0,-j*1.4*side) if i%6==2 else (j*1.4*side,0);instance(COLLECTIONS[models[i%6]],(p[0]+dx,p[1]+dy,.18),0,1.05 if i%6==1 and j==0 else .82 if i%6==1 else 1)
for p in CRYSTALS:instance(COLLECTIONS['CrystalGate'],(*p,.02))
for i,p in enumerate(BRIDGES):
 if i==0:
  d=LAYOUT['BridgeDirections'][i];instance(COLLECTIONS['Bridge'],(*p,-.12),-math.atan2(d['X'],d['Y']))
for i,p in enumerate(BOSSES):instance(COLLECTIONS['SolarColossus' if i==0 else 'NightLeviathan'],(*p,.24),0,1.3 if i else 1)
for i,p in enumerate([xy(p) for p in LAYOUT['RiftCreatures']]):instance(COLLECTIONS['ObserverFirefly' if i==0 else 'RiftRay'],(*p,.2))
flow=collection('RiverFlow')
for i in range(64):
 for obj in instance(COLLECTIONS['FoamStreak'],(0,0,0),target=flow):
  for frame in range(1,242,6):
   distance=(i*RIVER_LENGTH/64+(frame-1)/24*2.2)%RIVER_LENGTH;p,a=sample_path(SMOOTH_RIVER,distance);obj.location=(p[0]-math.sin(a)*math.sin(i)*1.4,p[1]+math.cos(a)*math.sin(i)*1.4,-.30-distance/RIVER_LENGTH*.14);obj.rotation_euler.z=a-pi/2;obj.keyframe_insert('location',frame=frame);obj.keyframe_insert('rotation_euler',frame=frame)
  for curve in obj.animation_data.action.fcurves:
   for key in curve.keyframe_points:key.interpolation='LINEAR'
   curve.modifiers.new('CYCLES')
# Source waterfall drops and bubbling rings have the very same keyed animation as the runtime prefab.
splash=collection('AmbientSplashes');rig=RIGS['WaterfallSplash'];source=COLLECTIONS['WaterfallSplash']
for points in flows:
 offset=Vector(points[-1])+Vector((0,0,.06))
 for src in source.objects:
  if src.type!='MESH':continue
  label=src['rig_part'];copy=src.copy();copy.data=src.data;copy.parent=None;splash.objects.link(copy);local=src.location.copy();node=rig['objects'][label];keys=CLIPS['WaterfallSplash'][0]['Tracks'];track=next(t for t in keys if t['Path'].endswith('_'+label))
  for key in track['Keys']:
   p=key['Position'];s=key['Scale'];copy.location=offset+Vector((p[0],p[2],p[1]))+local;copy.scale=(s[0],s[2],s[1]);frame=round(key['Time']*24)+1;copy.keyframe_insert('location',frame=frame);copy.keyframe_insert('scale',frame=frame)
  for curve in copy.animation_data.action.fcurves:
   curve.modifiers.new('CYCLES')
for name in RIGS:rest_rig(name,True)
for name,c in COLLECTIONS.items():
 if name not in ['Environment','Backdrop','PreviewUnits','RiverFlow','AmbientSplashes']:c.hide_viewport=True;c.hide_render=True
scene,camera=setup_render();scene.frame_end=240;scene.render.fps=24;scene.cycles.samples=16;scene.cycles.max_bounces=4;scene.cycles.diffuse_bounces=2;scene.cycles.glossy_bounces=2;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.08;scene.cycles.adaptive_min_samples=4;scene.render.resolution_x=1440;scene.render.resolution_y=1440;camera.data.ortho_scale=166;camera.location=(0,-126,174);camera.rotation_euler=(Vector((0,1,-2))-camera.location).to_track_quat('-Z','Y').to_euler();scene.frame_set(1)
scene['art_version']='0.6';scene['river_walls']=0;scene['concept_images']='3-16 in supplied design doc';bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
print('CELESTIAL06 MASTER SAVED',len(manifest['Models']),sum(m['Triangles'] for m in manifest['Models']),'triangles',len(RIGS),'rigs',sum(len(c) for c in CLIPS.values()),'clips',time.time()-start,flush=True)
