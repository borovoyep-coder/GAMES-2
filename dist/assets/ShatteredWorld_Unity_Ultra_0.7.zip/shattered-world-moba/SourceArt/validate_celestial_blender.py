"""Read back the actual .blend and compare it with native export metadata."""
import bpy,json,math
from pathlib import Path
root=Path(__file__).resolve().parents[1];source=root/'Assets/ShatteredWorld/Art/Source'
bpy.ops.wm.open_mainfile(filepath=str(root/'SourceArt/ValleyOfShards.blend'))
manifest=json.loads((source/'ArtManifest.json').read_text());layout=json.loads((source/'ValleyLayout.json').read_text());assert manifest['Version']=='0.6';assert bpy.context.scene['river_walls']==0
clipcount=0
for model in manifest['Models']:
 name=model['Name'];collection=bpy.data.collections.get(name);assert collection and any(o.type=='MESH' for o in collection.objects),name
 data=json.loads((source/model['File']).read_text())
 for clip in data.get('Clips',[]):
  actions=[a for a in bpy.data.actions if a.name.startswith(name+'.'+clip['Name']+'.')];assert actions,(name,clip['Name']);assert any(a.frame_range[1]>a.frame_range[0] for a in actions);clipcount+=1
print('PASS',len(manifest['Models']),'editable Blender collections and',clipcount,'saved animation clips',flush=True);assert clipcount==100
images=[i for i in bpy.data.images if i.source=='FILE'];assert len(images)==6 and all(i.packed_file for i in images)
water=next(o for o in bpy.data.collections['Environment'].objects if o.name.startswith('Straight turquoise river'))
assert len(water.data.vertices)==len(layout['River']['Points'])*3;assert water.data.vertices[0].co.z>water.data.vertices[-1].co.z+.1;assert water.data.uv_layers.active;assert bpy.data.materials['Water'].node_tree.animation_data
foam=bpy.data.collections['RiverFlow'];assert len(foam.objects)==64 and all(o.animation_data for o in foam.objects)
splash=bpy.data.collections['AmbientSplashes'];assert len(splash.objects)==90 and all(o.animation_data for o in splash.objects)
print('PASS 6 packed textures, finite straight downhill river, animated material UV, 64 foam meshes, 90 animated spray/ripple meshes',flush=True)
preview=bpy.data.collections['PreviewUnits'];towers=[o for o in preview.objects if o.name.startswith('Royal main energy crystal') and 'brilliant facet' not in o.name and o.dimensions.z<3];assert len(towers)==18,len(towers)
for slot in layout['TowerSlots']:
 p=slot['Position'];assert any(math.hypot(o.location.x-p['X'],o.location.y-p['Y'])<.001 for o in towers)
for name in ['FountainBlue','FountainRed']:
 c=bpy.data.collections[name];assert max(v.co.z for o in c.objects if o.type=='MESH' for v in o.data.vertices if 'Flat circular' in o.name)<=.6
tiles=[o for o in bpy.data.collections['Environment'].objects if o.name.startswith('Joined sandstone lane tile')]
assert len(tiles)>1000 and all(p.normal.z>.99 for o in tiles for p in o.data.polygons if p.area>.001 and max(o.data.vertices[i].co.z for i in p.vertices)-min(o.data.vertices[i].co.z for i in p.vertices)<.00001 and all(abs(o.data.vertices[i].co.z-.22)<.0001 for i in p.vertices))
print('PASS all 18 photo tower anchors, flat tiled fountains and upward-facing joined pavers',flush=True)
print('CELESTIAL BLENDER SOURCE VALIDATION COMPLETE',flush=True)
