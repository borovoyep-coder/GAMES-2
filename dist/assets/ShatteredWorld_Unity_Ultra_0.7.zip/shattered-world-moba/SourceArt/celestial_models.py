"""Original 0.6 Blender meshes, inspired by the supplied design concepts 1–16.
All armour, fur, leaves, wings, crystals and articulated parts are editable mesh geometry.
Front is Blender -Y; native animation export converts to Unity +Z.
"""
RIGS={};CLIPS={}
def start_rig(name,kind):
 collection(name);RIGS[name]={'pivots':{},'kind':kind,'clips':{}};return CURRENT

def articulated(label,pivot,make):
 before=set(CURRENT.objects);make()
 for obj in CURRENT.objects:
  if obj.type=='MESH' and obj not in before:obj['rig_part']=label
 RIGS[CURRENT.name]['pivots'][label]=pivot

def finish_rig(name):
 rig=RIGS[name];root=bpy.data.objects.new(name+'_Visual',None);CURRENT.objects.link(root);rig['objects']={'Visual':root};rig['root']=root
 for label,pivot in rig['pivots'].items():
  node=bpy.data.objects.new(name+'_'+label,None);CURRENT.objects.link(node);node.parent=root;node.location=pivot;rig['objects'][label]=node
 for obj in list(CURRENT.objects):
  if obj.type=='MESH':
   label=obj.get('rig_part','Body')
   if label not in rig['pivots']:raise ValueError((name,obj.name,label))
   obj.parent=rig['objects'][label];obj.location=Vector(obj.location)-Vector(rig['pivots'][label])
 return CURRENT

def plate(name,center,outline,depth,color,material='Metal',bevel=.025):
 # A silhouette designed in X/Z, with a genuine thickness and rounded hard edges.
 x,y,z=center;n=len(outline);verts=[(x+u,y+side*depth/2,z+v) for side in [-1,1] for u,v in outline]
 faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 obj=mesh_object(name,verts,faces,color,material)
 if bevel:
  mod=obj.modifiers.new('Sculpted armour chamfer','BEVEL');mod.width=min(bevel,depth*.20);mod.segments=2
  mod=obj.modifiers.new('Stable weighted plate normals','WEIGHTED_NORMAL');mod.keep_sharp=True
 return obj

def shield_shape(w,h):return [(-w*.5,h*.28),(-w*.33,h*.5),(w*.33,h*.5),(w*.5,h*.28),(w*.38,-h*.15),(0,-h*.55),(-w*.38,-h*.15)]
def armour(name,p,s,color='4D426D',material='Metal'):
 return plate(name,p,[(-s[0]*.5,-s[2]*.38),(-s[0]*.55,s[2]*.14),(-s[0]*.32,s[2]*.5),(s[0]*.32,s[2]*.5),(s[0]*.55,s[2]*.14),(s[0]*.5,-s[2]*.38),(0,-s[2]*.55)],s[1],color,material,min(.045,min(s)*.12))

def shard(name,p,r,h,color='purple',tilt=(0,0)):
 obj=crystal(name,p,r,h,color,tilt)
 # Delicate bright facets are real inset slivers, not a billboard glow.
 edge=crystal(name+' brilliant facet',(p[0]-r*.2,p[1]-r*.55,p[2]+h*.16),r*.10,h*.63,'F4D9FF' if color=='purple' else 'D5F8FF' if color in ['blue','azure','6AE4FF'] else 'FFF2BD',tilt,'Glow')
 return obj

def rock(name,p,s,color,seed=0):
 mesh=primitive_mesh('Rock sculpt base',ico=1).copy()
 for i,v in enumerate(mesh.vertices):
  v.co*=1+.18*math.sin(i*3.73+seed*1.7)
 for f in mesh.polygons:f.use_smooth=False
 obj=new_object(name,mesh,p,s);finish(obj,name,color,'Stone',.035);obj.rotation_euler=(seed*.13,seed*.071,seed*.39)
 return obj

def swept(name,points,radii,color,material='Creature',sides=10):
 verts=[];faces=[]
 for j,p in enumerate(points):
  direction=Vector(points[min(j+1,len(points)-1)])-Vector(points[max(0,j-1)]);q=direction.to_track_quat('Y','Z')
  rx,rz=radii[j] if isinstance(radii[j],tuple) else (radii[j],radii[j])
  for k in range(sides):
   a=k*2*pi/sides;v=q@Vector((math.cos(a)*rx,0,math.sin(a)*rz))+Vector(p);verts.append(v)
  if j:
   for k in range(sides):faces.append(((j-1)*sides+k,(j-1)*sides+(k+1)%sides,j*sides+(k+1)%sides,j*sides+k))
 faces.extend([tuple(reversed(range(sides))),tuple((len(points)-1)*sides+k for k in range(sides))]);return mesh_object(name,verts,faces,color,material)

def jewel_shield(p,w,h,team='blue',solar=False):
 plate('Golden angular shield rim',p,shield_shape(w,h),.21,'F0C56A')
 plate('Inset enamel shield',(p[0],p[1]-.13,p[2]+.015),shield_shape(w*.83,h*.85),.07,'DDD5B2' if solar else '494469')
 plate('Carved central shield spine',(p[0],p[1]-.19,p[2]),[(-w*.05,h*.3),(w*.05,h*.3),(w*.08,-h*.25),(0,-h*.43),(-w*.08,-h*.25)],.04,'goldlight')
 shard('Shield heart gem',(p[0],p[1]-.23,p[2]-h*.08),w*.16,h*.43,team,(pi/2,0))
 for side in [-1,1]:
  polyline('Shield gold engraved chevron',[(p[0]+side*w*.28,p[1]-.19,p[2]+h*.20),(p[0]+side*w*.10,p[1]-.20,p[2]+h*.02),(p[0],p[1]-.20,p[2]-h*.18)],.025,'goldlight','Metal')

def knight(name,red=False):
 team='red' if red else 'blue';start_rig(name,'guard')
 def body():
  armour('Knight sculpted gold cuirass',(0,0,1.28),(.99,.65,.90),'D6A64F');armour('Knight layered violet breastplate',(0,-.13,1.33),(.79,.49,.65),'595178');armour('Knight central breastplate facet',(0,-.40,1.38),(.29,.065,.46),'8F86AB');shard('Knight chest insignia',(0,-.44,1.13),.115,.38,team,(pi/2,0))
  box('Knight segmented gold belt',(0,0,.94),(1.03,.65,.16),'gold','Metal',.04)
  for side in [-1,1]:armour('Flared hip tasset',(side*.34,-.03,.78),(.44,.58,.38),'655B84')
  cloth('Knight pleated indigo cape','843D65' if red else '365E8D')
 articulated('Body',(0,0,1.1),body)
 def head():
  armour('Knight sculpted helmet shell',(0,0,2.0),(.77,.66,.69),'D7B164');armour('Knight violet angular helmet face',(0,-.08,2.02),(.66,.62,.53),'655A84')
  plate('Knight visor recess',(0,-.419,1.98),[(-.24,.045),(.24,.045),(.18,-.065),(-.18,-.065)],.04,'17273F','Obsidian',.01)
  for side in [-1,1]:box('Knight glowing visor eye',(side*.12,-.448,1.98),(.15,.025,.045),team,'Glow',.008)
  plate('Knight helmet nose ridge',(0,-.45,1.97),[(-.055,.19),(.055,.19),(.04,-.18),(-.04,-.18)],.04,'goldlight')
  shard('Tall swept crystal helmet crest',(0,.08,2.25),.20,.75,team,(-.30,0))
  for side in [-1,1]:armour('Angular helmet cheek plate',(side*.30,-.19,1.85),(.18,.23,.29),'gold')
 articulated('Head',(0,0,1.74),head)
 for side in [-1,1]:
  def leg(side=side):
   limb('Jointed dark knee',(side*.27,0,.88),(side*.29,-.06,.31),.14,'3E3A55','Metal',.11,8);armour('Gold shin greave',(side*.29,-.09,.45),(.35,.32,.53),'CDA65D');armour('Violet shin inset',(side*.29,-.275,.47),(.22,.04,.32),'655B82');box('Heavy bevelled knight sabaton',(side*.29,-.16,.14),(.40,.58,.26),'69627E','Metal',.07)
  articulated('LegL' if side<0 else 'LegR',(side*.27,0,.84),leg)
  def arm(side=side):
   armour('Knight broad gold pauldron',(side*.56,0,1.57),(.58,.62,.33),'E3BC69');armour('Knight violet shoulder inset',(side*.60,-.01,1.64),(.47,.54,.24),'70628C');limb('Knight upper arm',(side*.56,0,1.43),(side*.69,-.10,1.03),.13,'3A3B52','Metal',.11);armour('Knight golden wrist gauntlet',(side*.70,-.14,1.04),(.30,.30,.31),'D4AC5B')
  articulated('ArmL' if side<0 else 'ArmR',(side*.51,0,1.48),arm)
 def weapon():
  x=.73;y=-.22;plate('Broad polished sword blade',(x,y,1.47),[(-.13,-.42),(.13,-.42),(.14,.50),(0,.76),(-.14,.50)],.075,'D3E3ED');plate('Sword central bevel',(x,y-.05,1.53),[(-.026,-.42),(.026,-.42),(.025,.40),(0,.68),(-.025,.40)],.015,'F3FAFC');box('Swept gold sword crossguard',(x,y,1.04),(.53,.18,.13),'goldlight','Metal',.035);limb('Leather wrapped sword handle',(x,y,.77),(x,y,1.0),.065,'47364E','Creature',.065);shard('Sword pommel jewel',(x,y,.69),.075,.20,team)
 articulated('Weapon',(.70,-.14,1.04),weapon)
 articulated('Shield',(-.51,0,1.48),lambda:jewel_shield((-.70,-.35,1.2),.90,1.30,team))
 return finish_rig(name)

def spirit_mage(name,red=False):
 team='red' if red else 'blue';robe='703E72' if red else '4B508A';start_rig(name,'mage')
 def body():
  swept('Sculpted floating robe',[(0,.10,.40),(0,.04,.92),(0,0,1.55)],[(.55,.32),(.36,.27),(.37,.29)],robe,sides=12)
  for j in range(9):
   a=j*2*pi/9;pts=[(math.cos(a)*.40,math.sin(a)*.28,.91),(math.cos(a)*.57,math.sin(a)*.41,.39),(math.cos(a+.12)*.52,math.sin(a+.12)*.4,.18+(j%3)*.07)];swept('Mage flowing robe shard',pts,[.13,.12,.005],'76649C' if j%2 else robe,sides=5)
  armour('Caster layered gold vestment',(0,-.15,1.32),(.65,.32,.70),'D7B269');armour('Caster violet chest inset',(0,-.34,1.34),(.46,.06,.49),robe);shard('Caster chest rune',(0,-.40,1.16),.09,.39,team,(pi/2,0))
  for side in [-1,1]:
   plate('Long embroidered stole',(side*.25,-.28,.94),[(-.09,.48),(.09,.48),(.10,-.50),(0,-.62),(-.09,-.50)],.04,'gold');plate('Stole blue inset',(side*.25,-.31,.95),[(-.045,.43),(.045,.43),(.05,-.44),(0,-.53),(-.045,-.44)],.02,robe)
  cloth('Floating mage cape',robe)
 articulated('Body',(0,0,1.18),body)
 def head():
  swept('Peaked sculpted spirit hood',[(0,0,1.65),(0,.04,2.12),(0,.20,2.48),(0,.37,2.56)],[(.38,.30),(.38,.31),(.19,.18),(.015,.015)],robe,sides=10)
  plate('Hood deep shadow face',(0,-.305,1.97),[(-.24,-.18),(-.26,.13),(0,.30),(.26,.13),(.24,-.18),(0,-.26)],.04,'15243F','Obsidian')
  polyline('Hood golden open rim',[(-.25,-.35,1.78),(-.28,-.35,2.08),(0,-.35,2.30),(.28,-.35,2.08),(.25,-.35,1.78)],.025,'goldlight','Metal')
  for side in [-1,1]:box('Caster radiant spirit eyes',(side*.105,-.352,2.02),(.14,.03,.055),team,'Glow',.015)
 articulated('Head',(0,0,1.71),head)
 for side in [-1,1]:
  def arm(side=side):
   armour('Mage high gold pauldron',(side*.47,0,1.52),(.46,.53,.29),'E0BB6B');swept('Mage flared sleeve',[(side*.44,0,1.43),(side*.65,-.1,1.12)],[(.16,.17),(.22,.20)],robe,sides=8);armour('Mage gold glove',(side*.67,-.12,1.1),(.20,.24,.24),'gold')
  articulated('ArmL' if side<0 else 'ArmR',(side*.43,0,1.45),arm)
 def staff():
  limb('Caster ornate crystal staff',(.72,-.18,.22),(.72,-.18,2.26),.052,'D2AD61','Metal',.052,10)
  for side in [-1,1]:swept('Curved staff crystal bracket',[(.72+side*.05,-.18,2.05),(.72+side*.28,-.18,2.31),(.72+side*.23,-.18,2.60)],[(.05,.05),(.055,.055),(.015,.015)],'gold','Metal',6)
  shard('Caster hovering focus crystal',(.72,-.18,2.25),.21,.65,team)
  ring('Caster focus orbit',(.72,-.18,2.37),.27,.025,'goldlight','Glow',segments=32)
 articulated('Weapon',(.67,-.12,1.1),staff)
 return finish_rig(name)

def siege_engine(name,red=False):
 team='red' if red else 'blue';start_rig(name,'siege')
 def body():
  box('Heavy armoured siege chassis',(0,.05,.70),(1.72,2.16,.47),'433E5D','Metal',.12);armour('Faceted siege rear housing',(0,.56,1.04),(1.40,.85,.58),'6C5B83');box('Gold plated artillery deck',(0,.02,1.03),(1.76,1.84,.18),'D0A45A','Metal',.06)
  for side in [-1,1]:
   armour('Siege sloped side armour',(side*.73,-.08,.87),(.24,1.62,.62),'74618B');shard('Siege rear power crystal',(side*.48,.66,1.11),.17,.69,team,(-.22,side*.23));box('Siege gold side frame',(side*.90,0,.76),(.10,1.95,.14),'goldlight','Metal',.03)
 articulated('Body',(0,0,.72),body)
 for side in [-1,1]:
  for i,y in enumerate([-.71,.75]):
   def wheel(side=side,y=y):
    for x,r,d,c in [(side*.99,.48,.28,'353249'),(side*1.15,.43,.05,'C7A45E'),(side*1.19,.30,.045,'5C5375'),(side*1.22,.13,.07,'goldlight')]:o=cyl('Armoured artillery wheel',(x,y,.47),r,d,c,'Metal',16);o.rotation_euler.y=pi/2
    for j in range(8):a=j*pi/4;limb('Wheel engraved golden spoke',(side*1.23,y,.47),(side*1.23,y+math.cos(a)*.29,.47+math.sin(a)*.29),.025,'goldlight','Metal',.02)
   articulated(('WheelL' if side<0 else 'WheelR')+str(i),(side*.99,y,.47),wheel)
 def weapon():
  swept('Massive octagonal crystal cannon',[(0,.62,1.35),(0,-.42,1.50),(0,-1.36,1.60)],[(.42,.38),(.40,.37),(.50,.44)],'655278','Metal',8)
  for y in [.52,-.33,-1.20]:o=cyl('Cannon golden octagonal muzzle collar',(0,y,1.48-y*.08),.49,.14,'E8C477','Metal',8);o.rotation_euler.x=pi/2
  o=cyl('Cannon dark recessed bore',(0,-1.455,1.60),.36,.06,'1A2338','Obsidian',8);o.rotation_euler.x=pi/2
  shard('Radiant crystal cannon muzzle',(0,-1.47,1.60),.26,.55,team,(pi/2,0))
  for side in [-1,1]:limb('Cannon gold longitudinal rib',(side*.29,.35,1.7),(side*.34,-1.13,1.96),.045,'goldlight','Metal',.045)
 articulated('Weapon',(0,.46,1.35),weapon)
 return finish_rig(name)

def guardian(name,azure=False,solar=False):
 start_rig(name,'solar' if solar else 'golem');scale=1.65 if solar else 1;glow='goldlight' if solar else 'azure' if azure else 'lava';stone='C5C4B0' if solar else '727E89' if azure else '443A45';trim='DDB75D' if solar else '96B9CC' if azure else '9B5943'
 def P(p):return tuple(x*scale for x in p)
 def body():
  rock('Golem angular rock torso',P((0,.04,2.17)),P((1.12,.64,1.12)),stone,3)
  for j in range(3):armour('Overlapping chest stone armour',P((0,-.39,2.57-j*.37)),P((1.55-j*.17,.40,.53)),trim if j==0 else stone,'Metal' if solar else 'Stone')
  shard('Golem incandescent heart',P((0,-.65,2.08)),.26*scale,.78*scale,glow,(pi/2,0))
  for side in [-1,1]:
   for j in range(3):polyline('Glowing elemental chest fissure',[P((side*.17,-.64,2.48-j*.29)),P((side*.45,-.59,2.43-j*.29)),P((side*.74,-.40,2.53-j*.29))],.022*scale,glow,'Glow')
   rock('Floating hip stone plate',P((side*.55,0,1.32)),P((.45,.46,.4)),stone,side+4)
  if solar:
   for r in [1.0,1.24]:o=ring('Solar halo behind shoulders',(0,0,0),r*scale,.055*scale,'goldlight','Glow');o.location=P((0,.60,3.3));o.rotation_euler.x=pi/2
 articulated('Body',P((0,0,2.0)),body)
 def head():
  rock('Carved guardian head',P((0,-.10,3.27)),P((.48,.43,.52)),stone,8);armour('Golem forehead crest',P((0,-.37,3.51)),P((.55,.19,.43)),trim,'Metal' if solar else 'Stone')
  for side in [-1,1]:box('Golem radiant carved eye',P((side*.18,-.49,3.28)),P((.22,.06,.09)),glow,'Glow',.02);rock('Golem cheek plate',P((side*.33,-.32,3.10)),P((.18,.23,.22)),stone,5)
  box('Guardian stone lower jaw',P((0,-.28,2.99)),P((.52,.38,.23)),stone,'Stone',.05)
  if solar:
   for j in range(5):shard('Golden solar crown',P(((j-2)*.19,0,3.69)),.09*scale,(.42+.22*(1-abs(j-2)/2))*scale,'goldlight')
  else:shard('Elemental crown crystal',P((0,.03,3.62)),.20*scale,.63*scale,glow)
 articulated('Head',P((0,0,2.98)),head)
 for side in [-1,1]:
  def leg(side=side):
   rock('Golem upper leg block',P((side*.50,.07,1.15)),P((.35,.39,.63)),stone,3+side);rock('Golem huge plated foot',P((side*.60,-.24,.30)),P((.46,.65,.31)),stone,4+side);armour('Golem angular knee guard',P((side*.55,-.36,.79)),P((.53,.20,.52)),trim,'Metal' if solar else 'Stone');limb('Golem glowing knee joint',P((side*.54,-.18,.66)),P((side*.54,-.18,1)),.10*scale,glow,'Glow',.10*scale)
  articulated('LegL' if side<0 else 'LegR',P((side*.48,0,1.38)),leg)
  def arm(side=side):
   rock('Golem massive layered shoulder',P((side*1.05,0,2.73)),P((.66,.63,.62)),stone,10+side);armour('Golem shoulder overplate',P((side*1.13,-.10,2.92)),P((.92,.75,.48)),trim,'Metal' if solar else 'Stone');rock('Golem lower arm',P((side*1.43,-.13,1.95)),P((.48,.50,.72)),stone,14+side)
   for j in range(3):shard('Golem shoulder crystal spikes',P((side*(.89+j*.28),.12,3.02)),(.14 if solar else .21)*scale,(.48+(j%2)*.23)*scale,glow,(0,side*.35))
   rock('Golem monumental closed fist',P((side*1.61,-.28,1.37)),P((.60,.57,.52)),stone,20+side)
   for j in range(4):armour('Golem articulated finger plate',P((side*1.61+(j-1.5)*.21,-.73,1.36)),P((.19,.20,.42)),trim,'Metal' if solar else 'Stone')
   for j in range(2):polyline('Arm elemental fissure',[P((side*1.1,-.45,2.60-j*.55)),P((side*1.45,-.56,2.35-j*.55)),P((side*1.62,-.52,2.45-j*.55))],.025*scale,glow,'Glow')
  articulated('ArmL' if side<0 else 'ArmR',P((side*.93,0,2.72)),arm)
 if solar:articulated('Shield',P((-1,0,2.7)),lambda:jewel_shield(P((-1.7,-.80,1.85)),1.5*scale,2.5*scale,'goldlight',True))
 return finish_rig(name)

def moon_wolf():
 name='MoonWolf';start_rig(name,'wolf')
 def body():
  swept('Wolf sculpted muscular body',[(0,.9,1.30),(0,.48,1.43),(0,-.42,1.62),(0,-.72,1.68)],[(.35,.42),(.47,.49),(.50,.61),(.40,.47)],'C1D3DF',sides=12)
  for j in range(7):
   y=.85-j*.23;shard('Wolf ice crystal dorsal mane',(0,y,1.78+.17*math.sin(j)),.15,.55+(j%3)*.16,'blue',(-.40,0))
  for side in [-1,1]:
   for j in range(8):shard('Wolf angular silver flank fur',(side*.34,.85-j*.19,1.56),.14,.30,'C5D9E5',(.45,side*.95))
  swept('Wolf long feathered tail',[(0,.78,1.32),(.12,1.35,1.25),(.30,1.83,1.58),(.25,2.15,1.68)],[.23,.28,.20,.015],'A6C4D7',sides=8)
 articulated('Body',(0,0,1.35),body)
 def head():
  swept('Wolf raised neck',[(0,-.58,1.55),(0,-.88,2.10)],[(.40,.44),(.32,.37)],'D5E2E8',sides=10);rock('Wolf shaped angular skull',(0,-1.02,2.12),(.40,.41,.36),'C4D9E5',2)
  swept('Wolf long tapered muzzle',[(0,-1.02,2.03),(0,-1.59,1.98)],[(.28,.23),(.15,.13)],'D7E5EB',sides=8);box('Wolf obsidian nose',(0,-1.64,2.01),(.25,.13,.16),'25334C','Creature',.035)
  for side in [-1,1]:
   plate('Wolf pointed ear',(side*.25,-.92,2.47),[(-.14,-.15),(.14,-.15),(side*.035,.43)],.14,'AFCBDB');box('Wolf luminous eye',(side*.29,-1.22,2.20),(.10,.12,.065),'azure','Glow',.018)
   for j in range(4):shard('Wolf cheek ruff',(side*.28,-.82+j*.10,1.97),.11,.32,'E0E9EA',(.35,side*.8))
   shard('Wolf bright fang',(side*.13,-1.45,1.88),.034,.16,'lightstone',(pi,0))
 articulated('Head',(0,-.65,1.75),head)
 for side in [-1,1]:
  for j,y in enumerate([-.48,.65]):
   def leg(side=side,y=y,j=j):
    swept('Wolf jointed leg',[(side*.30,y,1.39),(side*.38,y+.12,.72),(side*.39,y-.12,.20)],[(.19,.22),(.12,.14),(.10,.10)],'9CBCCF',sides=8);box('Wolf broad padded paw',(side*.39,y-.20,.12),(.29,.43,.23),'C9DCE5','Creature',.07)
    for k in range(3):limb('Wolf ivory claw',(side*.39+(k-1)*.075,y-.38,.14),(side*.39+(k-1)*.075,y-.47,.06),.025,'lightstone','Creature',.005)
   articulated(('LegL' if side<0 else 'LegR')+str(j),(side*.30,y,1.35),leg)
 return finish_rig(name)

def stone_centipede():
 name='StoneCentipede';start_rig(name,'centipede')
 def body():
  for j in range(8):
   y=.9-j*.36;rock('Centipede layered stone carapace',(0,y,.69),(.48-j*.014,.29,.33),'6E7768',j+3);armour('Centipede overlapping dorsal plate',(0,y,.88),(.71-j*.018,.45,.25),'A6AA7A','Stone');shard('Centipede jade dorsal mineral',(0,y+.04,1.0),.09,.20+(j%2)*.17,'9ACD5D')
  for side in [-1,1]:
   swept('Centipede curved mandible',[(side*.17,-1.77,.64),(side*.35,-2.04,.62),(side*.24,-2.18,.72)],[.07,.07,.005],'D8CE9D',sides=6);shard('Centipede glowing eye',(side*.19,-1.71,.78),.04,.12,'lava',(pi/2,0))
 articulated('Body',(0,0,.70),body)
 for side in [-1,1]:
  for j in range(7):
   y=.85-j*.36
   def leg(side=side,y=y,j=j):
    swept('Centipede segmented hooked leg',[(side*.34,y,.68),(side*.68,y+.12,.43),(side*.81,y-.09,.04)],[.075,.065,.01],'A39B69',sides=6)
   articulated(('LegL' if side<0 else 'LegR')+str(j),(side*.34,y,.68),leg)
 return finish_rig(name)

def rift_ghost():
 name='RiftGhost';start_rig(name,'wraith')
 def body():
  swept('Wraith tapered spectral torso',[(0,.13,.40),(0,0,1.28),(0,0,2.03)],[(.06,.06),(.47,.31),(.49,.33)],'655292',sides=10)
  for j in range(9):
   a=j*2*pi/9;swept('Wraith ethereal flame ribbon',[(math.cos(a)*.37,math.sin(a)*.27,1.47),(math.cos(a)*.60,math.sin(a)*.42,.77),(math.cos(a+.4)*.35,math.sin(a+.4)*.30,.18)],[(.13,.10),(.15,.08),(.005,.005)],'B687F5' if j%2 else '8362BC','Creature',5)
  armour('Wraith gilded chest plate',(0,-.27,1.85),(.65,.23,.48),'B7A174');shard('Wraith radiant chest tear',(0,-.42,1.60),.13,.43,'purple',(pi/2,0))
 articulated('Body',(0,0,1.5),body)
 def head():
  swept('Wraith towering pointed hood',[(0,0,1.96),(0,.03,2.39),(0,.25,2.78)],[(.35,.31),(.38,.34),(.02,.02)],'493A68',sides=10);plate('Wraith faceless void',(0,-.32,2.30),[(-.25,-.17),(-.26,.15),(0,.33),(.26,.15),(.25,-.17),(0,-.26)],.04,'241E3D','Obsidian')
  for side in [-1,1]:box('Wraith violet gaze',(side*.11,-.36,2.34),(.11,.025,.045),'D8B7FF','Glow',.01)
 articulated('Head',(0,0,2.0),head)
 for side in [-1,1]:
  def arm(side=side):
   armour('Wraith ancient gold pauldron',(side*.51,0,2.02),(.49,.46,.29),'B39B69');swept('Wraith spectral claw arm',[(side*.49,0,1.92),(side*.79,-.1,1.52),(side*.75,-.48,1.25)],[.16,.12,.10],'8266A9',sides=8)
   for j in range(3):swept('Wraith long hooked finger',[(side*.75+(j-1)*.10,-.45,1.30),(side*.77+(j-1)*.12,-.69,1.19),(side*.74+(j-1)*.12,-.77,1.32)],[.04,.033,.004],'C4A4E7',sides=5)
  articulated('ArmL' if side<0 else 'ArmR',(side*.48,0,2),arm)
 return finish_rig(name)

def crystal_crab():
 name='CrystalCrab';start_rig(name,'crab')
 def body():
  rock('Crab broad golden carapace',(0,.12,1.08),(1.05,.83,.47),'D6A536',4)
  for j in range(3):armour('Crab overlapping sun armour',(0,.43-j*.40,1.25),(1.65-j*.12,.52,.30),'ECC460')
  shard('Crab large amethyst crown',(0,.08,1.48),.29,.75,'purple')
  for side in [-1,1]:limb('Crab eye stalk',(side*.34,-.56,1.2),(side*.38,-.75,1.52),.06,'gold','Metal',.045);sphere('Crab luminous eye',(side*.38,-.75,1.53),(.10,.10,.08),'purple','Glow',0)
 articulated('Body',(0,0,1.0),body)
 for side in [-1,1]:
  for j in range(3):
   y=.60-j*.48
   def leg(side=side,y=y):swept('Crab golden articulated leg',[(side*.71,y,1),(side*1.26,y+.12,.65),(side*1.40,y-.18,.08)],[.13,.105,.018],'DBAA40','Metal',6)
   articulated(('LegL' if side<0 else 'LegR')+str(j),(side*.71,y,1),leg)
  def claw(side=side):
   swept('Crab heavy claw arm',[(side*.78,-.34,1.08),(side*1.35,-.85,1.24),(side*1.42,-1.28,1.44)],[.19,.23,.34],'DDAE3D','Metal',8)
   for sign in [-1,1]:swept('Crab sculpted open pincer',[(side*1.42,-1.19,1.43),(side*(1.42+sign*.26),-1.59,1.63),(side*(1.42+sign*.12),-1.89,1.60)],[.22,.15,.015],'ECC460','Metal',8)
   shard('Crab pincer gemstone',(side*1.42,-1.13,1.70),.13,.32,'purple')
  articulated('ArmL' if side<0 else 'ArmR',(side*.79,-.33,1.1),claw)
 return finish_rig(name)

def observer():
 name='ObserverFirefly';start_rig(name,'fly')
 def body():
  sphere('Observer floating turquoise eye',(0,-.05,1.55),(.42,.30,.43),'76D7D4','Creature',2);sphere('Observer luminous iris',(0,-.32,1.57),(.22,.045,.27),'azure','Glow',2);sphere('Observer dark slit pupil',(0,-.37,1.57),(.065,.018,.20),'19354D','Obsidian',1)
  o=ring('Observer gold eye armature',(0,0,0),.55,.065,'goldlight','Metal',segments=48);o.location=(0,-.05,1.55);o.rotation_euler.x=pi/2
  shard('Observer upper focus',(0,0,2.14),.13,.43,'azure');shard('Observer lower focus',(0,0,1.0),.09,.31,'azure',(pi,0))
 articulated('Body',(0,0,1.55),body)
 for side in [-1,1]:
  def wing(side=side):
   for j in [-1,1]:
    pts=[(side*.35,.07,1.59),(side*1.42,j*.30,1.75),(side*1.72,j*.65,1.62),(side*.81,j*.53,1.42)];mesh_object('Observer leaf shaped luminous wing',pts,[(0,1,2,3)],'72CFC3','Creature');polyline('Observer gold wing vein',[pts[0],pts[1],pts[2]],.022,'goldlight','Metal');polyline('Observer luminous wing nerve',[pts[0],pts[3],pts[2]],.015,'azure','Glow')
  articulated('WingL' if side<0 else 'WingR',(side*.35,.07,1.59),wing)
 return finish_rig(name)

def rift_ray():
 name='RiftRay';start_rig(name,'ray')
 def body():
  swept('Ray elegant fusiform body',[(0,-1.05,1.30),(0,-.4,1.53),(0,.55,1.40),(0,1.04,1.26)],[(.15,.10),(.49,.25),(.35,.17),(.08,.08)],'469AB5',sides=12);swept('Ray long streaming tail',[(0,.80,1.31),(0,1.73,1.19),(.15,2.4,1.49),(.35,2.97,1.62)],[.12,.08,.04,.005],'72C2D7',sides=8)
  for j in range(4):shard('Ray dorsal crystal',(0,-.3+j*.30,1.64),.12,.33+(j%2)*.18,'azure')
  for side in [-1,1]:sphere('Ray sapphire eye',(side*.20,-.76,1.42),(.07,.10,.06),'azure','Glow',1)
 articulated('Body',(0,0,1.4),body)
 for side in [-1,1]:
  def wing(side=side):
   verts=[]
   for row in range(5):
    t=row/4
    for j in range(8):
     u=j/7;verts.append((side*(.32+t*(2.35-.55*math.sin(u*pi))),-.65+u*1.65+t*.25,1.45+.60*t*t+.17*math.sin(u*pi)))
   faces=[(r*8+j,r*8+j+1,(r+1)*8+j+1,(r+1)*8+j) for r in range(4) for j in range(7)];mesh_object('Ray curved radiant wing membrane',verts,faces,'67B9D2','Creature')
   for j in [0,2,4,7]:polyline('Ray glowing anatomical wing veins',[verts[r*8+j] for r in range(5)],.020,'azure','Glow')
   polyline('Ray luminous swept wing edge',[verts[4*8+j] for j in range(8)],.026,'A0F2F5','Glow')
  articulated('WingL' if side<0 else 'WingR',(side*.32,0,1.45),wing)
 return finish_rig(name)

def night_dragon():
 name='NightLeviathan';start_rig(name,'dragon')
 def body():
  points=[(1.7,1.5,.6),(2.0,.7,.9),(1.50,.05,1.20),(.55,-.10,1.6),(-.15,.35,1.65),(-.65,1.1,1.4),(-.2,1.9,1.10),(.7,2.2,.80),(1.0,2.9,.66),(.55,3.55,.73),(-.2,3.9,1.05)]
  radii=[.65,.77,.85,.84,.78,.65,.54,.42,.31,.20,.015];swept('Leviathan coiled obsidian serpent body',points,radii,'40344E','Obsidian',12)
  for j,p in enumerate(points[:-1]):
   shard('Leviathan amethyst dorsal blade',(p[0],p[1],p[2]+radii[j]*.72),.20*(1-j*.05),.88-j*.05,'purple',(.17,0));rock('Leviathan overlapping dorsal armour',(p[0],p[1],p[2]+radii[j]*.27),(radii[j]*.85,radii[j]*.73,radii[j]*.46),'67506F',j)
  for side in [-1,1]:
   swept('Leviathan powerful foreleg',[(.45+side*.55,-.04,1.67),(.45+side*1.05,-.51,.64),(.45+side*1.29,-1.05,.27)],[.22,.18,.13],'51415F','Obsidian',8)
   for j in range(3):swept('Leviathan hooked talon',[(.45+side*1.29+(j-1)*.15,-1.04,.30),(.45+side*1.30+(j-1)*.15,-1.43,.15)],[.06,.005],'D3B9DF',sides=6)
 articulated('Body',(0,0,1.5),body)
 def head():
  swept('Leviathan ascending curved neck',[(.55,-.1,1.65),(.65,-.70,2.32),(.55,-1.20,2.85)],[.68,.48,.44],'51405F','Obsidian',12);rock('Leviathan chiselled dragon skull',(.55,-1.48,2.85),(.62,.72,.48),'70557D',5)
  swept('Leviathan elongated predatory muzzle',[(.55,-1.59,2.72),(.55,-2.40,2.56)],[(.47,.25),(.29,.16)],'4A3656','Obsidian',10);armour('Leviathan sculpted lower jaw',(.55,-2.04,2.33),(.69,.95,.18),'9A719F','Creature')
  for side in [-1,1]:
   box('Leviathan brilliant dragon eye',(.55+side*.41,-1.74,3.00),(.17,.15,.095),'D29CFF','Glow',.03)
   swept('Leviathan long swept crown horn',[(.55+side*.40,-1.1,3.09),(.55+side*.69,-.64,3.68),(.55+side*.78,-.20,4.12)],[.18,.12,.005],'C9A3D9','Creature',7)
   for j in range(4):shard('Leviathan visible ivory fang',(.55+side*.25,-2.36+j*.18,2.52),.05,.25,'lightstone',(pi,0))
   for j in range(3):shard('Leviathan cheek crystal',(.55+side*.49,-1.25+j*.17,2.78),.11,.48,'purple',(.25,side*.85))
 articulated('Head',(.55,-.65,2.3),head)
 for side in [-1,1]:
  def wing(side=side):
   p=[(side*.48,.20,2.0),(side*1.2,.18,3.13),(side*3.35,.30,4.7),(side*4.08,.91,3.08),(side*3.25,1.20,2.50),(side*3.64,2.14,1.65),(side*2.46,2.07,1.79),(side*2.20,2.90,1.14),(side*.55,1.68,1.68),(side*1.74,1.28,2.72)]
   faces=[(0,1,9),(1,2,9),(2,3,9),(3,4,9),(4,5,9),(5,6,9),(6,7,9),(7,8,9),(8,0,9)];mesh_object('Leviathan sculpted scalloped wing membrane',p,faces,'87539F','Creature');polyline('Leviathan obsidian leading wing bone',p[:4],.12,'43324F','Obsidian')
   for j in [3,5,7]:polyline('Leviathan anatomical wing fingers',[p[0],p[9],p[j]],.075,'53385F','Obsidian');polyline('Leviathan luminous wing bloodlines',[(x,y-.025,z+.035) for x,y,z in [p[0],p[9],p[j]]],.022,'C082F4','Glow')
  articulated('WingL' if side<0 else 'WingR',(side*.48,.20,2.0),wing)
 return finish_rig(name)

def celestial_building(name,red=False,core=False):
 start_rig(name,'core' if core else 'tower');team='red' if red else 'blue';r=2.9 if core else 1.58
 def body():
  lathe('Royal stepped sandstone plinth',[(0,r),(.16,r),(.23,r*.91),(.43,r*.91),(.51,r*.76),(.63,r*.76)],'D6C8A5',n=24)
  for z,rr in [(.18,r*.97),(.48,r*.83),(.66,r*.75)]:ornament_ring((0,0,z),rr,'goldlight',24 if core else 16)
  if core:
   lathe('Nexus faceted inner dais',[(.58,2.05),(.83,2.05),(1.02,1.67)],'A99E8A',n=16)
   for j in range(8):
    a=j*pi/4;x,y=math.cos(a),math.sin(a)
    for k in range(3):box('Nexus stepped flying buttress',(x*(2.3-k*.17),y*(2.3-k*.17),.70+k*.24),(.42,.55,.24),'D9C9A3','Stone',.05,a)
    swept('Nexus curved gilded support',[(x*2.40,y*2.40,.8),(x*2.02,y*2.02,2.40),(x*1.32,y*1.32,3.47)],[(.12,.12),(.10,.10),(.04,.04)],'D6B15F','Metal',8)
    armour('Nexus royal shrine pylon',(x*1.92,y*1.92,1.93),(.52,.53,2.0),'D1C4A7','Stone');shard('Nexus flanking crystal',(x*1.92,y*1.92,2.87),.26,1.33,team)
  else:
   lathe('Tower carved rising stone shaft',[(.60,1.04),(.80,.93),(1.65,.72),(2.05,.91),(2.22,1.11),(2.40,1.11)],'D1C1A0',n=16)
   for z,rr in [(.79,.94),(2.10,.96),(2.42,1.12)]:ornament_ring((0,0,z),rr,'gold',16)
   for j in range(8):
    a=j*pi/4;x,y=math.cos(a),math.sin(a);limb('Tower carved vertical flute',(x*.85,y*.85,.88),(x*.74,y*.74,1.9),.055,'F3E1B9','Stone',.05);shard('Tower inlaid magic rune',(x*.78,y*.78,1.23),.06,.40,team)
 articulated('Body',(0,0,.5),body)
 def focus():
  z=1.0 if core else 2.44;shard('Royal main energy crystal',(0,0,z),.92 if core else .42,5.85 if core else 1.91,team)
  n=6 if core else 3
  for j in range(n):
   a=j*2*pi/n;rr=1.06 if core else .68;shard('Orbiting royal energy shard',(math.cos(a)*rr,math.sin(a)*rr,z+.48),.20 if core else .14,1.8 if core else .78,team,(.15*math.sin(a),-.15*math.cos(a)))
   if not core:swept('Tower delicate golden crystal cradle',[(math.cos(a)*1.04,math.sin(a)*1.04,2.22),(math.cos(a)*.88,math.sin(a)*.88,2.89),(math.cos(a)*.50,math.sin(a)*.50,3.56)],[.075,.065,.02],'goldlight','Metal',7)
  ring('Energy orbit firing ring',(0,0,4.75 if core else 3.15),1.05 if core else .55,.045,team,'Glow',segments=48)
 articulated('Focus',(0,0,3.5 if core else 2.8),focus)
 return finish_rig(name)

def celestial_bridge():
 collection('Bridge')
 # Coordinates and span match the dynamic-map oriented deck: x width, y across river.
 for j in range(19):
  y=-6.75+j*.75;z=.18+.37*(1-(y/7.2)**2)
  for k in range(5):box('Bridge cut sandstone deck tile',((k-2)*.91,y,z),( .87,.71,.18),'D7C6A8','Stone',.035)
  box('Bridge central divine inlay',(0,y,z+.103),(.09,.71,.018),'F6D575','Glow',.005)
 for side in [-1,1]:
  points=[(side*2.32,-7+j*.5,.65+.37*(1-((-7+j*.5)/7.2)**2)) for j in range(29)]
  swept('Bridge carved arch voussoir beam',points,[(.20,.28)]*29,'B1A388','Stone',8)
  for j in range(10):
   y=-6.75+j*1.5;z=.65+.37*(1-(y/7.2)**2);box('Bridge sculpted parapet post',(side*2.32,y,z+.38),(.27,.28,.79),'E6D3AF','Stone',.035)
  polyline('Bridge elegant gilded handrail',[(x,y,z+.80) for x,y,z in points],.065,'goldlight','Metal')
  for y in [-6.7,6.7]:
   lathe('Bridge crystal beacon pillar',[(0,.32),(.8,.24),(1.02,.38)],'D9C7A3',n=12).location=(side*2.33,y,.26);shard('Bridge azure guiding beacon',(side*2.33,y,1.32),.17,.71,'blue')
 return CURRENT

def crystal_gate():
 name='CrystalGate';start_rig(name,'crystal')
 for j,(x,y,z,r,h) in enumerate([(0,0,.08,.60,3.0),(-.72,.08,.02,.34,1.91),(.71,.07,.02,.38,2.17),(-.32,-.44,.04,.27,1.38),(.34,.40,.02,.29,1.61)]):
  def make(x=x,y=y,z=z,r=r,h=h,j=j):
   shard('Amethyst passage crystal',(x,y,z),r,h,'purple',(0,(j-2)*.10));rock('Crystal basal quartz',(x,y,.07),(r*.78,r*.64,.16),'827096',j)
  articulated('Shard'+str(j),(x,y,z),make)
 return finish_rig(name)

def tiled_fountain(name,red=False):
 collection(name);tile='D6C2A5';cyl('Flat circular tiled spawn surface',(0,0,.04),4.8,.08,tile,'Stone',64)
 # Clipped square pavers use the same single material and colour as the lane roads.
 for ix in range(-5,6):
  for iy in range(-5,6):
   x=ix*.84;y=iy*.84
   if math.hypot(x,y)>4.12:continue
   box('Fountain matching lane sandstone tile',(x,y,.105),(.80,.80,.07),tile,'Stone',.018)
 ornament_ring((0,0,.095),4.66,'goldlight',32);ring('Fountain subtle resource aura',(0,0,.10),4.47,.035,'red' if red else 'blue','Glow')
 for obj in CURRENT.objects:obj.location.z+=.12
 return CURRENT

def tree(p,height=5.5,variant=0):
 x,y=p;cyl('Tree tapering natural bark trunk',(x,y,height*.22),.17,height*.44,'71553F','Wood',8,.10)
 for k in range(5):
  z=height*(.21+k*.145);r=height*(.29-k*.045);h=height*(.36-k*.025);verts=[];faces=[];n=16
  for row,(rr,zz) in enumerate([(r*.76,z),(r,z+h*.22),(r*.66,z+h*.53),(r*.04,z+h)]):
   for j in range(n):
    a=j*2*pi/n+k*.42+variant*.31;rad=rr*(1+.15*math.sin(j*2.7+k+variant));verts.append((x+math.cos(a)*rad,y+math.sin(a)*rad,zz+(.05*height*math.sin(j*2.3+k) if row<2 else 0)))
   if row:
    for j in range(n):faces.append(((row-1)*n+j,(row-1)*n+(j+1)%n,row*n+(j+1)%n,row*n+j))
  obj=mesh_object('Sculpted irregular fir foliage tier',verts,faces,['255C43','326D49','408254','55955D','77A869'][k],'Foliage')
  for face in obj.data.polygons:face.use_smooth=True
 for side in [-1,1]:limb('Tree exposed gnarled root',(x,y,.1),(x+side*.5,y+.23,.02),.085,'wood','Wood',.018,6)

def bush_geometry(x,y,scale=1):
 for j in range(19):
  a=j*2.399;rad=(.14+(j%4)*.14)*scale;h=(.70+(j%6)*.12)*scale;cx=x+math.cos(a)*rad;cy=y+math.sin(a)*rad;w=.11*scale;dx,dy=math.cos(a),math.sin(a);sx,sy=-dy*w,dx*w;lean=.40*scale
  verts=[(cx-sx*.3,cy-sy*.3,.02),(cx+sx*.3,cy+sy*.3,.02),(cx+dx*lean+sx,cy+dy*lean+sy,h*.55),(cx+dx*lean,cy+dy*lean,h*.64),(cx+dx*lean-sx,cy+dy*lean-sy,h*.55),(cx+dx*lean*1.4,cy+dy*lean*1.4,h)]
  mesh_object('Bright lime folded broadleaf brush',verts,[(0,1,3),(1,2,3),(2,5,3),(5,4,3),(4,0,3)],['8CB43E','B8D568','A2C94D','74A440'][j%4],'Foliage')

# Clips are keyed in Blender, then the same transforms are exported to native Unity AnimationClips.
def animate_rig(name):
 rig=RIGS[name];kind=rig['kind'];scene=bpy.context.scene;scene.render.fps=24;clips=[]
 specs=[('Idle',1.6,True),('Walk',.8,True),('Attack',.8,False),('Death',1.35,False),('Spawn',.8,False)]
 if kind in ['tower','core']:specs=[('Idle',1.6,True),('Attack',.8,False),('Death',1.35,False),('Spawn',.8,False)]
 if kind=='crystal':specs=[('Idle',1.6,True),('Death',1.35,False),('Spawn',.8,False)]
 if kind=='splash':specs=[('Idle',1.6,True)]
 for clip,duration,loop in specs:
  end=round(duration*24)+1;actions={};tracks=[]
  for label,node in rig['objects'].items():
   node.animation_data_clear();action=bpy.data.actions.new(name+'.'+clip+'.'+label);action.use_fake_user=True;node.animation_data_create();node.animation_data.action=action;actions[label]=action
   rest=Vector((0,0,0) if label=='Visual' else rig['pivots'][label]);samples=[]
   for frame in range(1,end+1):
    t=(frame-1)/(end-1);phase=t*2*pi;position=rest.copy();rotation=Vector((0,0,0));scale=Vector((1,1,1));flying=kind in ['mage','wraith','ray','fly'];sign=-1 if 'L' in label else 1
    if clip=='Idle':
     if label=='Visual' and kind not in ['tower','core','crystal','splash']:position.z+=math.sin(phase)*(.085 if flying else .025)
     if label=='Head':rotation.z=math.sin(phase)*.04
     if label.startswith('Wing'):rotation.y=sign*math.sin(phase)*(.20 if kind=='dragon' else .28)
     if label=='Focus':rotation.z=phase;scale*=1+.025*math.sin(phase)
     if kind=='crystal' and label.startswith('Shard'):position.z+=.03*math.sin(phase+int(label[-1]))
     if kind=='splash' and label.startswith('Drop'):
      j=int(label[4:]);u=(t+j*.137)%1;angle=j*2.399;position+=Vector((math.cos(angle)*u*.8,math.sin(angle)*u*.8,math.sin(u*pi)*(.8+j%3*.3)));scale*=max(.02,math.sin(u*pi))
     if kind=='splash' and label.startswith('Ripple'):
      u=(t+int(label[-1])*.25)%1;scale=Vector((.25+u*2.6,.25+u*2.6,max(.025,1-u)))
    elif clip=='Walk':
     if label.startswith('Leg'):
      index=int(label[-1]) if label[-1].isdigit() else 0;rotation.x=math.sin(phase+index*pi/2)*.52*sign
     if label.startswith('Arm') or label in ['Weapon','Shield']:rotation.x=math.sin(phase)*.24*sign
     if label.startswith('Wheel'):rotation.x=-phase
     if label.startswith('Wing'):rotation.y=math.sin(phase)*.40*sign
     if label=='Visual':position.z+=abs(math.sin(phase))*(.06 if not flying else .13);rotation.y=math.sin(phase)*.035
     if kind=='centipede' and label=='Body':rotation.z=math.sin(phase)*.08
    elif clip=='Attack':
     # Launch/impact pose at 0.24 s for guards/casters, 0.40 s for siege, 0.32 s for structures.
     peak=.5 if kind=='siege' else .40 if kind in ['tower','core'] else .30;wind=math.sin(min(1,t/peak)*pi/2) if t<peak else math.cos(min(1,(t-peak)/(1-peak))*pi/2)
     if label=='Visual' and kind not in ['tower','core']:rotation.x=-.12*math.sin(t*pi);position.y-=.10*math.sin(t*pi)
     if label in ['ArmR','Weapon']:rotation.x=(-1.15 if t<peak else .70)*wind;rotation.y=-.17*wind
     if label=='ArmL' and kind in ['golem','solar','crab','wraith']:rotation.x=-.75*wind
     if label=='Head' and kind in ['wolf','dragon','centipede']:rotation.x=-.35*wind;position.y-=.26*wind
     if flying and label=='Weapon':rotation.x=-.60*math.sin(t*pi)
     if kind=='siege' and label=='Weapon':position.y+=.42*max(0,1-abs(t-.50)/.22);rotation.x=-.13*wind
     if label.startswith('Wing'):rotation.y=sign*.4*wind
     if label=='Focus':scale*=1+.16*wind;position.z+=.20*wind;rotation.z=wind*.35
    elif clip=='Death':
     fall=min(1,t/.68);fall=fall*fall*(3-2*fall)
     if label=='Visual':
      if kind not in ['crystal','tower','core']:rotation.x=1.35*fall;position.y+=.2*fall
      if flying:position.z-=.65*fall
      scale*=max(.015,1-max(0,t-.80)*4.9)
     if kind=='crystal' and label.startswith('Shard'):
      j=int(label[-1]);a=j*2.399;position+=Vector((math.cos(a)*fall*2.2,math.sin(a)*fall*2.2,math.sin(fall*pi)*1.6-fall*.35));rotation=Vector((fall*(j-2)*.8,fall*1.5,fall*j));scale*=max(.02,1-t*.9)
     if label.startswith('Arm') or label in ['Shield','Weapon']:rotation.y=sign*.60*fall
     if kind in ['tower','core'] and label=='Body':position.z-=fall*.45;rotation.x=.14*fall
     if kind in ['tower','core'] and label=='Focus':position.z+=math.sin(fall*pi)*.65;scale*=max(.02,1-fall)
    elif clip=='Spawn':
     grow=min(1,t/.65);grow=grow*grow*(3-2*grow)
     if label=='Visual':scale*=max(.025,grow);position.z+=(1-grow)*(.7 if flying else .32)
     if kind=='crystal' and label.startswith('Shard'):position.z-=(1-grow)*(1.2+int(label[-1])*.2);rotation.z=(1-grow)*.7
    node.location=position;node.rotation_euler=rotation;node.scale=scale
    node.keyframe_insert('location',frame=frame);node.keyframe_insert('rotation_euler',frame=frame);node.keyframe_insert('scale',frame=frame)
    q=node.rotation_euler.to_quaternion();samples.append({'Time':round((frame-1)/24,6),'Position':[position.x,position.z,position.y],'Rotation':[-q.x,-q.z,-q.y,q.w],'Scale':[scale.x,scale.z,scale.y]})
   for curve in action.fcurves:
    for key in curve.keyframe_points:key.interpolation='LINEAR'
   tracks.append({'Path':'Visual' if label=='Visual' else 'Visual/'+name+'_'+label,'Keys':samples})
  rig['clips'][clip]={'actions':actions,'end':end};clips.append({'Name':clip,'Duration':round((end-1)/24,6),'Loop':loop,'Tracks':tracks})
 CLIPS[name]=clips
 for label,node in rig['objects'].items():node.animation_data.action=rig['clips']['Idle']['actions'][label]
 scene.frame_set(1);bpy.context.view_layer.update()

def splash_model():
 name='WaterfallSplash';start_rig(name,'splash')
 for j in range(12):
  a=j*2.399;p=(math.cos(a)*.25,math.sin(a)*.25,0)
  articulated('Drop'+str(j),p,lambda p=p:sphere('Animated waterfall spray droplet',p,(.07,.07,.13),'D3F7FF','Glow',0))
 for j in range(3):articulated('Ripple'+str(j),(0,0,0),lambda j=j:ring('Animated expanding foam ripple',(0,0,.02+j*.01),.65,.045,'ADECF5','Glow',segments=32))
 return finish_rig(name)
