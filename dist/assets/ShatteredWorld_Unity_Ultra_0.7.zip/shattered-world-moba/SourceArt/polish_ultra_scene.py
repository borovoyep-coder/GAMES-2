"""Final masonry union, cliff facets and presentation renders, applied to the saved 0.5 master."""
import bpy,bmesh,math,random,json,ast,time,os
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';PREVIEW=ROOT/'docs/Art';pi=math.pi;start=time.time()
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
base=ROOT/'SourceArt/build_valley.py';text=base.read_text();tree0=ast.parse(text);COLLECTIONS={c.name:c for c in bpy.data.collections};CURRENT=COLLECTIONS['Environment'];PRIMITIVES={};R=random.Random(1505)
for node in tree0.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PALETTE' for t in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),str(base),'exec'),globals())
MATERIALS={name:bpy.data.materials[name] for name in ['Stone','Ground','Foliage','Wood','Metal','Creature','Crystal','Glow','Water','Obsidian']}
def definitions(path,names):
 tree=ast.parse(path.read_text())
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),globals())
definitions(base,{'lin','rgb','collection','finish','primitive_mesh','new_object','box','sphere','cyl','limb','ring','polyline','rotate','xy'})
definitions(ROOT/'SourceArt/build_reference_valley.py',{'mesh_object'})
definitions(ROOT/'SourceArt/ultra_models.py',{'stone_wall'})
definitions(ROOT/'SourceArt/build_ultra_valley.py',{'author_matrix','instance'})
layout=json.loads((OUT/'ValleyLayout.json').read_text());manifest=json.loads((OUT/'ArtManifest.json').read_text())
stems=('Hand cut sandstone block','Bevelled ruin coping','Clinging wall moss','Carved terminal pier','Terminal gold coping')
removed=0
for obj in list(CURRENT.objects):
 if obj.name.startswith(stems):bpy.data.objects.remove(obj,do_unlink=True);removed+=1
def merged(blocks):
 groups={}
 for w in blocks:
  angle=w['Angle']%180;r=math.radians(angle);d=(math.cos(r),math.sin(r));p=xy(w['Center']);t=p[0]*d[0]+p[1]*d[1];offset=-p[0]*d[1]+p[1]*d[0];key=(round(angle,3),round(offset,2),w['Size']['Y']);groups.setdefault(key,[]).append((t-w['Size']['X']/2,t+w['Size']['X']/2))
 result=[]
 for (angle,offset,width),intervals in groups.items():
  intervals.sort();runs=[]
  for a,b in intervals:
   if runs and a<=runs[-1][1]+.025:runs[-1]=(runs[-1][0],max(b,runs[-1][1]))
   else:runs.append((a,b))
  d=(math.cos(math.radians(angle)),math.sin(math.radians(angle)))
  for a,b in runs:
   t=(a+b)/2;result.append(((d[0]*t-d[1]*offset,d[1]*t+d[0]*offset),b-a,math.radians(angle),width))
 return result
for center,length,angle,width in merged(layout['Walls']):stone_wall(center,length,angle,width)
for center,length,angle,width in merged(layout['BankWalls']):stone_wall(center,length,angle,width,.9)
print('POLISH: replaced',removed,'overlapping masonry objects with continuous runs',flush=True)
for obj in COLLECTIONS['Backdrop'].objects:
 if obj.type!='MESH':continue
 if obj.name.startswith(('Layered valley escarpment','Distant jagged alpine peak','Pale alpine summit')):
  obj.data=obj.data.copy()
  for v in obj.data.vertices:
   p=v.co;v.co*=1+.065*math.sin(p.x*5+p.y*7+p.z*11+obj.location.x*.03)
  for face in obj.data.polygons:face.use_smooth=False
  if not obj.name.startswith('Pale alpine summit'):
   color=rgb(['829B94','708D86','93A69D'][int(abs(obj.location.x+obj.location.y))%3]);obj.color=(*color,1);obj['art_color']=list(color)
 elif obj.name.startswith('Sculpted mountain valley'):
  color=rgb('708A81');obj.color=(*color,1);obj['art_color']=list(color)
print('POLISH: faceted and painted surrounding cliff faces',flush=True)
# Reposition the three presentation heroes around each fountain's central life crystal.
preview=COLLECTIONS['PreviewUnits']
for team in range(2):
 fountain=layout['Fountains'][team];suffix='Red' if team else 'Blue';claimed=set()
 for index in range(3):
  center=Vector((fountain['X']+(index-1)*1.1,fountain['Y'],.65));angle=index*2*pi/3;dest=Vector((fountain['X']+math.cos(angle)*2.2,fountain['Y']+math.sin(angle)*2.2,.65));delta=dest-center;source=COLLECTIONS[('Warrior' if index%2==0 else 'Mage')+suffix]
  for original in source.objects:
   if original.type!='MESH':continue
   target=center+original.location
   for obj in preview.objects:
    if obj in claimed or obj.type!='MESH' or obj.data!=original.data:continue
    if (obj.location-target).length<.0001:
     obj.location+=delta;claimed.add(obj);break
# Export only the two changed environment kits; animated characters and their FBX remain untouched.
export_text=text[text.index('def export_bundle('):text.index('def instance(')]
export_text=export_text.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
export_text=export_text.replace('uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])',"uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(export_text,str(base),'exec'),globals())
bpy.context.view_layer.update()
for name in ['Environment','Backdrop']:
 definition=export_bundle(name,COLLECTIONS[name],True)
 for i,entry in enumerate(manifest['Models']):
  if entry['Name']==name:manifest['Models'][i]=definition
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2))
scene=bpy.context.scene;camera=scene.camera;scene.cycles.samples=24;scene.cycles.max_bounces=4;scene.cycles.diffuse_bounces=2;scene.cycles.glossy_bounces=2;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.06;scene.cycles.adaptive_min_samples=4;scene.render.resolution_percentage=100;scene.render.fps=24;scene.frame_end=240;scene.frame_set(1)
camera.data.ortho_scale=164;camera.location=(0,-126,174);camera.rotation_euler=(Vector((0,1,-2))-camera.location).to_track_quat('-Z','Y').to_euler();scene.render.resolution_x=1600;scene.render.resolution_y=1600
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
if os.environ.get('VALLEY_SKIP_RENDER')!='1':
 scene.render.filepath=str(PREVIEW/'Valley_Overview.png');bpy.ops.render.render(write_still=True)
 camera.location=(-27,-48,42);camera.rotation_euler=(Vector((-24,-3,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=52;scene.render.resolution_x=1500;scene.render.resolution_y=1050;scene.render.filepath=str(PREVIEW/'Valley_Closeup.png');bpy.ops.render.render(write_still=True)
 camera.location=(-64,-74,28);camera.rotation_euler=(Vector((-50,-50,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=30;scene.render.resolution_x=1450;scene.render.resolution_y=1000;scene.render.filepath=str(PREVIEW/'Fountain_Nexus.png');bpy.ops.render.render(write_still=True)
 COLLECTIONS['Environment'].hide_render=True;COLLECTIONS['Backdrop'].hide_render=True;preview.hide_render=True;COLLECTIONS['RiverFlow'].hide_render=True;gallery=collection('CreatureGallery');names=['MagmaGuardian','MoonWolf','RiftGhost','AzureGolem','StoneCentipede','CrystalCrab','ObserverFirefly','RiftRay','SolarColossus','NightLeviathan']
 for i,name in enumerate(names):
  x=(i%5-2)*8;y=(i//5)*8;instance(COLLECTIONS[name],(x,y,0),0,.7 if i>=8 else 1,target=gallery);cyl('Gallery pedestal',(x,y,-.25),3,.4,'darkstone','Stone',32)
 camera.location=(0,-35,30);camera.rotation_euler=(Vector((0,3.7,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=43;scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.filepath=str(PREVIEW/'Creature_Collection.png');bpy.ops.render.render(write_still=True)
 gallery.hide_render=True;mini=collection('MinionGallery')
 for i,name in enumerate(['GuardBlue','CasterBlue','DestroyerBlue','GuardRed','CasterRed','DestroyerRed']):
  p=((i%3-1)*4.5,(i//3)*4.5,0);instance(COLLECTIONS[name],p,target=mini);cyl('Minion gallery pedestal',(p[0],p[1],-.2),1.7,.35,'darkstone','Stone',32)
 camera.location=(0,-16,13);camera.rotation_euler=(Vector((0,2,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=17;scene.render.resolution_x=1500;scene.render.resolution_y=1000;scene.render.filepath=str(PREVIEW/'Minion_Collection.png');bpy.ops.render.render(write_still=True)
print('ULTRA POLISH COMPLETE',time.time()-start,flush=True)
