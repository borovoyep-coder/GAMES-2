"""Editable water ripples, fine foam ribbons and the four traced battle clearings."""
import bpy,bmesh,math,json,ast
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';pi=math.pi
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
COLLECTIONS={c.name:c for c in bpy.data.collections};CURRENT=COLLECTIONS['Environment'];MATERIALS={m.name:m for m in bpy.data.materials}
for file,names in [('build_valley.py',{'lin','rgb'}),('build_reference_valley.py',{'mesh_object','export_fbx'})]:
 for node in ast.parse((ROOT/'SourceArt'/file).read_text()).body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PALETTE' for t in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
for name in ['Water','SkyWater']:
 mat=MATERIALS[name];nodes=mat.node_tree.nodes;links=mat.node_tree.links
 if nodes.get('Living water ripple bump'):continue
 shader=next(n for n in nodes if n.type=='BSDF_PRINCIPLED');coords=nodes.new('ShaderNodeTexCoord');mapping=next((n for n in nodes if n.type=='MAPPING'),None)
 vector=mapping.outputs['Vector'] if mapping else coords.outputs['UV']
 wave=nodes.new('ShaderNodeTexWave');wave.wave_type='BANDS';wave.bands_direction='Y';wave.inputs['Scale'].default_value=2.8;wave.inputs['Distortion'].default_value=3.2;wave.inputs['Detail Scale'].default_value=1.8;links.new(vector,wave.inputs['Vector'])
 noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=5.0;noise.inputs['Detail'].default_value=2;links.new(vector,noise.inputs['Vector'])
 mix=nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=.65;links.new(wave.outputs['Color'],mix.inputs[1]);links.new(noise.outputs['Color'],mix.inputs[2])
 bump=nodes.new('ShaderNodeBump');bump.name='Living water ripple bump';bump.inputs['Strength'].default_value=.26;bump.inputs['Distance'].default_value=.085;links.new(mix.outputs[0],bump.inputs['Height']);links.new(bump.outputs['Normal'],shader.inputs['Normal'])
 shader.inputs['Roughness'].default_value=.19
# The outer blue cascades use the same saved UV animation mechanism as the interior river.
mat=MATERIALS['SkyWater'];nodes=mat.node_tree.nodes;links=mat.node_tree.links
if not any(n.type=='MAPPING' for n in nodes):
 mapping=nodes.new('ShaderNodeMapping');coords=nodes.new('ShaderNodeTexCoord');links.new(coords.outputs['UV'],mapping.inputs['Vector'])
 for node in nodes:
  if node.type in ['TEX_IMAGE','TEX_WAVE','TEX_NOISE']:links.new(mapping.outputs['Vector'],node.inputs['Vector'])
 mapping.inputs['Location'].default_value=(0,0,0);mapping.inputs['Location'].keyframe_insert('default_value',frame=1);mapping.inputs['Location'].default_value=(0,-3,0);mapping.inputs['Location'].keyframe_insert('default_value',frame=241)
 for curve in mat.node_tree.animation_data.action.fcurves:
  for key in curve.keyframe_points:key.interpolation='LINEAR'
  curve.modifiers.new('CYCLES')
foam=next(o for o in COLLECTIONS['FoamStreak'].objects if o.type=='MESH');mesh=foam.data;mesh.clear_geometry();verts=[];faces=[]
for i in range(15):
 t=i/14;y=-.8+t*1.6;x=math.sin(t*pi*2)*.085+math.sin(t*pi*4)*.018;width=.024*math.sin(t*pi)**.7+.002;verts.extend([(x-width,y,0),(x+width,y,0)])
 if i:faces.append((i*2-2,i*2-1,i*2+1,i*2))
mesh.from_pydata(verts,[],faces);mesh.update()
# The image's four clearings are softly irregular, subtly warmer than the forest floor.
if not bpy.context.scene.get('living_water06'):
 import numpy as np
 trace=json.loads((ROOT/'SourceArt/Reference/ReferenceTrace.json').read_text());aa=[];bb=[]
 for (u,v),(x,y) in trace['Calibration']:aa.extend([[u,v,1,0,0,0,-x*u,-x*v],[0,0,0,u,v,1,-y*u,-y*v]]);bb.extend([x,y])
 h=np.r_[np.linalg.solve(aa,bb),1].reshape(3,3)
 for index,pixel in enumerate([(354,574),(742,389),(553,832),(890,635)]):
  p=h@np.array([*pixel,1]);p=p[:2]/p[2];verts=[(p[0],p[1],-.058)];n=48
  for i in range(n):a=i*2*pi/n;r=6.4+.30*math.sin(a*5+index)+.18*math.sin(a*11);verts.append((p[0]+math.cos(a)*r,p[1]+math.sin(a)*r,-.058))
  mesh_object('Traced warm battle clearing '+str(index),verts,[(0,i+1,(i+1)%n+1) for i in range(n)],'A3B45E','Ground')
base=ROOT/'SourceArt/build_valley.py';text=base.read_text();exp=text[text.index('def export_bundle('):text.index('def instance(')]
exp=exp.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
exp=exp.replace('uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])',"uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(exp,str(base),'exec'),globals());bpy.context.view_layer.update();m=json.loads((OUT/'ArtManifest.json').read_text())
for name in ['Environment','FoamStreak']:
 c=COLLECTIONS[name];c.hide_viewport=False;c.hide_render=False;bpy.context.view_layer.update();entry=export_bundle(name,c,name=='Environment');m['Models']=[entry if p['Name']==name else p for p in m['Models']]
 if name=='FoamStreak':export_fbx(name,c)
(OUT/'ArtManifest.json').write_text(json.dumps(m,indent=2));bpy.context.scene['living_water06']=True;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True);print('LIVING WATER COMPLETE',flush=True)
