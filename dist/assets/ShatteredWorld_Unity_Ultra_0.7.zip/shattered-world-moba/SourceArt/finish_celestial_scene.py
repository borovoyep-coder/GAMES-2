"""Finish source/export parity after reviewing shore clearance and fountain/terrace junctions."""
import bpy,bmesh,math,json,ast
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';pi=math.pi
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
COLLECTIONS={c.name:c for c in bpy.data.collections};CURRENT=COLLECTIONS['Environment'];MATERIALS={m.name:m for m in bpy.data.materials}
# Rebuild every forest wall from the final shared collision layout; no hidden old bank pieces survive.
base=ROOT/'SourceArt/build_valley.py';PRIMITIVES={}
for file,names in [('build_valley.py',{'lin','rgb','finish','primitive_mesh','new_object','box','sphere','cyl','limb','ring','polyline','rotate','xy'}),('ultra_models.py',{'stone_wall'}),('polish_ultra_scene.py',{'merged'})]:
 tree=ast.parse((ROOT/'SourceArt'/file).read_text())
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PALETTE' for t in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
stems=('Hand cut sandstone block','Bevelled ruin coping','Clinging wall moss','Carved terminal pier','Terminal gold coping');removed=0
for obj in list(CURRENT.objects):
 if obj.name.startswith(stems):bpy.data.objects.remove(obj,do_unlink=True);removed+=1
layout=json.loads((OUT/'ValleyLayout.json').read_text())
for center,length,angle,width in merged(layout['Walls']):stone_wall(center,length,angle,width)
if not bpy.context.scene.get('finish06'):
 for name in ['FountainBlue','FountainRed']:
  for obj in COLLECTIONS[name].objects:obj.location.z+=.12
  data={obj.data for obj in COLLECTIONS[name].objects if obj.type=='MESH'}
  for obj in COLLECTIONS['PreviewUnits'].objects:
   if obj.type=='MESH' and obj.data in data:obj.location.z+=.12
base=ROOT/'SourceArt/build_valley.py';text=base.read_text();export_text=text[text.index('def export_bundle('):text.index('def instance(')]
export_text=export_text.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
export_text=export_text.replace('uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])',"uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(export_text,str(base),'exec'),globals())
for node in ast.parse((ROOT/'SourceArt/build_reference_valley.py').read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name=='export_fbx':exec(compile(ast.Module(body=[node],type_ignores=[]),'export_fbx','exec'),globals())
manifest=json.loads((OUT/'ArtManifest.json').read_text());bpy.context.view_layer.update()
for name in ['Environment','FountainBlue','FountainRed']:
 c=COLLECTIONS[name];c.hide_viewport=False;c.hide_render=False;bpy.context.view_layer.update();definition=export_bundle(name,c,name=='Environment')
 manifest['Models']=[definition if item['Name']==name else item for item in manifest['Models']]
 if name!='Environment':export_fbx(name,c)
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2));bpy.context.scene['river_banks_closed']=True;bpy.context.scene['finish06']=True
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
print('CELESTIAL FINISH COMPLETE',removed,'old masonry objects replaced from final layout',flush=True)
