"""Fix thin cloak plate bevels in the editable source and re-export both caster rigs."""
import bpy,bmesh,math,json,ast
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';pi=math.pi
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
COLLECTIONS={c.name:c for c in bpy.data.collections};MATERIALS={m.name:m for m in bpy.data.materials};CLIPS={};RIGS={}
for file,names in [('build_ultra_valley.py',{'author_matrix','static_rig_fbx'}),('ultra_models.py',{'animated_export_bundle'}),('build_celestial_valley.py',{'rest_rig','isolated_fbx'})]:
 for node in ast.parse((ROOT/'SourceArt'/file).read_text()).body:
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
base=ROOT/'SourceArt/build_valley.py';text=base.read_text();exp=text[text.index('def export_bundle('):text.index('def instance(')]
exp=exp.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
exp=exp.replace('uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])',"uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(exp,str(base),'exec'),globals());manifest=json.loads((OUT/'ArtManifest.json').read_text());models={m['Name']:m for m in manifest['Models']}
for name in ['CasterBlue','CasterRed']:
 c=COLLECTIONS[name];data=json.loads((OUT/models[name]['File']).read_text());CLIPS[name]=data['Clips'];rig={'pivots':{},'objects':{'Visual':bpy.data.objects[name+'_Visual']},'clips':{}}
 meshes=set(o.data for o in c.objects if o.type=='MESH')
 for obj in bpy.data.objects:
  if obj.type!='MESH' or obj.data not in meshes:continue
  for mod in obj.modifiers:
   if mod.type=='BEVEL' and mod.name=='Sculpted armour chamfer':
    depth=max(v.co.y for v in obj.data.vertices)-min(v.co.y for v in obj.data.vertices);mod.width=min(mod.width,depth*.20)
 for chunk in data['Chunks']:
  label=chunk['Name'][len(name)+1:];p=chunk['Position'];rig['pivots'][label]=(p[0],p[2],p[1]);rig['objects'][label]=bpy.data.objects[chunk['Name']]
 for clip in data['Clips']:rig['clips'][clip['Name']]={'end':round(clip['Duration']*24)+1,'actions':{label:bpy.data.actions[name+'.'+clip['Name']+'.'+label] for label in rig['objects']}}
 rig['root']=rig['objects']['Visual'];RIGS[name]=rig;c.hide_viewport=False;rest_rig(name);bpy.context.view_layer.update();entry=animated_export_bundle(name,c);manifest['Models']=[entry if m['Name']==name else m for m in manifest['Models']];isolated_fbx(name,c);rest_rig(name,True)
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2));bpy.context.scene['caster_chamfers_fixed']=True;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True);print('CASTER CHAMFERS REPAIRED',flush=True)
