"""Replace overlapping rectangular curve tiles with joined 3D sandstone pavers."""
import bpy,bmesh,math,json,ast
from pathlib import Path
from mathutils import Matrix,Vector
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';pi=math.pi
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
COLLECTIONS={c.name:c for c in bpy.data.collections};CURRENT=COLLECTIONS['Environment'];MATERIALS={m.name:m for m in bpy.data.materials};PRIMITIVES={}
for file,names in [('build_valley.py',{'lin','rgb'}),('build_reference_valley.py',{'mesh_object','sample_path'})]:
 for node in ast.parse((ROOT/'SourceArt'/file).read_text()).body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PALETTE' for t in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),globals())
exec(compile((ROOT/'SourceArt/celestial_environment.py').read_text(),'celestial_environment.py','exec'),globals())
layout=json.loads((OUT/'ValleyLayout.json').read_text());BASES=[(p['X'],p['Y']) for p in layout['Bases']];ROAD_CENTERS=[];removed=0
for obj in list(CURRENT.objects):
 if obj.name.startswith(('Uniform lane sandstone paving tile','Divine golden line down lane centre','Joined sandstone lane tile','Divine continuous golden lane centre')):bpy.data.objects.remove(obj,do_unlink=True);removed+=1
for road in layout['Lanes']:seamless_lane([(p['X'],p['Y']) for p in road['Points']],foundation=False)
build_joined_pavers()
base=ROOT/'SourceArt/build_valley.py';text=base.read_text();exp=text[text.index('def export_bundle('):text.index('def instance(')]
exp=exp.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
exp=exp.replace('uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])',"uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(exp,str(base),'exec'),globals());bpy.context.view_layer.update();entry=export_bundle('Environment',CURRENT,True);m=json.loads((OUT/'ArtManifest.json').read_text());m['Models']=[entry if p['Name']=='Environment' else p for p in m['Models']];(OUT/'ArtManifest.json').write_text(json.dumps(m,indent=2))
bpy.context.scene['joined_paving06']=True;bpy.context.scene.cycles.use_denoising=True;bpy.context.scene.cycles.samples=32;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True);print('JOINED PAVING COMPLETE',removed,'old parts replaced',flush=True)
