"""Validate FBX in an empty scene, avoiding dependency updates of the full landscape."""
import bpy,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];source=root/'Assets/ShatteredWorld/Art/Source';manifest=json.loads((source/'ArtManifest.json').read_text())
counts={m['Name']:m['Triangles'] for m in manifest['Models']};checked=0
for path in sorted((root/'SourceArt/FBX').rglob('*.fbx')):
 bpy.ops.wm.read_factory_settings(use_empty=True)
 bpy.ops.import_scene.fbx(filepath=str(path),use_image_search=False,use_anim=True)
 name=path.stem.rsplit('_',1)[0] if path.parent.name=='Animations' else path.stem
 meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert meshes,path
 count=0
 for obj in meshes:
  assert obj.data.uv_layers.active,(path.name,'UV')
  assert obj.data.color_attributes,(path.name,'vertex colors')
  obj.data.calc_loop_triangles();count+=len(obj.data.loop_triangles)
 assert count==counts[name],(path.name,count,counts[name])
 if path.parent.name=='Animations':
  assert len(bpy.data.actions)>0,path
  assert any(a.frame_range[1]>a.frame_range[0]+5 for a in bpy.data.actions),path
 checked+=1;print('PASS FBX read-back',path.name,'triangles',count,flush=True)
assert checked==139,checked
print('CELESTIAL FBX VALIDATION COMPLETE: 39 static + 100 animated files',flush=True)
