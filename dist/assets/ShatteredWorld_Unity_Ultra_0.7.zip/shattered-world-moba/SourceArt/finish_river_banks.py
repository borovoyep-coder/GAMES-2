"""Close the physical bank faces and align the parapets with the actual curved river."""
import bpy,bmesh,math,random,json,ast,time
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';PREVIEW=ROOT/'docs/Art';pi=math.pi;start=time.time()
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'))
base=ROOT/'SourceArt/build_valley.py';text=base.read_text();COLLECTIONS={c.name:c for c in bpy.data.collections};CURRENT=COLLECTIONS['Environment'];PRIMITIVES={};R=random.Random(1505)
for node in ast.parse(text).body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PALETTE' for t in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),str(base),'exec'),globals())
MATERIALS={name:bpy.data.materials[name] for name in ['Stone','Ground','Foliage','Wood','Metal','Creature','Crystal','Glow','Water','Obsidian']}
def definitions(path,names):
 for node in ast.parse(path.read_text()).body:
  if isinstance(node,ast.FunctionDef) and node.name in names:exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),globals())
definitions(base,{'lin','rgb','finish','primitive_mesh','new_object','box','sphere','cyl','limb','rotate','xy'})
definitions(ROOT/'SourceArt/build_reference_valley.py',{'mesh_object'})
definitions(ROOT/'SourceArt/ultra_models.py',{'stone_wall'})
definitions(ROOT/'SourceArt/polish_ultra_scene.py',{'merged'})
layout=json.loads((OUT/'ValleyLayout.json').read_text());manifest=json.loads((OUT/'ArtManifest.json').read_text())
stems=('Hand cut sandstone block','Bevelled ruin coping','Clinging wall moss','Carved terminal pier','Terminal gold coping','Closed mossy riverbank')
for obj in list(CURRENT.objects):
 if obj.name.startswith(stems):bpy.data.objects.remove(obj,do_unlink=True)
for center,length,angle,width in merged(layout['Walls']):stone_wall(center,length,angle,width)
for center,length,angle,width in merged(layout['BankWalls']):stone_wall(center,length,angle,width,.9)
water=next(o for o in CURRENT.objects if o.name.startswith('Curved river surface'))
for side in [0,2]:
 verts=[];faces=[]
 for i in range(len(layout['River']['Points'])):
  p=water.data.vertices[i*3+side].co;verts.extend([(p.x,p.y,-.1),(p.x,p.y,p.z-.1)])
  if i:
   j=i*2;face=(j-2,j-1,j+1,j) if side==0 else (j-2,j,j+1,j-1);faces.append(face)
 mesh_object('Closed mossy riverbank '+str(side),verts,faces,'789788','Stone')
bpy.context.view_layer.update()
export_text=text[text.index('def export_bundle('):text.index('def instance(')]
export_text=export_text.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
export_text=export_text.replace('uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])',"uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(export_text,str(base),'exec'),globals());definition=export_bundle('Environment',CURRENT,True)
for i,m in enumerate(manifest['Models']):
 if m['Name']=='Environment':manifest['Models'][i]=definition
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2));scene=bpy.context.scene;scene['river_banks_closed']=True;scene.frame_set(1);camera=scene.camera
camera.data.ortho_scale=164;camera.location=(0,-126,174);camera.rotation_euler=(Vector((0,1,-2))-camera.location).to_track_quat('-Z','Y').to_euler();scene.render.resolution_x=1600;scene.render.resolution_y=1600;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
scene.render.filepath=str(PREVIEW/'Valley_Overview.png');bpy.ops.render.render(write_still=True)
camera.location=(-27,-48,42);camera.rotation_euler=(Vector((-24,-3,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=52;scene.render.resolution_x=1500;scene.render.resolution_y=1050;scene.render.filepath=str(PREVIEW/'Valley_Closeup.png');bpy.ops.render.render(write_still=True)
print('RIVER BANK FINISH COMPLETE',time.time()-start,flush=True)
