"""Blender modelling helpers for the 0.5 scene; executed by build_ultra_valley.py."""
OLD_TREE=tree;OLD_TOWER=tower;OLD_GATE=gate;OLD_BRIDGE=bridge;OLD_ENVIRONMENT=build_environment;OLD_TERRAIN=terrain

def tree(p,height=5.5,variant=0):
 x,y=p
 cyl('Tapered bark trunk',(x,y,height*.23),.22,height*.46,'574536','Wood',9,.12)
 for level in range(5):
  z=height*(.27+level*.145);r=height*(.29-level*.042);h=height*(.34-level*.018)
  cone=cyl('Painted layered fir canopy',(x,y,z),r,h,['173E35','205143','2C6550','3D7758','579067'][level],'Foliage',12,.018);cone.rotation_euler.z=variant*.4+level*.29
  for j in range(5):
   a=j*2*pi/5+level*.7+variant*.13;tip=(x+math.cos(a)*r*.87,y+math.sin(a)*r*.87,z-h*.19)
   limb('Fir branch with needle tips',(x,y,z+h*.06),tip,.055,'wood','Wood',.018,6)
   tuft=cyl('Fir needle fringe',(tip[0],tip[1],tip[2]+h*.13),r*.22,h*.43,['23513D','316A46','477B4F'][j%3],'Foliage',6,.01);tuft.rotation_euler.x=math.sin(a)*.35;tuft.rotation_euler.y=-math.cos(a)*.35
 for side in [-1,1]:limb('Gnarled exposed tree root',(x,y,.12),(x+side*.52,y+.3,.02),.11,'wood','Wood',.025)

def bush_geometry(x,y,scale=1):
 for i in range(25):
  a=i*2*pi/25;radius=(.18+(i%5)*.11)*scale;h=(.8+(i%7)*.11)*scale;lean=.35*scale;w=.115*scale;dx,dy=math.cos(a),math.sin(a);sx,sy=-dy*w,dx*w;cx=x+dx*radius;cy=y+dy*radius
  verts=[(cx-sx,cy-sy,.015),(cx+sx,cy+sy,.015),(cx+dx*lean+sx,cy+dy*lean+sy,h*.62),(cx+dx*lean,cy+dy*lean,h*.8),(cx+dx*lean-sx,cy+dy*lean-sy,h*.62),(cx+dx*(lean+.08),cy+dy*(lean+.08),h)]
  mesh_object('Folded broad grass leaf',verts,[(0,1,3),(1,2,3),(2,5,3),(5,4,3),(4,0,3)],['8BAF44','B2CA66','688F35','9FBD4C'][i%4],'Foliage')
 for j in range(3):
  a=j*2*pi/3;limb('Brush seed head stem',(x,y,.05),(x+math.cos(a)*.28,y+math.sin(a)*.28,1.28*scale),.017,'8DAD50','Foliage',.012,5)

def stone_wall(center,length,angle=0,width=.85,height=1.5):
 before=set(CURRENT.objects)
 count=max(1,math.ceil(length/1.35));step=length/count
 for i in range(count):
  q=rotate(((i+.5)*step-length/2,0),angle);x,y=center[0]+q[0],center[1]+q[1]
  for row in range(3):
   box('Hand cut sandstone block',(x,y,.24+row*.4),(step-.04,width,.37),['B9AA8A','D7C9A6','C7B895'][(i+row)%3],'Stone',.055,angle)
  box('Bevelled ruin coping',(x,y,1.3+.008*math.sin(x*7+y*3)),(step-.035,width+.18,.22),'E3D6B5','Stone',.045,angle)
  if i%4==0:
   for j in range(4):
    q=rotate((-.25+j*.17,width*.51),angle);sphere('Clinging wall moss',(x+q[0],y+q[1],1.2-j*.14),(.19,.12,.09),'5B7D3A','Foliage',0)
 for side in ([-1,1] if length>3 else []):
  q=rotate((side*(length/2-.2),0),angle);x,y=center[0]+q[0],center[1]+q[1]
  box('Carved terminal pier',(x,y,.76),(width+.16,width+.16,1.52),'C9BA99','Stone',.06,angle);box('Terminal gold coping',(x,y,1.55+.012*math.sin(x*5+y*3)),(width+.36,width+.36,.2),'goldlight','Stone',.04,angle)
 if height!=1.5:
  for obj in CURRENT.objects:
   if obj not in before:obj.location.z*=height/1.5;obj.scale.z*=height/1.5

def ornament_ring(p,r,color='gold',count=12):
 ring('Inlaid fine circuit',p,r,.035,color,'Metal',segments=64)
 for i in range(count):
  a=i*2*pi/count;q=(p[0]+math.cos(a)*r,p[1]+math.sin(a)*r,p[2]+.015)
  o=box('Engraved diamond rune',q,(.13,.13,.018),color,'Metal',.01,a+pi/4)

def tower(name,red=False,core=False):
 OLD_TOWER(name,red,core);c='red' if red else 'blue'
 if core:
  for side in range(6):
   a=side*pi/3
   for j in range(3):
    radius=2.55-j*.1;q=(math.cos(a)*radius,math.sin(a)*radius,.48+j*.18);box('Nexus carved buttress step',q,(.45,.55,.2),'lightstone','Stone',.04,a)
   crystal('Nexus suspended royal shard',(math.cos(a)*1.65,math.sin(a)*1.65,3.4),.2,1.25,c,(.3*math.sin(a),-.3*math.cos(a)))
  ornament_ring((0,0,.23),2.85,'goldlight',24);ornament_ring((0,0,1.06),2.12,'gold',18)
 else:
  for side in range(8):
   a=side*pi/4;r=.79
   box('Tower inset shadow panel',(math.cos(a)*r,math.sin(a)*r,1.34),(.18,.05,.58),'74644A','Stone',.025,a-pi/2)
   limb('Tower glowing rune',(math.cos(a)*r*1.02,math.sin(a)*r*1.02,1.12),(math.cos(a)*r*1.02,math.sin(a)*r*1.02,1.53),.023,c,'Glow',.023,5)
  ornament_ring((0,0,.22),1.48,'goldlight',16);ornament_ring((0,0,2.32),1.04,'gold',12)
 return CURRENT

def fountain(name,red=False):
 collection(name);c='red' if red else 'blue'
 for z,r,h in [(.05,4.7,.3),(.25,4.35,.24),(.42,3.95,.2)]:cyl('Fountain stepped sanctuary',(0,0,z),r,h,'lightstone','Stone',48)
 ornament_ring((0,0,.54),3.7,'goldlight',32);cyl('Fountain luminous basin',(0,0,.48),3.25,.12,c,'Water',64)
 for i in range(12):
  a=i*pi/6;box('Fountain segmented basin curb',(math.cos(a)*3.4,math.sin(a)*3.4,.68),(1.65,.45,.4),'stone','Stone',.07,a+pi/2)
 lathe('Fountain crystal pedestal',[(.5,.85),(.85,.8),(1.15,.5),(1.4,.75)],'stone');crystal('Fountain life crystal',(0,0,1.35),.52,2.4,c)
 for i in range(4):
  a=i*pi/2;points=[]
  for j in range(15):
   t=j/14;r=.6+2*t;points.append((math.cos(a)*r,math.sin(a)*r,1.5+1.5*math.sin(pi*t)-t))
  polyline('Fountain falling magical water',points,.06,'B3F4ED','Water')
 for i in range(7):
  a=pi*.05+i*pi*.15;x,y=math.cos(a)*3.9,math.sin(a)*3.9;cyl('Fountain shrine pillar',(x,y,1.5),.25,2.4,'stone','Stone',12);cyl('Fountain pillar capital',(x,y,2.75),.38,.18,'gold','Metal',12);crystal('Fountain guardian light',(x,y,2.9),.18,.65,c)
 return CURRENT

def gate():
 OLD_GATE()
 for i in range(6):
  a=i*pi/3;p=(math.cos(a)*1.35,math.sin(a)*1.35,.45);box('Ancient crystal binding clamp',p,(.5,.38,.5),'gold','Metal',.08,a);crystal('Gate loose shard',(math.cos(a)*1.75,math.sin(a)*1.75,.12),.13,.55,'purple',(.2*math.sin(a),-.2*math.cos(a)))
 ornament_ring((0,0,.31),1.5,'goldlight',18)
 return CURRENT

def bridge():
 OLD_BRIDGE()
 for side in [-1,1]:
  points=[]
  for j in range(25):
   t=j/24;points.append((side*2.25,-7+14*t,-.18+1.0*math.sin(pi*t)))
  polyline('Bridge supporting stone arch',points,.15,'stone','Stone')
  for y in [-5,-2,1,4]:
   z=.3+.65*math.sin((y+6.5)/13*pi);box('Bridge carved gilded baluster',(side*2.5,y,z+.62),(.22,.22,.75),'gold','Metal',.035);sphere('Bridge pearl lantern',(side*2.5,y,z+1.12),(.12,.12,.12),'azure','Glow',1)
 return CURRENT

def improve_creature(name):
 c=COLLECTIONS[name];collection(name)
 for obj in c.objects:
  for mod in obj.modifiers:
   if mod.type=='BEVEL':mod.segments=2
 if name in ['MagmaGuardian','AzureGolem','SolarColossus']:
  s=1.6 if name=='SolarColossus' else 1;glow='goldlight' if name=='SolarColossus' else 'azure' if name=='AzureGolem' else 'lava'
  for side in [-1,1]:
   for row in range(3):box('Layered golem shoulder armour',(side*(1.28+row*.12)*s,0,(2.85-row*.22)*s),(.9*s,.95*s,.25*s),'B8A675' if name=='SolarColossus' else '5B6B71' if name=='AzureGolem' else '71634F','Metal',.09,side*.08)
   for j in range(4):box('Golem articulated finger',(side*(1.7+j*.12)*s,-.53*s,.65*s),(.12*s,.32*s,.38*s),'gold' if name=='SolarColossus' else 'darkstone','Metal',.045)
  for j in range(7):
   a=j*2*pi/7;p=(math.cos(a)*.57*s,-.825*s,(2.15+math.sin(a)*.57)*s);sphere('Golem engraved core rivet',p,(.045*s,.025*s,.045*s),glow,'Glow',0)
  if name=='SolarColossus':
   for i in range(12):a=i*pi/6;crystal('Sun titan radiant crest',(math.cos(a)*1.12*s,.2*s,(3.4+math.sin(a)*1.12)*s),.085*s,.75*s,'goldlight',(.65*math.cos(a),.65*math.sin(a)))
 elif name=='MoonWolf':
  for side in [-1,1]:
   for i in range(5):crystal('Wolf sculpted fur tuft',(side*(.4+i*.025),-.65+i*.26,1.55-i*.06),.1,.48,'D3DDDC',(.45,side*.65),'Creature')
   for i in range(3):crystal('Wolf ivory fang',(side*(.14+i*.035),-1.65+i*.07,1.8),.025,.15,'lightstone',(pi,0),'Creature')
 elif name=='NightLeviathan':
  for side in [-1,1]:
   for j in range(8):
    t=j/7;p=(side*(.8+2.8*t),.8+1.5*t,2.5-.1*t);sphere('Wing embedded amethyst scales',p,(.13,.22,.05),'AA65CF','Crystal',0)
   for j in range(4):crystal('Dragon facial crest',(.7+side*.5,-1.1+j*.17,3.05),.07,.45,'C09EE0',(.8,side*.45))
 elif name=='CrystalCrab':
  for i in range(18):a=i*2*pi/18;sphere('Crab gilded shell rivet',(math.cos(a)*.88,math.sin(a)*.59,1.1),(.055,.055,.055),'goldlight','Metal',0)
 elif name=='RiftGhost':
  for i in range(12):
   a=i*pi/6;polyline('Ghost flowing cloth fold',[(math.cos(a)*.42,math.sin(a)*.34,1.68),(math.cos(a)*.58,math.sin(a)*.42,.9),(math.cos(a)*.69,math.sin(a)*.53,.4+(.12 if i%2 else 0))],.035,'AE9BE3','Glow')
 elif name in ['ObserverFirefly','RiftRay']:
  for side in [-1,1]:
   for j in range(4):polyline('Wing fine luminous veins',[(0,0,1.4),(side*(.7+j*.18),.1+j*.12,1.45),(side*(1.0+j*.15),.2+j*.15,1.28)],.012,'BAF5E7','Glow')

RIGS={};CLIPS={};RIG_PART=None
def part(name,pivot,make):
 global RIG_PART
 before=set(CURRENT.objects);make()
 for obj in CURRENT.objects:
  if obj not in before and obj.type=='MESH':obj['rig_part']=name
 RIGS[CURRENT.name]['pivots'][name]=pivot

def cloth(name,team):
 verts=[];faces=[]
 for row in range(5):
  z=1.65-row*.29
  for j in range(7):x=(j-3)*(.16+row*.015);verts.append((x,.25+row*.12+math.cos(j*pi/3)*.055,z))
  if row:
   for j in range(6):a=(row-1)*7+j;faces.append((a,a+1,a+8,a+7))
 return mesh_object(name,verts,faces,team,'Creature')

def minion(name,red=False,mage=False,cannon=False):
 collection(name);RIGS[name]={'pivots':{}};team='red' if red else 'blue';silver='E0DCD0'
 if cannon:
  def body():
   box('Siege articulated chassis',(0,0,.65),(1.5,2.0,.55),'wood','Wood',.12);box('Siege armoured upper deck',(0,0,1.02),(1.55,1.7,.22),'gold','Metal',.07)
   for side in [-1,1]:box('Siege ornate side armour',(side*.75,0,.76),(.12,1.75,.53),team,'Metal',.04)
   crystal('Siege charged power crystal',(0,.5,1.25),.35,.9,team);ornament_ring((0,.5,1.18),.42,'goldlight',10)
  part('Body',(0,0,.65),body)
  for side in [-1,1]:
   for index,y in enumerate([-.63,.63]):
    def wheel(side=side,y=y):
     o=cyl('Siege iron wheel',(side*.91,y,.44),.48,.24,'darkstone','Metal',16);o.rotation_euler.y=pi/2
     o=cyl('Wheel gold hub',(side*1.045,y,.44),.19,.04,'gold','Metal',12);o.rotation_euler.y=pi/2
     for j in range(8):a=j*pi/4;limb('Wheel sculpted spoke',(side*1.06,y,.44),(side*1.06,y+math.cos(a)*.39,.44+math.sin(a)*.39),.035,'gold','Metal',.025)
    part(('WheelL' if side<0 else 'WheelR')+str(index),(side*.91,y,.44),wheel)
  def barrel():
   limb('Siege long rune cannon',(0,.2,1.25),(0,-1.25,1.48),.31,'gold','Metal',.25,16)
   for y in [-1.15,-.6,0]:o=cyl('Cannon barrel band',(0,y,1.4-y*.08),.35,.13,'lightstone','Metal',16);o.rotation_euler.x=pi/2
   sphere('Cannon dark bore',(0,-1.34,1.49),(.19,.035,.19),'obsidian','Obsidian',1)
  part('Weapon',(0,.25,1.25),barrel)
 else:
  def body():
   sphere('Minion shaped cuirass',(0,0,1.19),(.43,.29,.48),team,'Metal',2);box('Minion breastplate',(0,-.245,1.22),(.62,.13,.62),silver,'Metal',.08)
   crystal('Minion team chest insignia',(0,-.33,1.08),.1,.36,team,(pi/2,0));box('Minion gold belt',(0,0,.9),(.8,.57,.14),'gold','Metal',.04);cloth('Minion pleated cape',team)
   if mage:
    o=cyl('Caster pleated robe',(0,.04,.68),.48,.84,team,'Creature',16,.33)
    for j in range(8):a=j*pi/4;limb('Caster robe gold embroidery',(math.cos(a)*.41,math.sin(a)*.41,.3),(math.cos(a)*.29,math.sin(a)*.29,.95),.018,'goldlight','Metal',.018,5)
  part('Body',(0,0,1.12),body)
  def head():
   sphere('Minion sculpted helmet',(0,0,1.82),(.29,.28,.33),'gold' if not mage else 'obsidian','Metal',2);box('Minion deep face visor',(0,-.25,1.81),(.38,.06,.14),'1C2D35','Obsidian',.025)
   for side in [-1,1]:sphere('Minion luminous eye',(side*.1,-.292,1.82),(.047,.027,.04),team,'Glow',1)
   if mage:
    o=cyl('Caster curved hood',(0,.04,2.15),.31,.62,team,'Creature',12,.04);o.rotation_euler.x=-.18
    crystal('Caster hood gem',(0,-.26,2.08),.08,.26,team)
   else:
    for j in range(5):o=box('Guard helmet swept plume',(0,.15-j*.07,2.12+j*.025),(.14,.13,.28),team,'Creature',.06);o.rotation_euler.x=-.25
  part('Head',(0,0,1.61),head)
  for side in [-1,1]:
   def leg(side=side):
    limb('Minion articulated greave',(side*.22,0,.91),(side*.24,-.04,.28),.135,'darkstone','Metal',.11,10);box('Minion bevelled boot',(side*.24,-.13,.16),(.31,.48,.25),silver,'Metal',.05)
   part('LegL' if side<0 else 'LegR',(side*.22,0,.86),leg)
   def arm(side=side):
    sphere('Minion layered pauldron',(side*.46,0,1.42),(.24,.29,.16),'gold','Metal',1);limb('Minion gauntleted arm',(side*.43,0,1.39),(side*.57,-.1,1.0),.12,silver,'Metal',.095,10);sphere('Minion glove',(side*.57,-.12,.97),(.13,.13,.16),'darkstone','Creature',1)
   part('ArmL' if side<0 else 'ArmR',(side*.43,0,1.39),arm)
  def weapon():
   if mage:
    limb('Caster silver rune staff',(.63,-.18,.24),(.63,-.18,2.3),.045,'gold','Metal',.045,10);crystal('Caster staff head',(.63,-.18,2.17),.17,.57,team);ring('Caster staff floating halo',(.63,-.18,2.28),.27,.025,'goldlight','Glow')
   else:
    box('Guard broad sword',(.65,-.23,1.29),(.2,.09,1.05),silver,'Metal',.035);box('Guard sword crosspiece',(.65,-.23,.9),(.4,.15,.09),'gold','Metal',.03);crystal('Sword pommel',(.65,-.23,.68),.065,.22,team)
  part('Weapon',(.57,-.12,.97),weapon)
  if not mage:
   def shield():
    sphere('Guard bevelled kite shield',(-.6,-.31,1.11),(.31,.11,.42),'gold','Metal',2);sphere('Guard enamel shield face',(-.6,-.405,1.11),(.245,.035,.34),team,'Metal',2);crystal('Guard shield crest',(-.6,-.45,.98),.08,.3,silver,(pi/2,0),'Metal')
   part('Shield',(-.43,0,1.39),shield)
 # Rigid articulated meshes are genuinely animated in Blender. Native Unity clips use the same tracks.
 rig=RIGS[name];rig['root']=bpy.data.objects.new(name+'_Visual',None);CURRENT.objects.link(rig['root']);rig['objects']={'Visual':rig['root']}
 for label,pivot in rig['pivots'].items():
  node=bpy.data.objects.new(name+'_'+label,None);CURRENT.objects.link(node);node.parent=rig['root'];node.location=pivot;rig['objects'][label]=node
 for obj in list(CURRENT.objects):
  if obj.type!='MESH':continue
  label=obj['rig_part'];node=rig['objects'][label];obj.parent=node;obj.location=Vector(obj.location)-Vector(rig['pivots'][label])
 rig['mage']=mage;rig['cannon']=cannon;rig['clips']={}
 return CURRENT

def make_minion_clips(name):
 rig=RIGS[name];scene=bpy.context.scene;scene.render.fps=24
 spec=[('Idle',1.5,True),('Walk',.8,True),('Attack',.85,False),('Death',1.35,False),('Spawn',.8,False)];clips=[]
 for clip,duration,loop in spec:
  end=round(duration*24)+1;actions={};tracks=[]
  for label,node in rig['objects'].items():
   node.animation_data_clear();action=bpy.data.actions.new(name+'.'+clip+'.'+label);action.use_fake_user=True;node.animation_data_create();node.animation_data.action=action;actions[label]=action
   rest=Vector((0,0,0) if label=='Visual' else rig['pivots'][label]);samples=[]
   for frame in range(1,end+1):
    t=(frame-1)/(end-1);phase=t*2*pi;position=rest.copy();rotation=Vector((0,0,0));scale=Vector((1,1,1))
    if clip=='Idle':
     if label=='Visual':position.z+=math.sin(phase)*.025
     if label=='Head':rotation.z=math.sin(phase)*.035
    elif clip=='Walk':
     sign=-1 if label in ['LegL','ArmR','Weapon'] else 1
     if label.startswith('Leg') or label.startswith('Arm') or label in ['Weapon','Shield']:rotation.x=math.sin(phase)*(.48 if label.startswith('Leg') else .27)*sign
     if label=='Visual':position.z+=abs(math.sin(phase))*.065;rotation.y=math.sin(phase)*.035
     if label.startswith('Wheel'):rotation.x=-phase
    elif clip=='Attack':
     wind=math.sin(min(1,t/.38)*pi/2) if t<.38 else max(0,1-(t-.38)/.62)
     snap=math.sin(min(1,t/.22)*pi/2) if t<.22 else math.cos(min(1,(t-.22)/.78)*pi/2)
     if label=='Visual':rotation.x=-.11*math.sin(t*pi)
     if label in ['ArmR','Weapon']:rotation.x=(-.85 if t<.3 else .95)*wind;rotation.y=-.15*wind
     if rig['mage'] and label in ['ArmR','Weapon']:rotation.x=-.6*math.sin(pi*t)
     if rig['cannon'] and label=='Weapon':position.y+=.32*max(0,1-abs(t-.48)/.18);rotation.x=-.11*wind
     if label=='Head':rotation.x=.07*wind
    elif clip=='Death':
     fall=min(1,t/.65);fall=fall*fall*(3-2*fall)
     if label=='Visual':rotation.x=1.35*fall;position.z-=.1*fall;position.y+=.22*fall;scale*=max(.02,1-max(0,t-.8)*4.9)
     if label.startswith('Arm') or label in ['Weapon','Shield']:rotation.y=(.45 if label.endswith('L') else -.45)*fall
    elif clip=='Spawn':
     grow=min(1,t/.55);grow=grow*grow*(3-2*grow)
     if label=='Visual':scale*=max(.025,grow);position.z+=(1-grow)*.42;rotation.z=(1-grow)*.45
     if label=='Head':rotation.x=-.18*(1-grow)
    node.location=position;node.rotation_euler=rotation;node.scale=scale
    node.keyframe_insert('location',frame=frame);node.keyframe_insert('rotation_euler',frame=frame);node.keyframe_insert('scale',frame=frame)
    # Reflection (x,y,z)->(x,z,y) maps quaternion xyz to (-x,-z,-y).
    q=node.rotation_euler.to_quaternion();samples.append({'Time':round((frame-1)/24,6),'Position':[position.x,position.z,position.y],'Rotation':[-q.x,-q.z,-q.y,q.w],'Scale':[scale.x,scale.z,scale.y]})
   for fcurve in action.fcurves:
    for key in fcurve.keyframe_points:key.interpolation='LINEAR'
   path='Visual' if label=='Visual' else 'Visual/'+name+'_'+label
   tracks.append({'Path':path,'Keys':samples})
  rig['clips'][clip]={'actions':actions,'end':end};clips.append({'Name':clip,'Duration':round((end-1)/24,6),'Loop':loop,'Tracks':tracks})
 CLIPS[name]=clips
 for label,node in rig['objects'].items():node.animation_data.action=rig['clips']['Idle']['actions'][label]
 scene.frame_set(1);bpy.context.view_layer.update()

def animated_export_bundle(name,c):
 result={'Name':name,'Chunks':[],'Clips':CLIPS[name]};total=0
 for label,pivot in RIGS[name]['pivots'].items():
  temp=bpy.data.collections.new('Native temporary part');bpy.context.scene.collection.children.link(temp)
  for obj in c.objects:
   if obj.type=='MESH' and obj.get('rig_part')==label:temp.objects.link(obj)
  definition=export_bundle(name+'_'+label,temp);data=json.loads((OUT/definition['File']).read_text());(OUT/definition['File']).unlink()
  for chunk in data['Chunks']:
   chunk['Name']=name+'_'+label;chunk['Position']=[pivot[0],pivot[2],pivot[1]]
   for i in range(0,len(chunk['Vertices']),3):chunk['Vertices'][i]-=pivot[0];chunk['Vertices'][i+1]-=pivot[2];chunk['Vertices'][i+2]-=pivot[1]
   result['Chunks'].append(chunk)
  total+=definition['Triangles'];bpy.data.collections.remove(temp)
 file=name+'.meshdata.json';(OUT/file).write_text(json.dumps(result,separators=(',',':')))
 return {'Name':name,'File':file,'Triangles':total,'Chunks':len(result['Chunks'])}

def animated_fbx(name,c):
 directory=ROOT/'SourceArt/FBX/Animations';directory.mkdir(exist_ok=True);rig=RIGS[name];scene=bpy.context.scene;c.hide_viewport=False;c.hide_render=False;bpy.context.view_layer.update()
 for obj in c.objects:
  if obj.type!='MESH':continue
  obj.data=obj.data.copy();mesh=obj.data;attr=mesh.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER')
  for value in attr.data:value.color=(*obj.get('art_color',[.5,.5,.5]),1)
  if not mesh.uv_layers:
   layer=mesh.uv_layers.new(name='PaintedUV')
   for poly in mesh.polygons:
    for loop in poly.loop_indices:
     p=obj.matrix_world@mesh.vertices[mesh.loops[loop].vertex_index].co;layer.data[loop].uv=(p.x*.18+p.z*.13,p.y*.18+p.z*.07)
 for clip,data in rig['clips'].items():
  for label,node in rig['objects'].items():node.animation_data.action=data['actions'][label]
  scene.frame_start=1;scene.frame_end=data['end'];scene.frame_set(1);bpy.ops.object.select_all(action='DESELECT')
  for obj in c.objects:obj.select_set(True)
  bpy.ops.export_scene.fbx(filepath=str(directory/(name+'_'+clip+'.fbx')),use_selection=True,axis_forward='-Z',axis_up='Y',add_leaf_bones=False,bake_anim=True,bake_anim_use_all_actions=False,bake_anim_use_nla_strips=False,bake_anim_simplify_factor=0,colors_type='LINEAR',path_mode='RELATIVE')
 for label,node in rig['objects'].items():node.animation_data.action=rig['clips']['Idle']['actions'][label]
 scene.frame_start=1;scene.frame_end=240;scene.frame_set(1);c.hide_viewport=True;c.hide_render=True
