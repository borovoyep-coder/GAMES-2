import json,math,random,re
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
root=Path(__file__).resolve().parents[1]
rng=random.Random(714)
texture_dir=root/'Assets/ShatteredWorld/Art/Textures'
for name,kind in [('PaintedStone','stone'),('PaintedFoliage','foliage'),('PaintedCreature','creature'),('AncientMetal','metal'),('FlowWater','water'),('GroundMeadow','ground')]:
 size=1024 if kind in ['ground','stone'] else 512
 noise=np.random.default_rng(714).normal(0,3,(size,size));base=np.clip(233+noise,0,255).astype(np.uint8)
 image=Image.fromarray(np.repeat(base[:,:,None],3,axis=2),'RGB');d=ImageDraw.Draw(image,'RGBA')
 for i in range(2200 if kind=='ground' else 600):
  x=rng.randrange(size);y=rng.randrange(size);l=rng.randint(2,24);alpha=rng.randint(10,38)
  if kind=='foliage':d.line((x,y,x+l*.7,y-l),fill=(128,147,125,alpha),width=rng.randint(1,4))
  elif kind=='water':d.arc((x-l,y-3,x+l,y+3),0,165,fill=(255,255,255,alpha+20),width=1)
  elif kind=='metal':d.line((x,y,x+l,y+1),fill=(255,255,225,alpha),width=1)
  elif kind=='creature':d.ellipse((x,y,x+l,y+l*.4),fill=(160,156,146,alpha))
  else:d.line((x,y,x+l,y+rng.randint(-6,6)),fill=(105,109,98,alpha),width=rng.randint(1,3))
 if kind=='stone':
  for j in range(30):
   x=rng.randrange(size);y=rng.randrange(size);p=[(x,y)]
   for k in range(rng.randint(3,7)):x+=rng.randint(-12,16);y+=rng.randint(8,20);p.append((x,y))
   d.line(p,fill=(97,95,82,50),width=2)
 image.filter(ImageFilter.GaussianBlur(.25)).save(texture_dir/(name+'.png'))
