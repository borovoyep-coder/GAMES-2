"""Valley 0.4: photo-traced layout, all visual assets authored/exported in Blender."""
from pathlib import Path
import os
BASE=Path(__file__).resolve().parent/'build_valley.py'
text=BASE.read_text();exec(compile(text[:text.index('start=time.time();build_environment()')],str(BASE),'exec'),globals())
from mathutils.geometry import delaunay_2d_cdt
TRACE=json.loads((ROOT/'SourceArt/Reference/ReferenceTrace.json').read_text())
R=random.Random(1504)
HERO_PATHS=[[xy(p) for p in r['Points']] for r in LAYOUT['JunglePaths']]
BYPASSES=[[xy(p) for p in r['Points']] for r in LAYOUT['BypassRoutes']]
TOWERS=LAYOUT['TowerSlots'];RIVER=[xy(p) for p in LAYOUT['River']['Points']]
BOSS_RADIUS=LAYOUT['BossRadius'];HALF_RIVER=LAYOUT['RiverHalfWidth']

# Match the native export's painted projection in Blender's renders as well.
# Water keeps its authored longitudinal UVs; all other surfaces use world projection.
for name,mat in MATERIALS.items():
 if name=='Water':continue
 nodes=mat.node_tree.nodes;links=mat.node_tree.links;geo=nodes.new('ShaderNodeNewGeometry');separate=nodes.new('ShaderNodeSeparateXYZ');links.new(geo.outputs['Position'],separate.inputs[0]);combine=nodes.new('ShaderNodeCombineXYZ')
 for axis,coeffs in [('X',(.18,.13)),('Y',(.18,.07))]:
  mul=nodes.new('ShaderNodeMath');mul.operation='MULTIPLY';mul.inputs[1].default_value=coeffs[0];links.new(separate.outputs[axis],mul.inputs[0]);height=nodes.new('ShaderNodeMath');height.operation='MULTIPLY';height.inputs[1].default_value=coeffs[1];links.new(separate.outputs['Z'],height.inputs[0]);add=nodes.new('ShaderNodeMath');add.operation='ADD';links.new(mul.outputs[0],add.inputs[0]);links.new(height.outputs[0],add.inputs[1]);links.new(add.outputs[0],combine.inputs[axis])
 links.new(combine.outputs[0],next(n for n in nodes if n.type=='TEX_IMAGE').inputs['Vector'])

def point_in(p,poly):
 result=False
 for i,a in enumerate(poly):
  b=poly[i-1]
  if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0]:result=not result
 return result

def on_paths(p,paths,width):return any(near_segment(p,a,b)<width for line in paths for a,b in zip(line,line[1:]))
def protected(p,extra=0):return on_lane(p,4.3+extra) or on_paths(p,BYPASSES,1.75+extra) or on_paths(p,HERO_PATHS,1.7+extra)
def catmull(points,steps=4):
 result=[]
 for i in range(len(points)-1):
  a=Vector(points[max(0,i-1)]);b=Vector(points[i]);c=Vector(points[i+1]);d=Vector(points[min(len(points)-1,i+2)])
  for j in range(steps):
   t=j/steps;p=(b*2+(-a+c)*t+(a*2-b*5+c*4-d)*t*t+(-a+b*3-c*3+d)*t*t*t)*.5;result.append(tuple(p))
 result.append(points[-1]);return result
SMOOTH_RIVER=RIVER
def sample_path(path,d):
 for a,b in zip(path,path[1:]):
  length=math.dist(a,b)
  if d<=length:
   t=max(0,d/length);return (a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t),math.atan2(b[1]-a[1],b[0]-a[0])
  d-=length
 return path[-1],math.atan2(path[-1][1]-path[-2][1],path[-1][0]-path[-2][0])
RIVER_LENGTH=sum(math.dist(a,b) for a,b in zip(SMOOTH_RIVER,SMOOTH_RIVER[1:]))
def surface_banks():
 left=[];right=[]
 for i,p in enumerate(SMOOTH_RIVER):
  a=SMOOTH_RIVER[max(0,i-1)];b=SMOOTH_RIVER[min(len(SMOOTH_RIVER)-1,i+1)];dx=b[0]-a[0];dy=b[1]-a[1];length=math.hypot(dx,dy);n=(-dy/length,dx/length)
  left.append((p[0]+n[0]*HALF_RIVER,p[1]+n[1]*HALF_RIVER));right.append((p[0]-n[0]*HALF_RIVER,p[1]-n[1]*HALF_RIVER))
 return left,right
BANK_LEFT,BANK_RIGHT=surface_banks()

def mesh_object(name,verts,faces,color,material,uv=None):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);CURRENT.objects.link(o);o.color=(*rgb(color),1);o['art_color']=list(rgb(color));o['art_material']=material;me.materials.append(MATERIALS[material])
 if uv:
  layer=me.uv_layers.new(name='FlowUV')
  for polygon in me.polygons:
   for loop in polygon.loop_indices:layer.data[loop].uv=uv[me.loops[loop].vertex_index]
  o['uv_mode']='explicit'
 return o

def terrain():
 outer=[(-62,-62),(62,-62),(62,62),(-62,62)];hole=BANK_LEFT+list(reversed(BANK_RIGHT));verts=outer+hole
 edges=[(i,(i+1)%4) for i in range(4)]+[(4+i,4+(i+1)%len(hole)) for i in range(len(hole))]
 v,e,f,*_=delaunay_2d_cdt([Vector(p) for p in verts],edges,[],0,.0001)
 faces=[]
 for face in f:
  center=(sum(v[i].x for i in face)/len(face),sum(v[i].y for i in face)/len(face))
  if not point_in(center,hole):faces.append(tuple(face))
 mesh_object('Terrain with smooth river channel',[(p.x,p.y,-.1) for p in v],faces,'grass','Ground')
 # Real curved water ribbon with longitudinal UVs.
 verts=[];uv=[];faces=[];travel=0
 for i,p in enumerate(SMOOTH_RIVER):
  if i:travel+=math.dist(SMOOTH_RIVER[i-1],p)
  for side,q in enumerate([BANK_LEFT[i],p,BANK_RIGHT[i]]):verts.append((q[0],q[1],-.43+(0 if side!=1 else .018)));uv.append((side*.5,travel*.14))
  if i:
   j=i*3
   for k in range(2):faces.append((j-3+k,j-3+k+1,j+k+1,j+k))
 water=mesh_object('Curved river surface with flow UV',verts,faces,'water','Water',uv)
 # Blender material animation is stored in the source .blend, in addition to Unity flow.
 nodes=MATERIALS['Water'].node_tree.nodes;links=MATERIALS['Water'].node_tree.links;tex=next(n for n in nodes if n.type=='TEX_IMAGE');mapping=nodes.new('ShaderNodeMapping');coords=nodes.new('ShaderNodeTexCoord');links.new(coords.outputs['UV'],mapping.inputs['Vector']);links.new(mapping.outputs['Vector'],tex.inputs['Vector']);mapping.inputs['Location'].default_value=(0,0,0);mapping.inputs['Location'].keyframe_insert('default_value',frame=1);mapping.inputs['Location'].default_value=(0,-3,0);mapping.inputs['Location'].keyframe_insert('default_value',frame=241)
 if MATERIALS['Water'].node_tree.animation_data:
  for curve in MATERIALS['Water'].node_tree.animation_data.action.fcurves:
   for key in curve.keyframe_points:key.interpolation='LINEAR'
   curve.modifiers.new('CYCLES')
 return water

PATH_SURFACES=[];FOOTPATH_STONES=[]
def path_strip(points,width,color='A7986D',tiles=False):
 # A continuous joined ribbon avoids overlapping slabs at curved path joints.
 if len(points)<2:return
 verts=[];faces=[];uv=[];travel=0
 for i,p in enumerate(points):
  a=points[max(0,i-1)];b=points[min(len(points)-1,i+1)];dx=b[0]-a[0];dy=b[1]-a[1];l=math.hypot(dx,dy) or 1;n=(-dy/l,dx/l)
  if i:travel+=math.dist(points[i-1],p)
  verts.extend([(p[0]+n[0]*width/2,p[1]+n[1]*width/2,.045),(p[0]-n[0]*width/2,p[1]-n[1]*width/2,.045)]);uv.extend([(0,travel*.3),(1,travel*.3)])
  if i:faces.append((i*2-2,i*2-1,i*2+1,i*2))
 # Collect contours: intersections must share a single surface, not coplanar ribbons.
 PATH_SURFACES.append(([(p[0],p[1]) for p in verts[::2]]+[(p[0],p[1]) for p in reversed(verts[1::2])],color))
 if tiles:
  length=sum(math.dist(a,b) for a,b in zip(points,points[1:]));d=.4
  while d<length:
   p,a=sample_path(points,d);color=R.choice(['stone','lightstone'])
   if not any(math.dist(p,q)<.4 for q in FOOTPATH_STONES):
    # Slightly varied real slab heights prevent coplanar intersections at curved entries.
    z=.075+.012*math.sin(len(FOOTPATH_STONES)*2.399);FOOTPATH_STONES.append(p);box('Footpath stepping stone',(p[0],p[1],z),(.9,width*.65,.08),color,'Stone',.035,a)
   d+=1.25

def merge_footpaths():
 vertices=[];edges=[]
 for polygon,color in PATH_SURFACES:
  offset=len(vertices);vertices.extend(Vector(p) for p in polygon);edges.extend((offset+i,offset+(i+1)%len(polygon)) for i in range(len(polygon)))
 v,e,faces,*_=delaunay_2d_cdt(vertices,edges,[],0,.00001)
 kept=[]
 for face in faces:
  center=(sum(v[i].x for i in face)/len(face),sum(v[i].y for i in face)/len(face))
  if any(point_in(center,polygon) for polygon,color in PATH_SURFACES):kept.append(tuple(face))
 mesh_object('Unified forest paths and tower passages',[(p.x,p.y,.045) for p in v],kept,'989B5C','Ground')

def stone_wall(center,length,angle=0,width=.85,height=1.5):
 n=max(1,math.ceil(length/1.5));step=length/n
 for i in range(n):
  q=rotate(((i+.5)*step-length/2,0),angle);x,y=center[0]+q[0],center[1]+q[1]
  for level in range(2):box('Reference ruin brick',(x,y,.38+level*.55),(step-.045,width,.52),R.choice(['stone','lightstone','C0B08C']),'Stone',.045,angle)
  box('Wall narrow coping',(x,y,1.28),(step-.025,width+.14,.15),'lightstone','Stone',.035,angle)
  if i==0 or i==n-1:
   box('Wall end pillar',(x,y,.7),(width+.13,width+.13,1.4),'stone','Stone',.05,angle);box('Non-overlapping pillar cap',(x,y,1.48),(width+.28,width+.28,.14),'goldlight','Stone',.025,angle)
  if i%3==0:
   for k in range(2):sphere('Wall moss',(x+R.uniform(-.3,.3),y+R.uniform(-.25,.25),1.4),(.2,.2,.09),'moss','Foliage',0)

def bush_geometry(x,y,scale=1):
 # Curved individual leaves, rather than spherical stand-ins.
 for i in range(18):
  a=i*2*pi/18+R.uniform(-.2,.2);r=R.uniform(.1,.6)*scale;h=R.uniform(.65,1.3)*scale;lean=R.uniform(.25,.65)*scale;width=R.uniform(.06,.12)*scale;cx=x+math.cos(a)*r;cy=y+math.sin(a)*r;tx=cx+math.cos(a)*lean;ty=cy+math.sin(a)*lean;side=(-math.sin(a)*width,math.cos(a)*width)
  vertices=[(cx-side[0],cy-side[1],.02),(cx+side[0],cy+side[1],.02),(tx+side[0]*.5,ty+side[1]*.5,h*.68),(tx,ty,h),(tx-side[0]*.5,ty-side[1]*.5,h*.68)]
  mesh_object('Sculpted brush leaf',vertices,[(0,1,2,4),(4,2,3)],R.choice(['8DA943','A0B64F','B8C466','6F963D']),'Foliage')

def build_environment():
 collection('Environment');terrain()
 for lane in LANES:
  # Real individual pavers are clipped by a shared continuous road footprint.
  for a,b in zip(lane,lane[1:]):paving(a,b,6.7)
 for path in BYPASSES:path_strip(path,2.8,'A9945D',True)
 for path in HERO_PATHS:path_strip(path,2.45,'8F9952')
 for i,wall in enumerate(LAYOUT['Walls']):
  a=math.radians(wall['Angle']);stone_wall(xy(wall['Center']),wall['Size']['X'],a,wall['Size']['Y'])
 for p in BASES:floor_disc(p,8.8)
 # Exact photo glades: preserve their shape and separate them from forest islands.
 for pixel in [(354,574),(742,389),(553,832),(890,635)]:
  # Use the calibrated trace's existing world conversion through its homography.
  controls=TRACE['Calibration'];aa=[];bb=[]
  for (u,v),(x,y) in controls:aa.extend([[u,v,1,0,0,0,-x*u,-x*v],[0,0,0,u,v,1,-y*u,-y*v]]);bb.extend([x,y])
  import numpy as np
  H=np.r_[np.linalg.solve(aa,bb),1].reshape(3,3);q=H@np.array([*pixel,1]);p=(q[0]/q[2],q[1]/q[2]);cyl('Reference battle glade',(p[0],p[1],-.035),6.3,.055,'A4AA5E','Ground',32)
 for i,p in enumerate(BOSSES):
  radius=BOSS_RADIUS;floor_disc(p,radius,'D3BC94' if i==0 else '9E8CA9')
  for rr in [3.5,8,12.5,15]:ring('Boss sanctuary engraved rings',(p[0],p[1],.23),rr,.075,'goldlight' if i==0 else 'purple','Glow')
  for entry in LAYOUT['BossEntrances'][i]['Points']:path_strip([xy(entry),p],5.0,'B4A486',True)
  for j in range(26):
   a=j*2*pi/26;q=(p[0]+math.cos(a)*(radius-.25),p[1]+math.sin(a)*(radius-.25))
   if any(near_segment(q,xy(e),p)<3.1 for e in LAYOUT['BossEntrances'][i]['Points']):continue
   cyl('Arena pillar',(q[0],q[1],2),.48,3.8,'stone','Stone',10);cyl('Arena capital',(q[0],q[1],4),.68,.27,'gold','Metal',10);crystal('Arena magic ward',(q[0],q[1],4.15),.22,.9,'goldlight' if i==0 else 'purple')
 for i,p in enumerate(CAMPS):
  cyl('Monster camp earth',(p[0],p[1],-.055),3.8,.08,'8D9952','Ground',28)
  for j in range(8):
   a=j*2*pi/8;q=(p[0]+math.cos(a)*3.8,p[1]+math.sin(a)*3.8)
   if protected(q,.2):continue
   sphere('Camp boulder',(q[0],q[1],.18),(.4,.35,.27),'darkstone','Stone',0)
 # Border cliffs lie beyond the thin outer walkways; they no longer occupy the back passages.
 for side in range(4):
  for i in range(43):
   t=-62+i*2.95;x,y=(t,62) if side==0 else (t,-62) if side==1 else (62,t) if side==2 else (-62,t)
   if any(math.dist((x,y),p)<BOSS_RADIUS+1 for p in BOSSES):continue
   o=sphere('Blender cliff face',(x,y,-3.2),(R.uniform(1.6,2.5),R.uniform(1.4,2.6),R.uniform(3.8,6)),R.choice(['7C7C6D','6D756A','darkstone']),'Stone',1)
   if i%3==0:box('Cliff rock ledge',(x,y,-.35),(2.1,1.6,.75),'darkstone','Stone',.12,R.uniform(-.2,.2))
 for bank in [BANK_LEFT,BANK_RIGHT]:
  for i in range(0,len(bank),3):
   p=bank[i]
   if on_lane(p,4.2) or any(math.dist(p,b)<7.6 for b in BRIDGES):continue
   sphere('Natural curved riverbank',(p[0],p[1],-.16),(.52,.55,.42),'stone','Stone',0)
   if i%9==0:crystal('River-bank mineral',(p[0],p[1],.05),.12,.5,'azure')
 trees=[]
 islands=[[xy(p) for p in zone['Points']] for zone in LAYOUT['TreeIslands']]
 for ix in range(-60,61,2):
  for iy in range(-60,61,2):
   p=(ix+R.uniform(-.45,.45),iy+R.uniform(-.45,.45))
   if not any(point_in(p,polygon) for polygon in islands):continue
   if protected(p,1.0) or on_paths(p,[RIVER],HALF_RIVER+1.4) or any(math.dist(p,q)<4.7 for q in CAMPS) or any(math.dist(p,xy(t['Position']))<3.4 for t in TOWERS) or any(math.dist(p,q)<3 for q in CRYSTALS) or any(math.dist(p,q)<8 for q in BRIDGES):continue
   trees.append(p);tree(p,R.uniform(4.4,6.4),len(trees))
 for region in LAYOUT['BushZones']:
  polygon=[xy(p) for p in region['Points']];x0=min(p[0] for p in polygon);x1=max(p[0] for p in polygon);y0=min(p[1] for p in polygon);y1=max(p[1] for p in polygon)
  for i in range(max(5,int((x1-x0)*(y1-y0)*1.5))):
   x=R.uniform(x0,x1);y=R.uniform(y0,y1)
   if point_in((x,y),polygon):bush_geometry(x,y,R.uniform(.65,1))
 # Low grass is decorative; tall traced bush polygons alone provide concealment.
 for i in range(650):
  p=(R.uniform(-59,59),R.uniform(-59,59))
  if protected(p,.2) or on_paths(p,[RIVER],HALF_RIVER+.5) or any(math.dist(p,b)<9 for b in BASES):continue
  grass_clump(*p,.7)
 for side in range(4):
  for t in [-40,-25,-10,5,20,35]:
   p=(t,60.8) if side==0 else (60.8,t) if side==1 else (t,-60.8) if side==2 else (-60.8,t)
   if any(math.dist(p,b)<18 for b in BOSSES):continue
   cyl('Perimeter broken column',(p[0],p[1],1.65),.38,3.3,'stone','Stone',9);box('Column cap',(p[0],p[1],3.4),(1,1,.23),'lightstone')
 # Beyond the playable paths: a layered forest rim and the skyline ruins seen in the reference.
 for side in range(4):
  for i in range(30):
   t=-64+i*4.4;d=65.5+R.uniform(0,2.6);p=(t,d) if side==0 else (d,t) if side==1 else (t,-d) if side==2 else (-d,t)
   if any(math.dist(p,b)<BOSS_RADIUS+4 for b in BOSSES):continue
   tree(p,R.uniform(5.5,8.2),i+side*30)
 for x in [-27,-8,13,33]:
  y=61.5
  for side in [-1,1]:
   cyl('Skyline arch fluted pillar',(x+side*1.7,y,2.5),.4,5,'stone','Stone',10);box('Skyline capital',(x+side*1.7,y,5.1),(1.1,1.1,.3),'lightstone')
  for j in range(13):
   a=(j+.5)*pi/13;o=box('Skyline arch voussoir',(x+math.cos(a)*1.7,y,5.1+math.sin(a)*1.7),(.47,.8,.48),'lightstone','Stone',.03);o.rotation_euler.y=pi/2-a
 for x,y in [(-63,-27),(-63,16),(63,18),(63,-28),(-5,-63),(23,63)]:
  for j in range(6):box('Sculpted waterfall',(x+(j-2.5)*.42 if abs(y)>62 else x,y+(j-2.5)*.42 if abs(x)>62 else y,-3.8),(.48,.32,7.6),R.choice(['water','azure','foam']),'Water',.01)
  for j in range(4):sphere('Waterfall foam',(x+R.uniform(-1,1),y+R.uniform(-1,1),-7.5),(.7,.8,.18),'foam','Glow',0)
 merge_footpaths()
 positions=[{'X':round(p[0],4),'Y':round(p[1],4)} for p in trees];LAYOUT['TreeObstacles']=positions;(OUT/'ValleyLayout.json').write_text(json.dumps(LAYOUT,indent=2));(OUT/'ValleyVegetation.json').write_text(json.dumps({'Positions':positions}))
 (ROOT/'Assets/ShatteredWorld/Simulation/Map/ForestLayout.cs').write_text('namespace ShatteredWorld.Simulation { public static class ForestLayout { public static readonly V2[] Positions={'+','.join('new V2(%sf,%sf)'%(p['X'],p['Y']) for p in positions)+'}; } }')
 print('REFERENCE ENVIRONMENT:',len(trees),'trees,',len(LAYOUT['Walls']),'walls,',len(LAYOUT['BushZones']),'brush regions',flush=True)

# Sculpted tower profile replaces the old squat cylinders.
def lathe(name,profile,color,material='Stone',n=16):
 verts=[];faces=[]
 for z,r in profile:
  for i in range(n):a=i*2*pi/n;verts.append((math.cos(a)*r,math.sin(a)*r,z))
 for j in range(len(profile)-1):
  for i in range(n):faces.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
 faces.append(tuple(reversed(range(n))));faces.append(tuple((len(profile)-1)*n+i for i in range(n)));return mesh_object(name,verts,faces,color,material)

def tower(name,red=False,core=False):
 collection(name);c='red' if red else 'blue'
 if core:
  lathe('Stepped citadel foundation',[(0,3),(.2,3),(.3,2.7),(.6,2.7),(.7,2.3),(1,2.3)],'stone')
  for z,r in [(.25,2.95),(.68,2.5),(1.08,2.2)]:ring('Core gold architectural trim',(0,0,z),r,.13,'gold')
  crystal('Citadel main crystal',(0,0,1.15),.95,5.8,c)
  for i in range(6):
   a=i*pi/3;x=math.cos(a)*1.9;y=math.sin(a)*1.9;lathe('Citadel shrine column',[(0,.34),(1.8,.24),(2,.4)],'stone').location=(x,y,.7);crystal('Flanking royal crystal',(x,y,2.8),.33,1.8,c)
   polyline('Golden citadel ribs',[(math.cos(a)*2.8,math.sin(a)*2.8,.7),(x,y,2.8),(math.cos(a)*1.2,math.sin(a)*1.2,4)],.1,'gold','Metal')
  return CURRENT
 lathe('Tower sculpted masonry',[(0,1.62),(.16,1.62),(.25,1.44),(.46,1.44),(.54,1.08),(.74,.92),(1.55,.68),(1.98,.76),(2.12,1.03),(2.3,1.12)],'stone')
 for z,r,w in [(.19,1.52,.1),(.49,1.24,.1),(.72,.92,.11),(2.08,.9,.1),(2.31,1.12,.12)]:ring('Tower golden band',(0,0,z),r,w,'gold')
 for i in range(8):
  a=i*pi/4;x=math.cos(a)*.75;y=math.sin(a)*.75;limb('Tower fluted pilaster',(x,y,.8),(x*.87,y*.87,1.9),.055,'lightstone','Stone',.05)
 crystal('Tower spear crystal',(0,0,2.35),.42,1.85,c)
 for i in range(3):
  a=i*2*pi/3;points=[]
  for j in range(6):t=j/5;r=1.13-.58*t;points.append((math.cos(a)*r,math.sin(a)*r,2.05+1.3*t))
  polyline('Tower curved crystal cradle',points,.075,'gold','Metal');crystal('Small tower shard',(math.cos(a)*.7,math.sin(a)*.7,2.34),.16,.8,c)
 return CURRENT

def leviathan():
 collection('NightLeviathan');centers=[]
 for i in range(14):
  t=i/13;a=.2+t*pi*1.6;r=1.7-t*.7;p=(math.cos(a)*r,math.sin(a)*r+.6,1+math.sin(t*pi)*1.1);centers.append(p);s=.66*(1-t*.78);sphere('Segmented dragon body',p,(s,s*.9,s*.85),'obsidian','Obsidian',1);crystal('Abyss dorsal spine',(p[0],p[1],p[2]+s*.55),s*.22,s*.9,'purple')
 head=(.7,-1.6,2.65);limb('Raised serpent neck',centers[0],(.9,-1,2.5),.5,'514666','Obsidian',.39)
 sphere('Leviathan dragon head',head,(.64,.87,.52),'514666','Obsidian',1);sphere('Long dragon muzzle',(.7,-2.27,2.5),(.48,.66,.27),'obsidian','Obsidian',1);sphere('Dragon lower jaw',(.7,-2.18,2.29),(.49,.7,.13),'655476','Creature',1)
 for side in [-1,1]:
  crystal('Back swept dragon horn',(.7+side*.43,-1.3,2.95),.17,1.1,'D3B1ED',(.65,side*.25))
  sphere('Leviathan bright eye',(.7+side*.45,-2.02,2.85),(.13,.12,.1),'purple','Glow',0)
  for i in range(3):crystal('Dragon tooth',(.7+side*(.17+i*.1),-2.62,2.47),.04,.22,'lightstone',(pi,0))
  verts=[(side*.55,.6,2.2),(side*4.3,.5,4.1),(side*3.6,1.4,3),(side*4,2.6,2.3),(side*2.3,3.1,1.9),(side*.4,2.2,1.8),(side*1.8,1.65,2.9)]
  mesh_object('Scalloped dragon wing',verts,[(0,1,6),(1,2,6),(2,3,6),(3,4,6),(4,5,6),(5,0,6)],'744B83','Creature');polyline('Dragon wing bone',[verts[0],verts[1],verts[2],verts[3],verts[4],verts[5]],.085,'obsidian','Obsidian')
  for j in [1,3,4]:polyline('Luminous wing veins',[verts[0],verts[6],verts[j]],.026,'purple','Glow')
  limb('Dragon forelimb',(.7+side*.5,-.3,1.8),(.7+side*1,-1,.45),.13,'obsidian','Obsidian',.1)
  for j in range(3):limb('Dragon claw',(.7+side*1+j*.12,-1,.45),(.7+side*1+j*.12,-1.4,.22),.065,'lightstone','Creature',.012)
 return CURRENT

def extra_models():
 collection('BushCluster');bush_geometry(0,0,1.1)
 collection('RuinWallStraight');stone_wall((0,0),4,0,.85)
 collection('RuinWallBroken');stone_wall((0,0),2.5,0,.85);box('Fallen coping',(1.7,.25,.15),(.7,.7,.3),'stone','Stone',.05,.3)
 collection('RuinArch')
 for side in [-1,1]:cyl('Arch column',(side*1.6,0,1.4),.3,2.8,'stone','Stone',10)
 for i in range(12):
  a=(i+.5)*pi/12;o=box('Arch keystone',(math.cos(a)*1.6,0,2.8+math.sin(a)*1.6),(.48,.65,.48),'lightstone','Stone',.03);o.rotation_euler.y=pi/2-a
 collection('FirTree');tree((0,0),5.8,0)
 collection('CliffRock');sphere('Cliff module',(0,0,-1.6),(2.2,1.8,3.4),'darkstone','Stone',1)
 collection('FoamStreak');verts=[(-.05,-.8,0),(.03,-.4,0),(.06,.2,0),(.04,.65,0),(-.02,.8,0),(-.09,.1,0)];mesh_object('Tapered river foam',verts,[(0,1,2,5),(5,2,3,4)],'foam','Glow')

# Export fixes corner-key aliasing and preserves explicit river UVs.
old_export=export_bundle
export_text=text[text.index('def export_bundle('):text.index('def instance(')]
export_text=export_text.replace('key=(loop.vertex_index,normal)','corner_key=(loop.vertex_index,normal)').replace('if key not in cache:','if corner_key not in cache:').replace('cache[key]=len(vertices)//3','cache[corner_key]=len(vertices)//3').replace('triangle.append(cache[key])','triangle.append(cache[corner_key])')
export_text=export_text.replace("uvs.extend([round(v.x*.18+v.z*.13,4),round(v.y*.18+v.z*.07,4)])", "uv=mesh.uv_layers.active.data[loopid].uv if obj.get('uv_mode')=='explicit' and mesh.uv_layers.active else (v.x*.18+v.z*.13,v.y*.18+v.z*.07);uvs.extend([round(uv[0],4),round(uv[1],4)])")
exec(compile(export_text,str(BASE),'exec'),globals())

def export_fbx(name,c):
 directory=ROOT/'SourceArt/FBX';directory.mkdir(exist_ok=True)
 c.hide_viewport=False;c.hide_render=False;bpy.context.view_layer.update();bpy.ops.object.select_all(action='DESELECT');copies=[];deps=bpy.context.evaluated_depsgraph_get()
 for src in c.objects:
  if src.type!='MESH':continue
  evaluated=src.evaluated_get(deps);me=bpy.data.meshes.new_from_object(evaluated);o=bpy.data.objects.new(src.name,me);bpy.context.scene.collection.objects.link(o);o.matrix_world=Matrix.LocRotScale(src.location,src.rotation_euler.to_quaternion(),src.scale)
  if not me.uv_layers:
   uv=me.uv_layers.new(name='PaintedUV')
   for polygon in me.polygons:
    for loop in polygon.loop_indices:
     p=o.matrix_world@me.vertices[me.loops[loop].vertex_index].co;uv.data[loop].uv=(p.x*.18+p.z*.13,p.y*.18+p.z*.07)
  attr=me.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER');color=src.get('art_color',[.5,.5,.5])
  for value in attr.data:value.color=(*color,1)
  me.color_attributes.active_color=attr;o.select_set(True);copies.append(o)
 if copies:
  bpy.context.view_layer.objects.active=copies[0]
  bpy.ops.export_scene.fbx(filepath=str(directory/(name+'.fbx')),use_selection=True,axis_forward='-Z',axis_up='Y',add_leaf_bones=False,bake_anim=False,colors_type='LINEAR',path_mode='RELATIVE')
 for o in copies:me=o.data;bpy.data.objects.remove(o,do_unlink=True);bpy.data.meshes.remove(me)
 c.hide_viewport=True;c.hide_render=True

start=time.time();build_environment();golem('MagmaGuardian');golem('AzureGolem',True);golem('SolarColossus',False,True);wolf();centipede();ghost();crab();firefly();ray();leviathan();tower('TowerBlue');tower('TowerRed',True);tower('CoreBlue',False,True);tower('CoreRed',True,True);bridge();gate()
for red in [False,True]:
 suffix='Red' if red else 'Blue';hero('Warrior'+suffix,red);hero('Mage'+suffix,red,True);hero('Guard'+suffix,red,False,True);hero('Caster'+suffix,red,True,True);hero('Destroyer'+suffix,red,False,True,True)
extra_models();manifest={'Version':'0.4','Models':[],'Materials':[{'Name':name,'Texture':spec[0],'Emission':spec[1]} for name,spec in SPECS.items()]}
for name,c in list(COLLECTIONS.items()):manifest['Models'].append(export_bundle(name,c,name=='Environment'))
(OUT/'ArtManifest.json').write_text(json.dumps(manifest,indent=2))
for name,c in list(COLLECTIONS.items()):
 if name!='Environment':export_fbx(name,c)
for name,c in COLLECTIONS.items():
 if name!='Environment':c.hide_render=True;c.hide_viewport=True
preview=collection('PreviewUnits')
for team in [0,1]:instance(COLLECTIONS['CoreRed' if team else 'CoreBlue'],(*BASES[team],.24))
for slot in TOWERS:instance(COLLECTIONS['TowerRed' if slot['Team'] else 'TowerBlue'],(*xy(slot['Position']),.24))
models=['MagmaGuardian','MoonWolf','RiftGhost','AzureGolem','StoneCentipede','CrystalCrab'];counts=[1,3,3,1,2,1]
for i,p in enumerate(CAMPS):
 side=1 if i<6 else -1;typ=i%6
 for j in range(counts[typ]):dx,dy=(0,-j*1.4*side) if typ==2 else (j*1.4*side,0);instance(COLLECTIONS[models[typ]],(p[0]+dx,p[1]+dy,.18),0,1.1 if typ==1 and j==0 else .85 if typ==1 else 1)
for p in CRYSTALS:instance(COLLECTIONS['CrystalGate'],(*p,.02))
for i,p in enumerate(BRIDGES):
 if i==0:
  direction=LAYOUT['BridgeDirections'][i];angle=-math.atan2(direction['X'],direction['Y']);instance(COLLECTIONS['Bridge'],(*p,-.45),angle)
for i,p in enumerate(BOSSES):instance(COLLECTIONS['SolarColossus' if i==0 else 'NightLeviathan'],(*p,.24),0,1.3 if i else 1)
for i,p in enumerate([xy(p) for p in LAYOUT['RiftCreatures']]):instance(COLLECTIONS['ObserverFirefly' if i==0 else 'RiftRay'],(*p,.2))
# Actual animated foam meshes in Blender, authored from the same river centreline.
flow=collection('RiverFlow')
for i in range(42):
 objects=instance(COLLECTIONS['FoamStreak'],(0,0,-.34),target=flow)
 for o in objects:
  for frame in range(1,242,12):
   d=(i*RIVER_LENGTH/42+(frame-1)/24*1.6)%RIVER_LENGTH;p,a=sample_path(SMOOTH_RIVER,d);o.location=(p[0]+math.sin(i)*.8,p[1]+math.cos(i)*.8,-.34);o.rotation_euler.z=a-pi/2;o.keyframe_insert('location',frame=frame);o.keyframe_insert('rotation_euler',frame=frame)
  if o.animation_data:
   for curve in o.animation_data.action.fcurves:
    for key in curve.keyframe_points:key.interpolation='LINEAR'
    curve.modifiers.new('CYCLES')
scene,camera=setup_render();scene.frame_end=240;scene.render.fps=24;scene.cycles.samples=20;scene.render.resolution_x=1440;scene.render.resolution_y=1440;camera.data.ortho_scale=158;camera.location=(0,-112,155);camera.rotation_euler=(Vector((0,1,0))-camera.location).to_track_quat('-Z','Y').to_euler();scene.frame_set(1)
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SourceArt/ValleyOfShards.blend'),compress=True)
if os.environ.get('VALLEY_SKIP_RENDER')!='1':
 scene.render.filepath=str(PREVIEW/'Valley_Overview.png');bpy.ops.render.render(write_still=True)
 camera.location=(-27,-48,51);camera.rotation_euler=(Vector((-24,-3,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=65;scene.render.resolution_x=1280;scene.render.resolution_y=880;scene.render.filepath=str(PREVIEW/'Valley_Closeup.png');bpy.ops.render.render(write_still=True)
 COLLECTIONS['Environment'].hide_render=True;preview.hide_render=True;flow.hide_render=True;collection('CreatureGallery')
 names=models+['ObserverFirefly','RiftRay','SolarColossus','NightLeviathan']
 for i,name in enumerate(names):
  x=(i%5-2)*8;y=(i//5)*8;instance(COLLECTIONS[name],(x,y,0),0,.7 if i>=8 else 1,target=CURRENT);cyl('Gallery pedestal',(x,y,-.25),3,.4,'darkstone','Stone',32)
 camera.location=(0,-35,38);camera.rotation_euler=(Vector((0,3.7,1))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=43;scene.render.resolution_x=1500;scene.render.resolution_y=850;scene.render.filepath=str(PREVIEW/'Creature_Collection.png');bpy.ops.render.render(write_still=True)
print('REFERENCE BUILD COMPLETE',time.time()-start,flush=True)
