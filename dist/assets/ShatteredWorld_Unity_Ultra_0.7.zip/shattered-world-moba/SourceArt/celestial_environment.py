"""Joined road cross-sections keep curved pavers disjoint at their real edges."""
PAVER_POLYGONS=[]
def seamless_lane(points,width=6.7,foundation=True):
 length=sum(math.dist(a,b) for a,b in zip(points,points[1:]));step=1.39;count=math.ceil(length/step);step=length/count
 if foundation:path_strip(points,width+.12,'B7A387')
 def section(distance):
  p,_=sample_path(points,max(0,min(length,distance)));a,_=sample_path(points,max(0,distance-.16));b,_=sample_path(points,min(length,distance+.16));dx=b[0]-a[0];dy=b[1]-a[1];n=math.hypot(dx,dy) or 1;return p,(-dy/n,dx/n)
 for i in range(count):
  d=(i+.5)*step;p,_=sample_path(points,d)
  if any(math.dist(p,b)<8.4 for b in BASES) or any(math.dist(p,q)<1.0 for q in ROAD_CENTERS):continue
  ROAD_CENTERS.append(p);a,an=section(i*step+.028);b,bn=section((i+1)*step-.028)
  for j in range(5):
   lo=(j-2.5)*width/5+.018;hi=(j-1.5)*width/5-.018
   corners=[(a[0]+an[0]*lo,a[1]+an[1]*lo),(a[0]+an[0]*hi,a[1]+an[1]*hi),(b[0]+bn[0]*hi,b[1]+bn[1]*hi),(b[0]+bn[0]*lo,b[1]+bn[1]*lo)]
   PAVER_POLYGONS.append(corners)
 verts=[];faces=[]
 for i,p in enumerate(points):
  a=points[max(0,i-1)];b=points[min(len(points)-1,i+1)];dx=b[0]-a[0];dy=b[1]-a[1];n=math.hypot(dx,dy);verts.extend([(p[0]-dy/n*.09,p[1]+dx/n*.09,.245),(p[0]+dy/n*.09,p[1]-dx/n*.09,.245)])
  if i:faces.append((i*2-2,i*2-1,i*2+1,i*2))
 mesh_object('Divine continuous golden lane centre',verts,faces,'FBD26B','Glow')


def build_joined_pavers():
 from mathutils.geometry import delaunay_2d_cdt
 vertices=[];edges=[];grid={}
 for index,polygon in enumerate(PAVER_POLYGONS):
  offset=len(vertices);vertices.extend(Vector(p) for p in polygon);edges.extend((offset+j,offset+(j+1)%4) for j in range(4))
  for x in range(math.floor(min(p[0] for p in polygon)/4),math.floor(max(p[0] for p in polygon)/4)+1):
   for y in range(math.floor(min(p[1] for p in polygon)/4),math.floor(max(p[1] for p in polygon)/4)+1):grid.setdefault((x,y),[]).append(index)
 v,e,faces,*_=delaunay_2d_cdt(vertices,edges,[],0,.00001);groups={}
 def inside(p,polygon):
  result=False
  for i,a in enumerate(polygon):
   b=polygon[i-1]
   if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0]:result=not result
  return result
 for face in faces:
  p=(sum(v[i].x for i in face)/len(face),sum(v[i].y for i in face)/len(face))
  for index in grid.get((math.floor(p[0]/4),math.floor(p[1]/4)),[]):
   if inside(p,PAVER_POLYGONS[index]):groups.setdefault(index,[]).append(tuple(face));break
 for index,triangles in groups.items():
  ids=sorted(set(i for f in triangles for i in f));mapping={i:j for j,i in enumerate(ids)};n=len(ids);verts=[(v[i].x,v[i].y,z) for z in [.075,.22] for i in ids];polygons=[];boundary={}
  for f in triangles:
   # CDT returns an upward-oriented partition of the road union, including tight inner corners.
   a,b,c=[v[i] for i in f[:3]]
   if (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)<0:f=tuple(reversed(f))
   local=tuple(mapping[i] for i in f);polygons.append(tuple(reversed(local)));polygons.append(tuple(i+n for i in local))
   for j,a in enumerate(local):
    b=local[(j+1)%len(local)];key=tuple(sorted((a,b)))
    if key in boundary:del boundary[key]
    else:boundary[key]=(a,b)
  for a,b in boundary.values():polygons.append((a,b,b+n,a+n))
  obj=mesh_object('Joined sandstone lane tile',verts,polygons,'D6C2A5','Stone');mod=obj.modifiers.new('Small paver edge chamfer','BEVEL');mod.width=.008;mod.segments=1;mod.limit_method='ANGLE'
  mod=obj.modifiers.new('Weighted paver corner normals','WEIGHTED_NORMAL');mod.keep_sharp=True
 # Apply the tiny chamfers and remove collapsed sub-millimetre faces at clipped inner corners.
 bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get()
 for obj in list(CURRENT.objects):
  if not obj.name.startswith('Joined sandstone lane tile'):continue
  mesh=bpy.data.meshes.new_from_object(obj.evaluated_get(deps));bm=bmesh.new();bm.from_mesh(mesh)
  bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00003)
  bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.00003)
  for face in list(bm.faces):
   if face.calc_area()<.0000001:bm.faces.remove(face)
  bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
  for face in bm.faces:
   low=min(v.co.z for v in face.verts);high=max(v.co.z for v in face.verts)
   if low>.219 and face.normal.z<-.8:face.normal_flip()
   if high<.076 and face.normal.z>.8:face.normal_flip()
  bm.to_mesh(mesh);bm.free();mesh.update();obj.modifiers.clear();obj.data=mesh
 print('PAVING UNION',len(groups),'disjoint cut tiles',flush=True)
