"""Preserve the photo trace, then add playable fountain and gated-shortcut definitions."""
from pathlib import Path
import json,math
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Assets/ShatteredWorld/Art/Source';path=OUT/'ValleyLayout.json'
l=json.loads(path.read_text())
backup=ROOT/'SourceArt/Reference/ValleyLayout04.json'
if not backup.exists():backup.write_text(json.dumps(l,indent=2))
else:l=json.loads(backup.read_text())
# The headwater enters from the northern cliff; the tail leaves under the eastern road.
l['River']['Points']=[{'X':-35,'Y':61},{'X':-35,'Y':55},{'X':-34.6,'Y':48},{'X':-34.4,'Y':43}]+l['River']['Points']+[{'X':48,'Y':-38},{'X':55,'Y':-41},{'X':62,'Y':-44}]
def xy(p):return p['X'],p['Y']
def v(p):return {'X':round(p[0],5),'Y':round(p[1],5)}
def dist(p,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy or 1)));return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)
def near(p,paths):return min(dist(p,xy(a),xy(b)) for line in paths for a,b in zip(line['Points'],line['Points'][1:]))
def segs(line):return zip(line['Points'],line['Points'][1:])
def nearest(p,paths):
 out=None
 for line in paths:
  for aa,bb in segs(line):
   a,b=xy(aa),xy(bb);d=dist(p,a,b)
   if out is None or d<out[0]:
    dx=b[0]-a[0];dy=b[1]-a[1];n=math.hypot(dx,dy);t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(n*n)));out=(d,(dx/n,dy/n),(a[0]+t*dx,a[1]+t*dy))
 return out
l['Fountains']=[v((p['X']+(-6.8 if i==0 else 6.8),p['Y']+(-6.8 if i==0 else 6.8))) for i,p in enumerate(l['Bases'])]
l['CrystalShortcuts']=[];l['CrystalDirections']=[];gatewalls=[]
for i,old in enumerate(l['Crystals']):
 p=xy(old);distance,direction,foot=nearest(p,l['Lanes'])
 if distance<6.3:
  dx=p[0]-foot[0];dy=p[1]-foot[1];n=math.hypot(dx,dy);p=(foot[0]+dx/n*6.3,foot[1]+dy/n*6.3)
 # Bank gates follow the river; other gates follow the nearest forest trail.
 _,direction,_=nearest(p,[l['River']] if near(p,[l['River']])<7 else l['JunglePaths'])
 best=None
 for j in range(16):
  angle=math.atan2(direction[1],direction[0])+(j//2+1)*(1 if j%2 else -1)*math.pi/32 if j else math.atan2(direction[1],direction[0]);d=(math.cos(angle),math.sin(angle))
  a=(p[0]-d[0]*5.6,p[1]-d[1]*5.6);b=(p[0]+d[0]*5.6,p[1]+d[1]*5.6)
  if min(near(a,[l['River']]),near(b,[l['River']]))<3.2:continue
  if max(abs(a[0]),abs(a[1]),abs(b[0]),abs(b[1]))>60:continue
  score=abs(j)*.1+max(0,3.6-near(a,l['Lanes']))*2+max(0,3.6-near(b,l['Lanes']))*2
  if best is None or score<best[0]:best=(score,d,a,b)
 assert best is not None,i
 _,d,a,b=best;l['Crystals'][i]=v(p);l['CrystalDirections'].append(v(d));l['CrystalShortcuts'].append({'Points':[v(a),v(p),v(b)]})
 n=(-d[1],d[0])
 for side in [-1,1]:
  for k in range(6):
   r=2.4+(k+.5)*1.15;q=(p[0]+n[0]*r*side,p[1]+n[1]*r*side)
   if near(q,l['Lanes'])<4.5 or near(q,l['BypassRoutes'])<2.3 or any(math.dist(q,xy(c))<4.7 for c in l['Camps']):continue
   gatewalls.append({'Center':v(q),'Size':v((1.15,.95)),'Angle':round(math.degrees(math.atan2(n[1],n[0])),5)})
l['CrystalDetours']=[]
for index in [6]:
 shortcut=l['CrystalShortcuts'][index];a=xy(shortcut['Points'][0]);b=xy(shortcut['Points'][-1]);d=xy(l['CrystalDirections'][index]);normal=(-d[1],d[0]);options=[]
 for side in [-1,1]:
  aa=(a[0]+normal[0]*12*side,a[1]+normal[1]*12*side);bb=(b[0]+normal[0]*12*side,b[1]+normal[1]*12*side)
  samples=[(u[0]+(v[0]-u[0])*t/12,u[1]+(v[1]-u[1])*t/12) for u,v in [(a,aa),(aa,bb),(bb,b)] for t in range(13)]
  score=min(near(p,[l['River']]) for p in samples)
  if max(max(abs(p[0]),abs(p[1])) for p in samples)<60:options.append((score,[a,aa,bb,b]))
 assert options;points=max(options,key=lambda o:o[0])[1];l['CrystalDetours'].append({'Points':[v(p) for p in points]})
def clear_wall(w):
 p=xy(w['Center']);angle=math.radians(w['Angle']);d=(math.cos(angle),math.sin(angle));length=w['Size']['X'];n=max(1,math.ceil(length/.95));out=[];run=[]
 def flush():
  if not run:return
  t=(run[0]+run[-1]+1)*length/(2*n)-length/2;q=(p[0]+d[0]*t,p[1]+d[1]*t)
  out.append({'Center':v(q),'Size':v((len(run)*length/n,w['Size']['Y'])),'Angle':w['Angle']});run.clear()
 for i in range(n):
  t=(i+.5)*length/n-length/2;q=(p[0]+d[0]*t,p[1]+d[1]*t)
  if near(q,l['CrystalShortcuts']+l['CrystalDetours'])<2.0:flush();continue
  run.append(i)
 flush()
 return out
# Small blocks preserve the visible contour while cutting only the new openings.
l['Walls']=[b for wall in l['Walls'] for b in clear_wall(wall)]+[w for w in gatewalls if near(xy(w['Center']),l['CrystalShortcuts'])>2.0]
l['JunglePaths']+=l['CrystalShortcuts']+l['CrystalDetours']
l['TreeObstacles']=json.loads((OUT/'ValleyVegetation.json').read_text())['Positions']
l['TreeObstacles']=[p for p in l['TreeObstacles'] if near(xy(p),l['CrystalShortcuts']+l['CrystalDetours'])>2.5]
(OUT/'ValleyVegetation.json').write_text(json.dumps({'Positions':l['TreeObstacles']}))
(ROOT/'Assets/ShatteredWorld/Simulation/Map/ForestLayout.cs').write_text('namespace ShatteredWorld.Simulation { public static class ForestLayout { public static readonly V2[] Positions={'+','.join('new V2(%sf,%sf)'%(p['X'],p['Y']) for p in l['TreeObstacles'])+'}; } }')
# Parapets drawn along the banks in the image; gaps at the lane and two bridges are deliberate.
rail_pixels=[[(289,348),(304,373),(318,398)],[(337,449),(365,470),(389,487)],[(454,511),(482,535),(512,550)],[(563,580),(588,596)],[(651,654),(684,685),(712,711)],[(789,759),(825,777),(865,794)],[(900,812),(930,834)],[(359,371),(372,402),(394,427)],[(470,470),(500,489),(526,503)],[(563,530),(598,548)],[(677,603),(705,626)],[(804,706),(847,728),(878,746)],[(935,773),(966,793)]]
trace=json.loads((ROOT/'SourceArt/Reference/ReferenceTrace.json').read_text())
import numpy as np
a=[];b=[]
for (u,y),(x,z) in trace['Calibration']:a.extend([[u,y,1,0,0,0,-x*u,-x*y],[0,0,0,u,y,1,-z*u,-z*y]]);b.extend([x,z])
h=np.r_[np.linalg.solve(a,b),1].reshape(3,3)
def world(p):q=h@np.array([*p,1]);return v((q[0]/q[2],q[1]/q[2]))
l['RiverRailings']=[{'Points':[world(p) for p in line]} for line in rail_pixels]
l['BankWalls']=[]
for route0 in l['RiverRailings']:
 for aa,bb in segs(route0):
  a,b=xy(aa),xy(bb);length=math.dist(a,b);n=max(1,math.ceil(length/1.4));angle=math.degrees(math.atan2(b[1]-a[1],b[0]-a[0]))
  for k in range(n):
   t=(k+.5)/n;p=(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)
   _,direction,foot=nearest(p,[l['River']]);normal=(-direction[1],direction[0]);side=1 if (p[0]-foot[0])*normal[0]+(p[1]-foot[1])*normal[1]>=0 else -1
   p=(foot[0]+normal[0]*(l['RiverHalfWidth']+.35)*side,foot[1]+normal[1]*(l['RiverHalfWidth']+.35)*side);angle=math.degrees(math.atan2(direction[1],direction[0]))
   if near(p,l['Lanes'])<4.6 or near(p,l['JunglePaths'])<2.2 or any(math.dist(p,xy(q))<8.0 for q in l['Bridges']) or any(math.dist(p,xy(q))<4.7 for q in l['Camps']):continue
   l['BankWalls'].append({'Center':v(p),'Size':v((length/n,.6)),'Angle':round(angle,5)})
path.write_text(json.dumps(l,indent=2))
def f(x):return (f'{float(x):.6f}'.rstrip('0').rstrip('.') or '0')+'f'
def cv(p):return 'new V2('+f(p['X'])+','+f(p['Y'])+')'
def route(r):return 'new LaneRoute('+','.join(cv(p) for p in r['Points'])+')'
lines=['namespace ShatteredWorld.Simulation { public static class ReferenceMapData { public static void Apply(MapLayout m) {','m.HalfSize=80;m.BossRadius=16;m.RiverHalfWidth=2.65f;']
for name in ['Bases','Fountains','Bridges','Crystals','CrystalDirections','Camps','RiftCreatures','Bosses','Bushes','BridgeDirections']:lines.append('m.'+name+'=new V2[]{'+','.join(cv(p) for p in l[name])+'};')
for name in ['Lanes','BypassRoutes','JunglePaths','TowerPassages','BossEntrances','BushZones','TreeIslands','CrystalShortcuts','RiverRailings']:lines.append('m.'+name+'=new LaneRoute[]{'+','.join(route(r) for r in l[name])+'};')
lines.append('m.River='+route(l['River'])+';')
lines.append('m.TowerSlots=new TowerSlot[]{'+','.join('new TowerSlot{Team=%s,Lane=%s,Tier=%s,Position=%s}'%(p['Team'],p['Lane'],p['Tier'],cv(p['Position'])) for p in l['TowerSlots'])+'};')
lines.append('m.Walls=new MapBlock[]{'+','.join('new MapBlock('+cv(w['Center'])+','+cv(w['Size'])+','+f(w['Angle'])+')' for w in l['Walls'])+'};')
lines.append('m.BankWalls=new MapBlock[]{'+','.join('new MapBlock('+cv(w['Center'])+','+cv(w['Size'])+','+f(w['Angle'])+')' for w in l['BankWalls'])+'};')
lines.append('} } }');(ROOT/'Assets/ShatteredWorld/Simulation/Map/ReferenceMapData.cs').write_text('\n'.join(lines))
print('0.5 layout:',len(l['Walls']),'masonry blocks, 8 gated shortcuts, 2 rear fountains, 13 bank railings')
