"""Read back the saved master scene. This never modifies or re-saves it."""
import bpy,json,math
from pathlib import Path
root=Path(__file__).resolve().parents[1]
print('Opening saved Blender 0.5 master for read-back validation',flush=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'SourceArt/ValleyOfShards.blend'))
source=root/'Assets/ShatteredWorld/Art/Source';manifest=json.loads((source/'ArtManifest.json').read_text());layout=json.loads((source/'ValleyLayout.json').read_text())
assert manifest['Version']=='0.5'
assert bpy.context.scene.get('river_banks_closed')
for model in manifest['Models']:
 c=bpy.data.collections.get(model['Name']);assert c and any(o.type=='MESH' for o in c.objects),model['Name']
print('PASS',len(manifest['Models']),'editable model collections including surrounding landscape and rear fountains',flush=True)
images=[i for i in bpy.data.images if i.source=='FILE'];assert len(images)==6 and all(i.packed_file for i in images)
water=next(o for o in bpy.data.collections['Environment'].objects if o.name.startswith('Curved river surface'))
assert len(water.data.vertices)==len(layout['River']['Points'])*3
assert water.data.vertices[0].co.z>water.data.vertices[-1].co.z+.4
assert water.data.uv_layers.active and bpy.data.materials['Water'].node_tree.animation_data
assert len([o for o in bpy.data.collections['Environment'].objects if o.name.startswith('Closed mossy riverbank')])==2
foam=bpy.data.collections['RiverFlow'];assert len(foam.objects)==64 and all(o.animation_data for o in foam.objects)
print('PASS 6 packed textures, downhill river geometry, longitudinal flow UV and 64 animated foam meshes',flush=True)
for name in ['GuardBlue','CasterBlue','DestroyerBlue','GuardRed','CasterRed','DestroyerRed']:
 for clip in ['Idle','Walk','Attack','Death','Spawn']:
  actions=[a for a in bpy.data.actions if a.name.startswith(name+'.'+clip+'.')];assert actions,(name,clip)
  assert any(len(a.fcurves)>0 and a.frame_range[1]>a.frame_range[0] for a in actions)
 walk=bpy.data.actions[name+'.Walk.'+('WheelL0' if name.startswith('Destroyer') else 'LegL')]
 curve=next(c for c in walk.fcurves if c.data_path=='rotation_euler' and c.array_index==0)
 assert abs(curve.evaluate(6)-curve.evaluate(15))>.2
print('PASS 30 articulated clips have real saved Blender actions and changing limb/wheel transforms',flush=True)
preview=bpy.data.collections['PreviewUnits'];towers=[o for o in preview.objects if o.name.startswith('Tower spear crystal')];assert len(towers)==18
for slot in layout['TowerSlots']:
 p=slot['Position'];assert any(math.hypot(o.location.x-p['X'],o.location.y-p['Y'])<.001 for o in towers)
assert bpy.data.collections['Backdrop'].objects
print('PASS explicit photo tower anchors and nonempty 3D backdrop',flush=True)
print('ULTRA BLENDER SOURCE VALIDATION COMPLETE',flush=True)
