using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using ShatteredWorld.Simulation;
using ShatteredWorld.Unity;

namespace ShatteredWorld.Editor
{
    public static class ValleyArtImporter
    {
        const string Source="Assets/ShatteredWorld/Art/Source/";
        const string Generated="Assets/ShatteredWorld/Art/Generated/";
        public const string CatalogPath="Assets/ShatteredWorld/Resources/ValleyArtCatalog.asset";
        public const string ShowcasePath="Assets/ShatteredWorld/Scenes/ValleyShowcase.unity";
        public const string SceneVersionPath="Assets/ShatteredWorld/Art/Generated/SceneVersion.txt";

        [MenuItem("Shattered World/Art/Rebuild native meshes and prefabs")]
        public static void Rebuild(){EnsureGenerated(true);AssetDatabase.SaveAssets();ProjectGenerator.Generate();}

        public static ValleyArtCatalog EnsureGenerated(bool force=false)
        {
            var existing=AssetDatabase.LoadAssetAtPath<ValleyArtCatalog>(CatalogPath);
            string manifestPath=Source+"ArtManifest.json";
            if(!File.Exists(manifestPath)){Debug.LogWarning("Valley art source has not been generated. Legacy blockout remains available.");return null;}
            var manifest=JsonUtility.FromJson<ArtManifestData>(File.ReadAllText(manifestPath));
            if(existing&&!force&&existing.Version==manifest.Version)return existing;
            Directory.CreateDirectory(Generated+"Meshes");Directory.CreateDirectory(Generated+"Materials");Directory.CreateDirectory(Generated+"Prefabs");Directory.CreateDirectory(Generated+"Animations");Directory.CreateDirectory("Assets/ShatteredWorld/Resources");
            AssetDatabase.Refresh();
            var shader=Shader.Find("Shattered World/Painted World");
            if(!shader)throw new InvalidOperationException("Painted World shader is missing; wait for Unity to import the shader before rebuilding art.");
            var palette=new Dictionary<string,Material>();
            foreach(var definition in manifest.Materials)
            {
                string path=Generated+"Materials/"+definition.Name+".mat";
                var material=AssetDatabase.LoadAssetAtPath<Material>(path);
                if(!material){material=new Material(shader);AssetDatabase.CreateAsset(material,path);}
                material.shader=shader;material.SetColor("_BaseColor",Color.white);
                material.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/ShatteredWorld/Art/Textures/"+definition.Texture+".png"));
                material.SetFloat("_EmissionStrength",definition.Emission);
                material.SetFloat("_WindStrength",definition.Name=="Foliage"?.09f:0);
                material.SetFloat("_FlowSpeed",(definition.Name=="Water"||definition.Name=="SkyWater")?.08f:0);material.SetVector("_FlowDirection",new Vector4(0,-1,0,0));
                material.SetFloat("_WaterSurface",(definition.Name=="Water"||definition.Name=="SkyWater")?1:0);
                material.SetFloat("_SpecularStrength",(definition.Name=="Water"||definition.Name=="SkyWater")?.8f:definition.Name=="Metal"?.52f:definition.Name=="Crystal"?.6f:.08f);
                material.SetFloat("_ShadeStrength",.72f);material.enableInstancing=true;
                EditorUtility.SetDirty(material);palette.Add(definition.Name,material);
            }
            var entries=new List<ArtModelReference>();
            try
            {
                for(int modelIndex=0;modelIndex<manifest.Models.Length;modelIndex++)
                {
                    var model=manifest.Models[modelIndex];
                    EditorUtility.DisplayProgressBar("Valley of Shards — import",model.Name,(float)modelIndex/manifest.Models.Length);
                    var data=JsonUtility.FromJson<ArtBundleData>(File.ReadAllText(Source+model.File));
                    var root=new GameObject(model.Name);var visual=new GameObject("Visual");visual.transform.SetParent(root.transform,false);
                    foreach(var chunk in data.Chunks)
                    {
                        ValidateChunk(chunk);
                        string path=Generated+"Meshes/"+chunk.Name+".asset";
                        var mesh=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                        bool fresh=!mesh;if(fresh)mesh=new Mesh{name=chunk.Name};else mesh.Clear();
                        mesh.indexFormat=chunk.Vertices.Length/3>65535?IndexFormat.UInt32:IndexFormat.UInt16;
                        int count=chunk.Vertices.Length/3;var vertices=new Vector3[count];var normals=new Vector3[count];var colors=new Color[count];var uv=new Vector2[count];
                        for(int i=0;i<count;i++)
                        {
                            vertices[i]=new Vector3(chunk.Vertices[i*3],chunk.Vertices[i*3+1],chunk.Vertices[i*3+2]);
                            normals[i]=new Vector3(chunk.Normals[i*3],chunk.Normals[i*3+1],chunk.Normals[i*3+2]);
                            colors[i]=new Color(chunk.Colors[i*4],chunk.Colors[i*4+1],chunk.Colors[i*4+2],chunk.Colors[i*4+3]);
                            uv[i]=new Vector2(chunk.UV[i*2],chunk.UV[i*2+1]);
                        }
                        mesh.vertices=vertices;mesh.normals=normals;mesh.colors=colors;mesh.uv=uv;mesh.subMeshCount=chunk.Submeshes.Length;
                        var materials=new Material[chunk.Submeshes.Length];
                        for(int i=0;i<chunk.Submeshes.Length;i++){mesh.SetTriangles(chunk.Submeshes[i].Triangles,i,false);materials[i]=palette[chunk.Submeshes[i].Material];}
                        mesh.RecalculateBounds();
                        if(fresh)AssetDatabase.CreateAsset(mesh,path);else EditorUtility.SetDirty(mesh);
                        var part=new GameObject(chunk.Name);part.transform.SetParent(visual.transform,false);
                        if(chunk.Position!=null&&chunk.Position.Length==3)part.transform.localPosition=new Vector3(chunk.Position[0],chunk.Position[1],chunk.Position[2]);
                        part.AddComponent<MeshFilter>().sharedMesh=mesh;
                        var renderer=part.AddComponent<MeshRenderer>();renderer.sharedMaterials=materials;renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
                        if(model.Name=="Environment"||model.Name=="Backdrop")GameObjectUtility.SetStaticEditorFlags(part,StaticEditorFlags.BatchingStatic|StaticEditorFlags.OccluderStatic);
                    }
                    if(data.Clips!=null&&data.Clips.Length>0)
                    {
                        var animation=root.AddComponent<Animation>();animation.playAutomatically=false;
                        foreach(var clip in data.Clips)
                        {
                            string clipPath=Generated+"Animations/"+model.Name+"_"+clip.Name+".anim";
                            var imported=BuildAnimation(clip);var asset=AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);
                            if(asset){EditorUtility.CopySerialized(imported,asset);UnityEngine.Object.DestroyImmediate(imported);}else{asset=imported;AssetDatabase.CreateAsset(asset,clipPath);}
                            animation.AddClip(asset,clip.Name);if(clip.Name=="Idle")animation.clip=asset;
                        }
                        root.AddComponent<MinionAnimationPlayer>().Animation=animation;
                    }
                    bool living=model.Name=="MagmaGuardian"||model.Name=="AzureGolem"||model.Name=="MoonWolf"||model.Name=="StoneCentipede"||model.Name=="RiftGhost"||model.Name=="CrystalCrab"||model.Name=="ObserverFirefly"||model.Name=="RiftRay"||model.Name=="SolarColossus"||model.Name=="NightLeviathan"||model.Name.StartsWith("Warrior")||model.Name.StartsWith("Mage")||model.Name.StartsWith("Guard")||model.Name.StartsWith("Caster");
                    if(living&&(data.Clips==null||data.Clips.Length==0)){var idle=root.AddComponent<StylizedIdleMotion>();idle.Visual=visual.transform;idle.Floating=model.Name=="RiftGhost"||model.Name=="ObserverFirefly"||model.Name=="RiftRay"||model.Name=="NightLeviathan";}
                    var prefab=PrefabUtility.SaveAsPrefabAsset(root,Generated+"Prefabs/"+model.Name+".prefab");
                    UnityEngine.Object.DestroyImmediate(root);entries.Add(new ArtModelReference{Name=model.Name,Prefab=prefab,Triangles=model.Triangles});
                }
            }
            finally{EditorUtility.ClearProgressBar();}
            var catalog=existing?existing:ScriptableObject.CreateInstance<ValleyArtCatalog>();catalog.Version=manifest.Version;catalog.Models=entries.ToArray();catalog.InvalidateCache();
            foreach(var entry in entries)if(entry.Name=="Environment")catalog.Environment=entry.Prefab;
            if(!string.IsNullOrEmpty(manifest.AmbientFile)){var ambient=JsonUtility.FromJson<ArtAmbientData>(File.ReadAllText(Source+manifest.AmbientFile));catalog.AmbientFlows=ambient.Flows;catalog.AmbientSplashes=ambient.Splashes??Array.Empty<ArtPoint>();}
            if(!existing)AssetDatabase.CreateAsset(catalog,CatalogPath);else EditorUtility.SetDirty(catalog);
            AssetDatabase.SaveAssets();Debug.Log("Valley art: imported "+entries.Count+" native mesh prefabs. Blender is not needed to open this Unity project.");return catalog;
        }

        static AnimationClip BuildAnimation(ArtAnimationClip definition)
        {
            var clip=new AnimationClip{name=definition.Name,legacy=true,frameRate=24,wrapMode=definition.Loop?WrapMode.Loop:WrapMode.ClampForever};
            foreach(var track in definition.Tracks)
            {
                string[] properties={"m_LocalPosition.x","m_LocalPosition.y","m_LocalPosition.z","m_LocalRotation.x","m_LocalRotation.y","m_LocalRotation.z","m_LocalRotation.w","m_LocalScale.x","m_LocalScale.y","m_LocalScale.z"};
                for(int component=0;component<properties.Length;component++)
                {
                    var keys=new Keyframe[track.Keys.Length];
                    for(int i=0;i<keys.Length;i++){var key=track.Keys[i];float value=component<3?key.Position[component]:component<7?key.Rotation[component-3]:key.Scale[component-7];keys[i]=new Keyframe(key.Time,value);}
                    var curve=new AnimationCurve(keys);
                    for(int i=0;i<keys.Length;i++){AnimationUtility.SetKeyLeftTangentMode(curve,i,AnimationUtility.TangentMode.Linear);AnimationUtility.SetKeyRightTangentMode(curve,i,AnimationUtility.TangentMode.Linear);}
                    clip.SetCurve(track.Path,typeof(Transform),properties[component],curve);
                }
            }
            clip.EnsureQuaternionContinuity();return clip;
        }

        public static void ValidateChunk(ArtChunkData chunk)
        {
            int count=chunk.Vertices.Length/3;
            if(chunk.Vertices.Length%3!=0||chunk.Normals.Length!=count*3||chunk.Colors.Length!=count*4||chunk.UV.Length!=count*2)throw new InvalidDataException("Invalid vertex stream: "+chunk.Name);
            foreach(var sub in chunk.Submeshes)
            {
                if(sub.Triangles.Length%3!=0)throw new InvalidDataException("Invalid triangle stream: "+chunk.Name);
                foreach(int index in sub.Triangles)if(index<0||index>=count)throw new InvalidDataException("Invalid mesh index: "+chunk.Name);
            }
        }

        public static void ApplyDetailedLayout(MatchConfig configuration)
        {
            string path=Source+"ValleyLayout.json";
            if(File.Exists(path)){configuration.Layout=JsonUtility.FromJson<MapLayout>(File.ReadAllText(path));EditorUtility.SetDirty(configuration);}
        }

        static GameObject Place(ValleyArtCatalog catalog,string name,Transform parent,V2 position,float height=0)
        {
            var prefab=catalog.Find(name);if(!prefab)return null;
            var go=(GameObject)PrefabUtility.InstantiatePrefab(prefab);go.transform.SetParent(parent,false);go.transform.localPosition=WorldRenderer.P(position,height);return go;
        }
        static void Identify(GameObject go,ArtObjectKind kind,int index,string name,Team team=Team.Neutral)
        {
            if(!go)return;var id=go.AddComponent<WorldArtIdentity>();id.Kind=kind;id.Index=index;id.DisplayName=name;id.Team=team;
        }

        public static void CreateShowcase(MatchConfig configuration,ValleyArtCatalog catalog,bool rebuild=false)
        {
            if(!catalog)return;
            if(File.Exists(ShowcasePath)&&!rebuild&&File.Exists(SceneVersionPath)&&File.ReadAllText(SceneVersionPath)==catalog.Version)return;
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var preview=new GameObject("Valley · complete edit-time art preview");
            var environment=(GameObject)PrefabUtility.InstantiatePrefab(catalog.Environment);environment.transform.SetParent(preview.transform,false);
            var flow=environment.AddComponent<RiverFlowAnimator>();flow.FoamPrefab=catalog.Find("FoamStreak");flow.Points=configuration.Layout.River.Points;
            Place(catalog,"Backdrop",preview.transform,new V2());
            for(int team=0;team<2;team++)Identify(Place(catalog,team==0?"FountainBlue":"FountainRed",preview.transform,configuration.Layout.Fountains[team]),ArtObjectKind.Fountain,team,"Фонтан возрождения",(Team)team);
            var world=new MatchWorld(configuration.Rules,configuration.Layout);
            while(world.Clock.Time<420)world.Clock.Advance();world.Objectives.Update();
            foreach(var unit in world.Units)
            {
                var go=Place(catalog,catalog.ModelFor(unit),preview.transform,unit.Position,.22f);if(!go)continue;
                var kind=unit.IsHero?ArtObjectKind.Hero:unit.Kind==Kind.Core?ArtObjectKind.Core:unit.Kind==Kind.Tower?ArtObjectKind.Tower:unit.Camp>=14?ArtObjectKind.Boss:unit.Camp>=12?ArtObjectKind.RiftCreature:ArtObjectKind.Camp;
                Identify(go,kind,unit.Camp>=0?unit.Camp:unit.Id,catalog.ModelFor(unit),unit.Team);
            }
            for(int i=0;i<8;i++)Identify(Place(catalog,"CrystalGate",preview.transform,configuration.Layout.Crystals[i]),ArtObjectKind.Crystal,i,"Кристальный проход "+(i+1));
            for(int i=0;i<2;i++)
            {
                var bridge=Place(catalog,"Bridge",preview.transform,configuration.Layout.Bridges[i],-.12f);
                var direction=configuration.Layout.BridgeDirections[i];bridge.transform.localRotation=Quaternion.Euler(0,Mathf.Atan2(direction.X,direction.Y)*Mathf.Rad2Deg,0);bridge.SetActive(i==0);Identify(bridge,ArtObjectKind.Bridge,i,i==0?"Мост Рассвета":"Мост Сумерек");
            }
            var controller=new GameObject("Valley art inspection").AddComponent<ValleyShowcaseController>();controller.Configuration=configuration;controller.EditTimePreview=preview;
            var camera=new GameObject("Main Camera").AddComponent<Camera>();camera.tag="MainCamera";camera.gameObject.AddComponent<AudioListener>();camera.orthographic=true;camera.orthographicSize=77;camera.farClipPlane=400;camera.nearClipPlane=.1f;camera.backgroundColor=new Color(.035f,.09f,.12f);camera.transform.position=new Vector3(0,140,-98);camera.transform.LookAt(new Vector3(0,-.5f,0));camera.gameObject.AddComponent<UniversalAdditionalCameraData>().renderPostProcessing=true;
            SetupLighting();
            EditorSceneManager.SaveScene(scene,ShowcasePath);
            File.WriteAllText(SceneVersionPath,catalog.Version);
            var view=SceneView.lastActiveSceneView;if(view)view.LookAt(new Vector3(0,0,0),Quaternion.Euler(55,0,0),90);
        }

        public static void SetupLighting()
        {
            Directory.CreateDirectory(Generated);AssetDatabase.Refresh();
            new GameObject("Valley graphics quality").AddComponent<ValleyGraphicsSettings>();
            var sun=new GameObject("Warm morning key light").AddComponent<Light>();sun.type=LightType.Directional;sun.color=new Color(1,.91f,.77f);sun.intensity=1.6f;sun.shadows=LightShadows.Soft;sun.shadowStrength=.75f;sun.transform.rotation=Quaternion.Euler(48,-35,0);
            RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=new Color(.42f,.54f,.6f);RenderSettings.ambientEquatorColor=new Color(.31f,.4f,.34f);RenderSettings.ambientGroundColor=new Color(.2f,.24f,.22f);
            RenderSettings.fog=true;RenderSettings.fogMode=FogMode.Linear;RenderSettings.fogColor=new Color(.045f,.13f,.17f);RenderSettings.fogStartDistance=180;RenderSettings.fogEndDistance=420;QualitySettings.shadowDistance=190;
            var volume=new GameObject("Subtle crystal bloom").AddComponent<Volume>();volume.isGlobal=true;
            var profile=ScriptableObject.CreateInstance<VolumeProfile>();var bloom=profile.Add<Bloom>();bloom.intensity.Override(.26f);bloom.threshold.Override(1.2f);
            volume.sharedProfile=profile;
            string path=Generated+"ValleyVolume.asset";
            var existing=AssetDatabase.LoadAssetAtPath<VolumeProfile>(path);
            if(!existing)
            {
                AssetDatabase.CreateAsset(profile,path);
                foreach(var component in profile.components)AssetDatabase.AddObjectToAsset(component,profile);
            }
            else{volume.sharedProfile=existing;UnityEngine.Object.DestroyImmediate(profile);}
            if(!volume.sharedProfile.TryGet<Bloom>(out var currentBloom)){currentBloom=volume.sharedProfile.Add<Bloom>();AssetDatabase.AddObjectToAsset(currentBloom,volume.sharedProfile);}currentBloom.intensity.Override(.38f);currentBloom.threshold.Override(1.1f);
            if(!volume.sharedProfile.TryGet<ColorAdjustments>(out var grading)){grading=volume.sharedProfile.Add<ColorAdjustments>();AssetDatabase.AddObjectToAsset(grading,volume.sharedProfile);}grading.contrast.Override(8);grading.saturation.Override(8);
            if(!volume.sharedProfile.TryGet<Tonemapping>(out var tonemapping)){tonemapping=volume.sharedProfile.Add<Tonemapping>();AssetDatabase.AddObjectToAsset(tonemapping,volume.sharedProfile);}tonemapping.mode.Override(TonemappingMode.ACES);
            EditorUtility.SetDirty(volume.sharedProfile);
        }
    }
}
