using System;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Tests
{
    public static partial class ScenarioSuite
    {
        static MatchWorld EmptyLane(out Unit minion)
        {
            var w=new MatchWorld();foreach(var unit in w.Units)unit.Health=0;
            minion=w.Spawn(Kind.Guard,Team.Blue,w.Layout.LanePoint(1,45));minion.Lane=1;minion.LaneDistance=45;return w;
        }
        static Unit LaneEnemy(MatchWorld world,Kind kind,float distance)
        {var enemy=world.Spawn(kind,Team.Red,world.Layout.LanePoint(1,distance));enemy.Lane=1;enemy.LaneDistance=distance;enemy.Tier=0;return enemy;}
        static void MinionPriorityAndNeutralImmunity()
        {
            Unit minion;var w=EmptyLane(out minion);var hero=LaneEnemy(w,Kind.Warrior,46);var tower=LaneEnemy(w,Kind.Tower,47);var enemy=LaneEnemy(w,Kind.Guard,50);
            var neutral=w.Spawn(Kind.Monster,Team.Neutral,minion.Position);neutral.Camp=14;
            w.Bots.Update(minion);Check(minion.Target==enemy.Id,"hero, tower or boss outranks minion");
            enemy.Health=0;w.Bots.Update(minion);Check(minion.Target==tower.Id,"hero outranks tower");
            tower.Health=0;w.Bots.Update(minion);Check(minion.Target==hero.Id,"hero inside range wasn't acquired");
            hero.Health=0;w.Bots.Update(minion);Check(minion.Target==0,"neutral monster acquired");
        }
        static void MinionCommitment()
        {
            Unit minion;var w=EmptyLane(out minion);var original=LaneEnemy(w,Kind.Guard,50);w.Bots.Update(minion);
            var closer=LaneEnemy(w,Kind.Guard,46);w.Clock.Advance();w.Bots.Update(minion);Check(minion.Target==original.Id,"closer minion stole committed target");
            original.Health=0;closer.Health=0;var tower=LaneEnemy(w,Kind.Tower,47);w.Bots.Update(minion);Check(minion.Target==tower.Id,"tower not acquired");
            var reinforcement=LaneEnemy(w,Kind.Guard,46);w.Bots.Update(minion);Check(minion.Target==tower.Id,"reinforcement stole committed tower target");
            var allied=w.Spawn(Kind.Warrior,Team.Blue,minion.Position);var red=w.Spawn(Kind.Warrior,Team.Red,minion.Position);w.Combat.Hit(red,allied,1,DamageType.True);Check(minion.Target==tower.Id,"hero combat broke minion target lock");
            tower.Health=0;w.Bots.Update(minion);Check(minion.Target==reinforcement.Id,"dead target lock never released");
        }
        static void MinionHeroRangeRelease()
        {
            Unit minion;var w=EmptyLane(out minion);var hero=LaneEnemy(w,Kind.Warrior,46);w.Bots.Update(minion);Check(minion.Target==hero.Id,"hero not acquired");
            hero.Position=w.Layout.LanePoint(1,51);w.Bots.Update(minion);Check(minion.Target==0,"minion chases hero beyond attack range");
        }
        static void StrictLaneCenters()
        {
            for(int lane=0;lane<3;lane++)for(int team=0;team<2;team++)
            {
                var w=new MatchWorld();foreach(var unit in w.Units)unit.Health=0;
                float distance=team==0?20:w.Layout.LaneLength(lane)-20;var minion=w.Spawn(Kind.Guard,(Team)team,w.Layout.LanePoint(lane,distance));minion.Lane=lane;minion.LaneDistance=distance;
                var along=w.Layout.LanePoint(lane,distance+(team==0?5:-5));var before=w.Layout.LanePoint(lane,distance+(team==0?4:-4));var axis=(along-before).Normalized;
                var tower=w.Spawn(Kind.Tower,(Team)(1-team),along+new V2(-axis.Y,axis.X)*2.8f);tower.Lane=lane;tower.Tier=0;float hp=tower.Health;
                for(int step=0;step<100;step++){w.Clock.Advance();w.Bots.Update(minion);w.Projectiles.Update();Check(MapLayout.NearRoute(minion.Position,w.Layout.Lanes[lane],.001f),"combat moved minion off route center");}
                Check(tower.Health<hp,"strict route prevents attacking a tower footprint");
            }
        }
        static void StructureProjectiles()
        {
            foreach(var kind in new[]{Kind.Tower,Kind.Core})
            {
                var w=new MatchWorld();foreach(var u in w.Units)u.Health=0;
                var building=w.Spawn(kind,Team.Blue,new V2(0,0));var target=w.Spawn(Kind.Guard,Team.Red,new V2(7,0));target.Armor=0;float hp=target.Health;
                Check(w.Combat.Attack(building,target),"structure cannot attack minion");Near(target.Health,hp);
                Clock(w,.35);w.Projectiles.Update();Check(w.Projectiles.Active.Count==1,"structure has no launched projectile");
                Check(w.Projectiles.Active[0].StartHeight>4,"structure bolt starts at ground");
                for(int i=0;i<20;i++){w.Clock.Advance();w.Projectiles.Update();}Check(target.Health<hp,"structure projectile causes no damage");
                var hero=w.Spawn(Kind.Warrior,Team.Red,new V2(6,0));building.NextAttack=0;Check(w.Combat.Attack(building,hero),"structure cannot attack hero");
            }
        }
        static void CentralNotices()
        {
            var w=new MatchWorld();Clock(w,120);w.Map.Update(w.Clock.Time,w.Units,w.Emit);Check(w.Notices.Count==1&&w.Notices[0].Kind==NoticeKind.Bridge,"missing first bridge announcement");
            w.Map.Update(w.Clock.Time,w.Units,w.Emit);Check(w.Notices.Count==1,"bridge announcement repeats each tick");
            Clock(w,240);w.Map.Update(w.Clock.Time,w.Units,w.Emit);Check(w.Notices.Count==2,"bridge swap emitted more than one announcement");
            var killer=w.Player;var tower=LaneEnemy(w,Kind.Tower,45);foreach(var unit in w.Units)if(unit.IsStructure&&unit.Id!=tower.Id)unit.Health=0;killer.Position=tower.Position;
            w.Combat.Hit(killer,tower,100000,DamageType.True);Check(w.Notices[w.Notices.Count-1].Kind==NoticeKind.Tower,"tower death notice missing");int count=w.Notices.Count;w.Combat.Hit(killer,tower,100000,DamageType.True);Check(w.Notices.Count==count,"tower death notice repeats");
            w.Objectives.Camps[14].SpawnAt=0;w.Objectives.Update();Unit boss=null;foreach(var unit in w.Units)if(unit.Alive&&unit.Camp==14)boss=unit;Check(boss!=null,"boss absent");killer.Position=boss.Position;w.Combat.Hit(killer,boss,100000,DamageType.True);Check(w.Notices[w.Notices.Count-1].Kind==NoticeKind.Boss,"boss death notice missing");
        }
        static void ObserverRespectsConcealment()
        {
            Unit hero;var w=VisionWorld(out hero);hero.Position=BrushCenter(w.Layout);w.Objectives.Zones.Add(new ObjectiveZone{Position=hero.Position,Team=Team.Red,Until=50,Vision=true});w.Vision.Update();
            Check(!w.Visible(Team.Red,hero),"observer zone reveals bush concealment");hero.Position+=new V2(0,6);Check(w.Visible(Team.Red,hero),"observer doesn't reveal ordinary fog");
        }
        static void StraightInternalRiver()
        {
            var w=new MatchWorld();var river=w.Layout.River;Check(w.Layout.BankWalls.Length==0&&w.Layout.RiverRailings.Length==0,"river walls remain");
            foreach(var p in river.Points){Check(V2.SegmentDistance(p,river[0],river[river.Length-1])<.001f,"river isn't straight");Check(Math.Abs(p.X)<60&&Math.Abs(p.Y)<60,"main river exits map");}
            Check(w.Layout.BossApproaches.Length==4,"four forest approaches missing");int sealedCrossings=0;
            for(int x=-68;x<=68;x++)for(int y=-68;y<=68;y++)
            {var a=new V2(x,y);var b=a+new V2(1,0);if(w.Map.Walkable(a)&&w.Map.Walkable(b)&&!w.Map.CanTraverse(a,b))sealedCrossings++;}
            Check(sealedCrossings>0,"arena sides aren't sealed outside forest gates");
        }
    }
}
