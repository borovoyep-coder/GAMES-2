using System;
using System.Collections.Generic;
using ShatteredWorld.Simulation;

namespace ShatteredWorld.Tests
{
    public static partial class ScenarioSuite
    {
        public static readonly Dictionary<string,Action> Cases=new Dictionary<string,Action>
        {
            {"map counts and explicit photo tower markers",MapCounts},
            {"three permanent lanes and four boss entrances",Connectivity},
            {"bridge boundaries and warning",Bridges},
            {"bridge closes and ejects safely",BridgeSafety},
            {"six melee and eight ranged crystal attacks",CrystalHits},
            {"mixed crystal hits and spell immunity",CrystalMixed},
            {"crystal restoration waits for hero",CrystalSafety},
            {"wave timestamps and siege composition",Waves},
            {"late siege is never duplicated",LateWaves},
            {"blessing applies to exactly two future waves per lane",Blessing},
            {"neutral spawn schedule and population",NeutralSchedule},
            {"neutral respawn starts at final death and rewards once",NeutralDeath},
            {"portal ownership channel cancellation cooldown expiry",Portal},
            {"modifier refresh expiry and out of combat",Modifiers},
            {"commands validate mana range cooldown and shop",Commands},
            {"damage respects structure progression",Progression},
            {"fog snapshots hide enemy heroes",Fog},
            {"hero death respawn and rewards once",HeroDeath},
            {"finish freezes simulation and new match resets",Restart},
            {"navigation routes obey blocked geometry",Navigation},
            {"all 256 crystal combinations preserve lanes and arenas",AllMapStates},
            {"minions complete all three routes in both directions",MinionRoutes},
            {"destroying an exposed core finishes match",CoreVictory},
            {"portal is cancelled by enemy hero damage",PortalDamage},
            {"detailed forest trunks block movement",ForestTrunks},
            {"rotated masonry follows its actual rectangle",RotatedWall},
            {"all jungle camps remain reachable in detailed forest",JungleConnectivity},
            {"both boss reward portal endpoints are walkable",RewardPortalSafety},
            {"all four bridge shore exits remain safe in dense forest",AllBridgeExits},
            {"eighteen tower side passages respect crystal gates",TowerPassages},
            {"outer bypass remains continuous in all bridge phases",OuterBypass},
            {"concealment follows traced brush polygons",BrushPolygons},
            {"fountains behind both cores spawn heal and recall heroes",Fountains},
            {"bush entry remembers five seconds of hero minion and tower vision",BushHistory},
            {"unseen bush entry hides immediately and close detection reveals",BushUnseen},
            {"river is forbidden outside roads and open bridge decks",RiverBoundaries},
            {"eight crystals block direct shortcuts and breaking saves distance",CrystalShortcuts},
            {"minion attacks use windup projectiles and siege damage",MinionAttacks},
            {"melee minions engage offset towers while remaining on their road",MinionTowerApproach},
            {"minions prioritize minion then structure then hero and ignore neutrals",MinionPriorityAndNeutralImmunity},
            {"minions keep committed targets despite closer enemies and hero combat",MinionCommitment},
            {"minions release heroes outside attack range",MinionHeroRangeRelease},
            {"all six minion routes stay exactly on center during tower combat",StrictLaneCenters},
            {"towers and nexus launch damaging animated projectiles",StructureProjectiles},
            {"central bridge tower and boss notices occur once",CentralNotices},
            {"observer vision does not reveal invisible bush heroes",ObserverRespectsConcealment},
            {"straight internal river has no walls and four forest arena gates",StraightInternalRiver}
        };
        static void Check(bool condition,string detail){if(!condition)throw new Exception(detail);}
        static void Near(double a,double b){Check(Math.Abs(a-b)<.01,$"{a} != {b}");}
        static int Count(MatchWorld w,Func<Unit,bool> match){int n=0;foreach(var u in w.Units)if(match(u))n++;return n;}
        static void Clock(MatchWorld w,double time){while(w.Clock.Time+1e-5<time)w.Clock.Advance();}
        static void MapCounts()
        {
            var w=new MatchWorld();Check(Count(w,u=>u.Kind==Kind.Core)==2,"cores");Check(Count(w,u=>u.Kind==Kind.Tower)==18,"towers");
            Check(Count(w,u=>u.IsHero)==10&&Count(w,u=>u.IsPlayer)==1,"heroes");
            Check(w.Layout.Camps.Length==12&&w.Map.Crystals.Length==8&&w.Map.Bridges.Length==2,"world counts");
            Check(w.Layout.TowerSlots.Length==18,"missing individually traced tower foundations");
            foreach(var slot in w.Layout.TowerSlots)
            {
                Unit actual=null;foreach(var u in w.Units)if(u.Kind==Kind.Tower&&(int)u.Team==slot.Team&&u.Lane==slot.Lane&&u.Tier==slot.Tier)actual=u;
                Check(actual!=null&&V2.Distance(actual.Position,slot.Position)<.01f,"tower placed by a generic spacing formula");
            }
            Check(w.Layout.TowerPosition(0,0,0).Y>20&&w.Layout.TowerPosition(1,0,0).X<-20,"upper outer towers do not guard reference arena approaches");
            Check(w.Layout.TowerPosition(0,2,0).X>20&&w.Layout.TowerPosition(1,2,0).Y<-20,"lower outer towers do not guard reference arena approaches");
        }
        static void Connectivity()
        {
            var w=new MatchWorld();var path=new List<V2>();
            for(int phase=0;phase<3;phase++)
            {
                w.Map.Update(phase*120,w.Units,_=>{});
                for(int lane=0;lane<3;lane++)for(float d=0;d<w.Layout.LaneLength(lane);d+=.5f)Check(w.Map.Walkable(w.Layout.LanePoint(lane,d)),"blocked lane");
                for(int b=0;b<2;b++)foreach(var entrance in w.Layout.BossEntrances[b].Points)Check(w.Navigation.Find(entrance,w.Layout.Bosses[b],path),"boss inaccessible");
            }
        }
        static void Bridges()
        {
            var w=new MatchWorld();var m=w.Map;
            m.Update(119.99,w.Units,_=>{});Check(!m.Bridges[0].Open&&!m.Bridges[1].Open,"early opening");
            m.Update(120,w.Units,_=>{});Check(m.Bridges[0].Open&&!m.Bridges[1].Open,"dawn");
            m.Update(225,w.Units,_=>{});Check(m.Bridges[0].Warning,"warning");
            m.Update(240,w.Units,_=>{});Check(!m.Bridges[0].Open&&m.Bridges[1].Open,"dusk");
            m.Update(600,w.Units,_=>{});Check(m.Bridges[0].Open&&!m.Bridges[1].Open,"late alternation");
        }
        static void BridgeSafety(){var w=new MatchWorld();w.Map.Update(120,w.Units,_=>{});w.Player.Position=w.Layout.Bridges[0];w.Map.Update(240,w.Units,_=>{});Check(w.Map.Walkable(w.Player.Position),"unsafe ejection");}
        static void CrystalHits()
        {
            var w=new MatchWorld();for(int i=0;i<5;i++)w.Map.HitCrystal(0,true,true,0);Check(!w.Map.Crystals[0].Broken,"too early");w.Map.HitCrystal(0,true,true,0);Check(w.Map.Crystals[0].Broken,"melee");
            for(int i=0;i<7;i++)w.Map.HitCrystal(1,false,true,0);Check(!w.Map.Crystals[1].Broken,"too early ranged");w.Map.HitCrystal(1,false,true,0);Check(w.Map.Crystals[1].Broken,"ranged");
        }
        static void CrystalMixed(){var w=new MatchWorld();w.Map.HitCrystal(0,true,false,0);Near(w.Map.Crystals[0].Durability,24);for(int i=0;i<3;i++)w.Map.HitCrystal(0,true,true,0);for(int i=0;i<4;i++)w.Map.HitCrystal(0,false,true,0);Check(w.Map.Crystals[0].Broken,"mixed");}
        static void CrystalSafety()
        {
            var w=new MatchWorld();for(int i=0;i<6;i++)w.Map.HitCrystal(0,true,true,0);w.Player.Position=w.Layout.Crystals[0];w.Map.Update(60,w.Units,_=>{});Check(w.Map.Crystals[0].Broken,"occupied restore");w.Player.Position=w.Layout.Bases[0];w.Map.Update(61,w.Units,_=>{});Check(!w.Map.Crystals[0].Broken,"didn't restore");
        }
        static void Waves()
        {
            var w=new MatchWorld();Clock(w,9.95);w.Waves.Update();Check(w.Waves.WaveNumber==0,"early wave");Clock(w,10);w.Waves.Update();Check(Count(w,u=>u.IsMinion)==18,"first wave");Clock(w,35);w.Waves.Update();Check(Count(w,u=>u.IsMinion)==36,"second wave");Clock(w,60);w.Waves.Update();Check(Count(w,u=>u.Kind==Kind.Destroyer)==6,"third siege");
        }
        static void LateWaves(){var w=new MatchWorld();for(int i=0;i<30;i++){Clock(w,w.Waves.NextWave);int before=Count(w,u=>u.Kind==Kind.Destroyer);double t=w.Clock.Time;w.Waves.Update();if(t>=600)Check(Count(w,u=>u.Kind==Kind.Destroyer)-before==6,"duplicate siege");}}
        static void Blessing()
        {
            var w=new MatchWorld();Clock(w,10);w.Waves.Update();w.Waves.Bless(Team.Blue);w.Waves.Bless(Team.Blue);
            for(int i=0;i<3;i++){Clock(w,w.Waves.NextWave);w.Waves.Update();}
            Check(Count(w,u=>u.Team==Team.Blue&&u.IsMinion&&u.SiegeBlessing)==21,"exact two future waves");for(int lane=0;lane<3;lane++)Check(w.Waves.BlessedWaves[0,lane]==0,"wave counters");
        }
        static void NeutralSchedule()
        {
            var w=new MatchWorld();Clock(w,20);w.Objectives.Update();Check(Count(w,u=>u.Kind==Kind.Monster)==22,"22 forest creatures");
            foreach(var u in w.Units)if(u.Kind==Kind.Monster)Check(w.Map.Walkable(u.Position),"monster camp "+u.Camp+" spawned inside obstacle at "+u.Position.X+","+u.Position.Y);
            Clock(w,60);w.Objectives.Update();Check(Count(w,u=>u.Kind==Kind.Monster)==24,"rift pair");Clock(w,180);w.Objectives.Update();Check(w.Objectives.Camps[14].Active&&!w.Objectives.Camps[15].Active,"colossus");Clock(w,420);w.Objectives.Update();Check(w.Objectives.Camps[14].Active&&w.Objectives.Camps[15].Active,"independent bosses");
        }
        static void NeutralDeath()
        {
            var w=new MatchWorld();Clock(w,30);w.Objectives.Update();var hero=w.Player;hero.Position=w.Layout.Camps[1];float gold=hero.Gold;Unit last=null;
            foreach(var u in w.Units)if(u.Camp==1){last=u;w.Combat.Hit(hero,u,10000,DamageType.True);}
            Near(hero.Gold-gold,65);Near(w.Objectives.Camps[1].SpawnAt,95);w.Objectives.OnDeath(hero,last);Near(hero.Gold-gold,65);
            Clock(w,94);w.Objectives.Update();Check(!w.Objectives.Camps[1].Active,"early respawn");Clock(w,95);w.Objectives.Update();Check(w.Objectives.Camps[1].Active,"respawn");
        }
        static void Portal()
        {
            var w=new MatchWorld();var u=w.Player;var p=new PortalState{A=u.Position,B=new V2(-20,-10),Team=Team.Blue,Until=90};w.Objectives.Portals.Add(p);
            Check(w.Objectives.UsePortal(u),"channel");w.Objectives.InterruptPortal(u.Id);Clock(w,1);w.Objectives.Update();Near(V2.Distance(u.Position,p.A),0);
            Check(w.Objectives.UsePortal(u),"retry");Clock(w,2);w.Objectives.Update();Near(V2.Distance(u.Position,p.B),0);Check(!w.Objectives.UsePortal(u),"cooldown");
            var enemy=w.ClosestHero(Team.Red,w.Layout.Bases[1],10);enemy.Position=p.A;Check(!w.Objectives.UsePortal(enemy),"enemy portal");Clock(w,90);w.Objectives.Update();Check(w.Objectives.Portals.Count==0,"expiry");
        }
        static void Modifiers()
        {
            var w=new MatchWorld();var u=w.Player;w.Modifiers.Apply(u,Buffs.RiftSpeed,u.Id,0);w.Modifiers.Apply(u,Buffs.RiftSpeed,u.Id,1);Check(u.Modifiers.Count==1,"refresh stacks");Near(u.Stat(Stat.Speed,1),u.Speed*1.2f);u.LastCombat=2;Near(u.Stat(Stat.Speed,3),u.Speed);Clock(w,6);w.Modifiers.Update(w,u);Check(u.Modifiers.Count==0,"expiry");
        }
        static void Commands()
        {
            var w=new MatchWorld();var u=w.Player;
            Check(!w.Execute(new GameCommand{Actor=u.Id,Type=CommandType.Ability,Point=new V2(50,50)}),"range");
            u.Mana=0;Check(!w.Combat.Ability(u,0,u.Position),"mana");u.Mana=250;Check(w.Combat.Ability(u,0,u.Position),"ability");Check(!w.Combat.Ability(u,0,u.Position),"cooldown");
            Check(w.Execute(new GameCommand{Actor=u.Id,Type=CommandType.Buy,Slot=0}),"shop");u.Position=new V2(0,0);Check(!w.Execute(new GameCommand{Actor=u.Id,Type=CommandType.Buy,Slot=1}),"remote shop");
        }
        static void Progression()
        {
            var w=new MatchWorld();Unit outer=null,inner=null,core=null;foreach(var u in w.Units)if(u.Team==Team.Red){if(u.Kind==Kind.Core)core=u;if(u.Kind==Kind.Tower&&u.Lane==1){if(u.Tier==0)outer=u;if(u.Tier==2)inner=u;}}
            w.Player.Position=inner.Position;w.Combat.Hit(w.Player,inner,10000,DamageType.True);Check(inner.Alive,"inner vulnerability");w.Player.Position=outer.Position;w.Combat.Hit(w.Player,outer,10000,DamageType.True);Check(!outer.Alive,"outer invulnerable");w.Player.Position=core.Position;w.Combat.Hit(w.Player,core,10000,DamageType.True);Check(core.Alive,"core shield");
        }
        static void Fog(){var w=new MatchWorld();int enemies=0;foreach(var s in w.Snapshot(Team.Blue).Units)if(s.Team==Team.Red&&(s.Kind==Kind.Warrior||s.Kind==Kind.Mage))enemies++;Check(enemies==0,"hidden heroes leaked");}
        static void HeroDeath()
        {
            var w=new MatchWorld();var enemy=w.ClosestHero(Team.Red,w.Layout.Bases[1],10);w.Player.Position=enemy.Position;w.Combat.Hit(w.Player,enemy,10000,DamageType.True);float gold=w.Player.Gold;w.Combat.Hit(w.Player,enemy,10000,DamageType.True);Near(w.Player.Gold,gold);Clock(w,enemy.RespawnAt);w.Step();Check(enemy.Alive,"respawn");Check(w.Kills[0]==1,"duplicate kill");
        }
        static void Restart(){var w=new MatchWorld();w.Finish(Team.Blue);w.Step();Check(w.Clock.Tick==0,"finished time");var fresh=new MatchWorld();Check(fresh.Phase==MatchPhase.Playing&&fresh.Kills[0]==0&&fresh.Objectives.Portals.Count==0,"restart state");}
        static void Navigation(){var w=new MatchWorld();var path=new List<V2>();Check(w.Navigation.Find(w.Layout.Bases[0],w.Layout.Bases[1],path),"base path");V2 last=w.Layout.Bases[0];foreach(var p in path){Check(w.Navigation.SegmentClear(last,p),"obstacle clipping");last=p;}}
        static void AllMapStates()
        {
            var w=new MatchWorld();var path=new List<V2>();
            for(int mask=0;mask<256;mask++)
            {
                for(int i=0;i<8;i++)w.Map.Crystals[i].Durability=(mask&(1<<i))==0?24:0;
                for(int phase=0;phase<3;phase++)
                {
                    w.Map.Bridges[0].Open=phase==1;w.Map.Bridges[1].Open=phase==2;
                    for(int lane=0;lane<3;lane++)for(float d=0;d<w.Layout.LaneLength(lane);d+=2)Check(w.Map.Walkable(w.Layout.LanePoint(lane,d)),"lane blocked in combination");
                    for(int boss=0;boss<2;boss++)foreach(var entrance in w.Layout.BossEntrances[boss].Points)
                    {Check(w.Navigation.Find(entrance,w.Layout.Bosses[boss],path),"arena blocked");Check(path.Count>0&&V2.Distance(path[path.Count-1],w.Layout.Bosses[boss])<1,"path doesn't reach arena");}
                }
            }
        }
        static void MinionRoutes()
        {
            for(int lane=0;lane<3;lane++)for(int team=0;team<2;team++)
            {
                var w=new MatchWorld();foreach(var old in w.Units)old.Health=0;
                var u=w.Spawn(Kind.Guard,(Team)team,w.Layout.Bases[team]);u.Lane=lane;u.LaneDistance=team==0?0:w.Layout.LaneLength(lane);
                for(int i=0;i<1200;i++){w.Clock.Advance();w.Bots.Update(u);}
                Check(V2.Distance(u.Position,w.Layout.Bases[1-team])<1,"minion stuck on route");
            }
        }
        static void CoreVictory()
        {
            var w=new MatchWorld();Unit core=null;foreach(var u in w.Units){if(u.Kind==Kind.Tower&&u.Team==Team.Red&&u.Lane==0)u.Health=0;if(u.Kind==Kind.Core&&u.Team==Team.Red)core=u;}
            w.Player.Position=core.Position;w.Combat.Hit(w.Player,core,10000,DamageType.True);
            Check(w.Phase==MatchPhase.Finished&&w.Winner==Team.Blue,"core destruction didn't finish match");
        }
        static void PortalDamage()
        {
            var w=new MatchWorld();var p=w.Player;var portal=new PortalState{Team=Team.Blue,A=p.Position,B=new V2(-20,-10),Until=90};w.Objectives.Portals.Add(portal);
            Check(w.Objectives.UsePortal(p),"channel failed");var enemy=w.ClosestHero(Team.Red,w.Layout.Bases[1],10);enemy.Position=p.Position;
            w.Combat.Hit(enemy,p,1,DamageType.True);Clock(w,1);w.Objectives.Update();Near(V2.Distance(p.Position,portal.A),0);
        }
        static void ForestTrunks()
        {
            var w=new MatchWorld();Check(w.Layout.TreeObstacles.Length>100,"forest art has no navigation data");
            foreach(var trunk in w.Layout.TreeObstacles)if(!w.Layout.OnLane(trunk))Check(!w.Map.Walkable(trunk),"tree is visually solid but walkable");
        }
        static void RotatedWall()
        {
            var wall=new MapBlock(new V2(0,0),new V2(10,1),45);
            Check(wall.Contains(new V2(3,3)),"rotated wall missing diagonal");Check(!wall.Contains(new V2(3,0)),"rotated wall retains wrong axis aligned blocker");
        }
        static void JungleConnectivity()
        {
            var w=new MatchWorld();var path=new List<V2>();
            for(int i=0;i<w.Layout.Camps.Length;i++)
            {
                var start=w.Layout.Bases[i<6?0:1];var end=w.Layout.Camps[i];
                Check(w.Navigation.Find(start,end,path),"jungle camp is sealed");
                Check(path.Count>0&&V2.Distance(path[path.Count-1],end)<1,"jungle camp route ends outside clearing");
            }
        }
        static void RewardPortalSafety()
        {
            for(int team=0;team<2;team++)
            {
                var w=new MatchWorld();Clock(w,420);w.Objectives.Update();Unit hero=null,boss=null;
                foreach(var u in w.Units){if(u.IsHero&&u.Team==(Team)team)hero=u;if(u.Camp==15)boss=u;}
                hero.Position=boss.Position;w.Combat.Hit(hero,boss,100000,DamageType.True);
                Check(w.Objectives.Portals.Count==1,"boss did not award portal");var portal=w.Objectives.Portals[0];
                Check(w.Map.Walkable(portal.A)&&w.Map.Walkable(portal.B),"boss portal exits inside new scenery");
            }
        }
        static void AllBridgeExits()
        {
            for(int bridge=0;bridge<2;bridge++)foreach(int side in new[]{-1,1})
            {
                var w=new MatchWorld();w.Map.Update(bridge==0?120:240,w.Units,_=>{});
                w.Player.Position=w.Layout.Bridges[bridge]+new V2(.1f*side,.1f*side);
                w.Map.Update(bridge==0?240:360,w.Units,_=>{});
                Check(w.Map.Walkable(w.Player.Position),"bridge ejects into a tree or wall");
            }
        }
        static void TowerPassages()
        {
            var w=new MatchWorld();Check(w.Layout.TowerPassages.Length==18,"missing tower side routes");
            for(int state=0;state<2;state++)
            {
                if(state==1)foreach(var crystal in w.Map.Crystals)crystal.Durability=0;
                for(int i=0;i<w.Layout.TowerPassages.Length;i++)
                {var route=w.Layout.TowerPassages[i];
                    for(float d=0;d<MapLayout.RouteLength(route);d+=.25f)
                    {
                        var p=MapLayout.RoutePoint(route,d);bool gated=false;
                        // Permanent minion lanes retain priority at the edge of a gate's radius.
                        if(state==0&&!w.Layout.OnLane(p)&&!w.Layout.OnBypass(p))foreach(var crystal in w.Layout.Crystals)if(V2.Distance(p,crystal)<2.4f)gated=true;
                        Check(w.Map.Walkable(p)==!gated,"tower side passage "+i+" has an unrelated obstacle at "+p.X+","+p.Y);
                    }
                }
            }
        }
        static void OuterBypass()
        {
            var w=new MatchWorld();Check(w.Layout.BypassRoutes.Length>0,"missing outer path");
            for(int phase=0;phase<3;phase++)
            {
                w.Map.Update(phase*120,w.Units,_=>{});
                foreach(var route in w.Layout.BypassRoutes)
                    for(float d=0;d<MapLayout.RouteLength(route);d+=.25f)
                        Check(w.Map.Walkable(MapLayout.RoutePoint(route,d)),"outer bypass is blocked");
            }
        }
        static void BrushPolygons()
        {
            var layout=new MapLayout();Check(layout.BushZones.Length==30,"missing traced brush areas");
            foreach(var zone in layout.BushZones)
            {
                V2 center=new V2(0,0);foreach(var point in zone.Points)center+=point;center*=1f/zone.Points.Length;
                Check(layout.IsInBush(center),"brush center doesn't conceal");
            }
            Check(!layout.IsInBush(layout.Bases[0])&&!layout.IsInBush(layout.Bases[1]),"base concealed by old circular brush volumes");
        }
    }
}
