using System;
using System.Collections.Generic;
namespace ShatteredWorld.Simulation
{
    public sealed class CampState
    {
        public int Id,Count,Gold,Xp;public float Respawn;public V2 Position;public double SpawnAt;public bool Active;
    }
    public sealed class ObjectiveZone {public V2 Position;public Team Team;public double Until;public bool Vision;}
    public sealed class PortalState {public Team Team;public V2 A,B;public double Until;}
    public sealed class PortalChannel {public int Actor;public V2 Origin,Destination;public double Finish,Expires;}
    public sealed class ObjectiveSystem
    {
        readonly MatchWorld w;
        public readonly CampState[] Camps=new CampState[16];
        public readonly List<ObjectiveZone> Zones=new List<ObjectiveZone>();
        public readonly List<PortalState> Portals=new List<PortalState>();
        readonly List<PortalChannel> channels=new List<PortalChannel>();
        public ObjectiveSystem(MatchWorld world)
        {
            w=world;int[] count={1,3,3,1,2,1},gold={100,65,70,100,85,95},xp={150,95,100,150,115,65};float[] respawn={100,65,65,100,75,75};
            for(int i=0;i<16;i++)
            {
                int type=i%6;
                Camps[i]=new CampState{Id=i,Count=i<12?count[type]:1,Gold=i<12?gold[type]:40,Xp=i<12?xp[type]:40,
                    Respawn=i<12?respawn[type]:i<14?90:i==14?180:240,Position=i<12?w.Layout.Camps[i]:i<14?w.Layout.RiftCreatures[i-12]:w.Layout.Bosses[i-14],SpawnAt=i<12?20:i<14?60:i==14?180:420};
            }
        }
        public void Update()
        {
            double now=w.Clock.Time;
            foreach(var c in Camps)if(!c.Active&&now+1e-5>=c.SpawnAt)
            {
                c.Active=true;
                for(int i=0;i<c.Count;i++)
                {
                    float side=c.Id<6?1:-1;
                    var offset=c.Id<12&&c.Id%6==2?new V2(0,-i*1.4f*side):new V2(i*1.4f*side,0);
                    var u=w.Spawn(Kind.Monster,Team.Neutral,c.Position+offset);u.Camp=c.Id;u.Spawn=u.Position;
                    u.BaseHealth=c.Id>=14?c.Id==14?6500:9000:c.Id<12?c.Count==1?1000:430:420;
                    u.Health=u.BaseHealth;u.Damage=c.Id>=14?110:c.Id<12?45:12;u.Range=c.Id>=14?5:2.8f;u.Speed=4;
                }
                if(c.Id>=14)w.Emit(c.Id==14?"Появился Солнечный колосс":"Появился Ночной левиафан");
            }
            for(int i=Zones.Count-1;i>=0;i--)
            {
                var z=Zones[i];if(z.Until<=now){Zones.RemoveAt(i);continue;}
                if(!z.Vision)foreach(var u in w.Units)if(u.Alive&&u.IsHero&&u.Team==z.Team&&V2.Distance(u.Position,z.Position)<7)w.Modifiers.Apply(u,Buffs.RiftSpeed,0,now);
            }
            for(int i=Portals.Count-1;i>=0;i--)if(Portals[i].Until<=now)Portals.RemoveAt(i);
            for(int i=channels.Count-1;i>=0;i--)
            {
                var c=channels[i];var u=w.Get(c.Actor);
                if(u==null||!u.Alive||now>=c.Expires||V2.Distance(c.Origin,u.Position)>1){channels.RemoveAt(i);continue;}
                if(now>=c.Finish){u.Position=c.Destination;u.Path.Clear();u.HasDestination=false;u.PortalCooldown=(float)now+15;w.Modifiers.Apply(u,Buffs.PortalSpeed,u.Id,now);channels.RemoveAt(i);}
            }
        }
        public bool UsePortal(Unit u)
        {
            if(u==null||!u.Alive||!u.IsHero||w.Clock.Time<u.PortalCooldown)return false;
            foreach(var c in channels)if(c.Actor==u.Id)return false;
            foreach(var p in Portals)if(p.Team==u.Team&&p.Until>w.Clock.Time)
            {
                bool atA=V2.Distance(u.Position,p.A)<3,atB=V2.Distance(u.Position,p.B)<3;
                if(!atA&&!atB)continue;
                channels.Add(new PortalChannel{Actor=u.Id,Origin=u.Position,Destination=atA?p.B:p.A,Finish=w.Clock.Time+1,Expires=p.Until});return true;
            }
            return false;
        }
        public void InterruptPortal(int actor){for(int i=channels.Count-1;i>=0;i--)if(channels[i].Actor==actor)channels.RemoveAt(i);}
        public Unit NearestAvailable(V2 point)
        {
            Unit best=null;float distance=float.MaxValue;
            foreach(var u in w.Units)if(u.Alive&&u.Kind==Kind.Monster){float d=V2.Distance(point,u.Position);if(d<distance){distance=d;best=u;}}
            return best;
        }
        public void ThinkMonster(Unit u)
        {
            var target=w.Get(u.Target);
            if(V2.Distance(u.Position,u.Spawn)>11)
            {u.Target=0;u.Health=Math.Min(u.BaseHealth,u.Health+u.BaseHealth*.1f*GameClock.Step);w.MoveDirect(u,u.Spawn);return;}
            if(target==null||!target.Alive||!target.IsHero||V2.Distance(target.Position,u.Spawn)>12)
            {
                target=w.ClosestHero(Team.Blue,u.Position,7);var red=w.ClosestHero(Team.Red,u.Position,7);
                if(red!=null&&(target==null||V2.Distance(red.Position,u.Position)<V2.Distance(target.Position,u.Position)))target=red;
                u.Target=target==null?0:target.Id;
            }
            if(target==null){w.MoveDirect(u,u.Spawn);u.Health=Math.Min(u.BaseHealth,u.Health+u.BaseHealth*.1f*GameClock.Step);return;}
            if(V2.Distance(u.Position,target.Position)<=u.Range)
            {
                if(w.Combat.Attack(u,target)&&u.Camp>=14&&w.Clock.Tick%3==0)w.AddTelegraph(u,target.Position,5,u.Camp==14?180:220,1,false);
            }
            else w.MoveDirect(u,target.Position);
        }
        public void OnDeath(Unit killer,Unit dead)
        {
            var camp=Camps[dead.Camp];if(!camp.Active)return;
            foreach(var u in w.Units)if(u.Alive&&u.Camp==dead.Camp)return;
            camp.Active=false;camp.SpawnAt=w.Clock.Time+camp.Respawn;
            if(dead.Camp>=14)w.Notify(NoticeKind.Boss,dead.Camp==14?"Солнечный колосс повержен":"Ночной левиафан повержен",killer==null?Team.Neutral:killer.Team);
            if(killer==null||!killer.IsHero)return;
            if(dead.Camp<14)
            {
                killer.Gold+=camp.Gold;w.GainXp(killer,camp.Xp);
                if(dead.Camp<12&&dead.Camp%6==0)w.Modifiers.Apply(killer,Buffs.Magma,killer.Id,w.Clock.Time);
                if(dead.Camp<12&&dead.Camp%6==3){w.Modifiers.Apply(killer,Buffs.Azure,killer.Id,w.Clock.Time);w.Modifiers.Apply(killer,Buffs.AzureCooldown,killer.Id,w.Clock.Time);}
                if(dead.Camp>=12)Zones.Add(new ObjectiveZone{Position=camp.Position,Team=killer.Team,Until=w.Clock.Time+45,Vision=dead.Camp==12});
                return;
            }
            foreach(var u in w.Units)if(u.IsHero&&u.Team==killer.Team)u.Gold+=dead.Camp==14?60:100;
            w.GainXp(killer,dead.Camp==14?180:250);
            if(dead.Camp==14){w.Waves.Bless(killer.Team);w.Emit("Благословение Рассвета: две будущие волны на каждой линии");}
            else
            {
                Portals.RemoveAll(p=>p.Team==killer.Team);
                float sign=killer.Team==Team.Blue?1:-1;
                Portals.Add(new PortalState{Team=killer.Team,A=new V2(-34,-24)*sign,B=new V2(-14,-6)*sign,Until=w.Clock.Time+90});
                w.Emit("Врата Бездны открыты на 90 секунд · E у портала");
            }
        }
    }
}
