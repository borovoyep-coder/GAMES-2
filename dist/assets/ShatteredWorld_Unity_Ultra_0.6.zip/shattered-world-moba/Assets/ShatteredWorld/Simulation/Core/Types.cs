using System;
using System.Collections.Generic;

namespace ShatteredWorld.Simulation
{
    [Serializable]
    public struct V2
    {
        public float X, Y;
        public V2(float x, float y) { X = x; Y = y; }
        public float Length => (float)Math.Sqrt(X * X + Y * Y);
        public V2 Normalized => Length > .001f ? this / Length : new V2();
        public static V2 operator +(V2 a, V2 b) => new V2(a.X + b.X, a.Y + b.Y);
        public static V2 operator -(V2 a, V2 b) => new V2(a.X - b.X, a.Y - b.Y);
        public static V2 operator *(V2 a, float b) => new V2(a.X * b, a.Y * b);
        public static V2 operator /(V2 a, float b) => new V2(a.X / b, a.Y / b);
        public static float Distance(V2 a, V2 b) => (a - b).Length;
        public static float SegmentDistance(V2 p, V2 a, V2 b)
        {
            var d = b - a; var t = Math.Max(0, Math.Min(1, ((p.X-a.X)*d.X+(p.Y-a.Y)*d.Y) / Math.Max(.001f,d.X*d.X+d.Y*d.Y)));
            return Distance(p, a + d * t);
        }
    }
    public enum Team { Blue, Red, Neutral }
    public enum Kind { Warrior, Mage, Guard, Caster, Destroyer, Tower, Core, Monster }
    public enum CommandType { Move, Stop, Attack, Ability, Recall, Buy }
    public enum DamageType { Physical, Magical, True }
    public enum MatchPhase { Playing, Finished }
    [Serializable]
    public struct GameCommand
    {
        public int Actor, Target, Slot;
        public CommandType Type;
        public V2 Point;
    }
    [Serializable]
    public struct UnitSnapshot
    {
        public int Id, Level; public Team Team; public Kind Kind; public V2 Position; public float Health, MaxHealth;
    }
    [Serializable]
    public class WorldSnapshot
    {
        public long Tick; public double Time; public MatchPhase Phase; public int NavigationRevision;
        public UnitSnapshot[] Units;
    }
    public sealed class GameClock
    {
        public const float Step = .05f;
        public long Tick { get; private set; }
        public double Time => Tick * (double)Step;
        public void Advance() { Tick++; }
    }
    [Serializable]
    public sealed class MatchRules
    {
        public float FirstWave = 10, WaveInterval = 25, LateWaveTime = 600;
        public float BridgeStart = 120, BridgePeriod = 120, BridgeWarning = 15;
        public float CrystalRespawn = 60, HeroRespawn = 12;
        public float HeroHealth = 1100, MageHealth = 850, TowerHealth = 1600, CoreHealth = 3600;
        public float HeroDamage = 90, MageDamage = 72, MinionHealth = 330, MinionDamage = 32, TowerDamage = 115;
        public float HeroSpeed = 7, PassiveGold = 2, LevelXp = 180;
        public float WaveHealthGrowth = .06f, WaveDamageGrowth = .05f;
        public float FountainRadius=4.8f,FountainHealthPerSecond=.18f,FountainManaPerSecond=40;
        public float VisionRadius=16,BushDetectionRadius=3,BushVisionHistory=5,BushEntryReveal=2;
        public float CasterProjectileSpeed=17,SiegeProjectileSpeed=12,StructureProjectileSpeed=20,StructureWindup=.32f;
        public float MinionSpeed=4.2f,MinionMeleeRange=2.2f,MinionRangedRange=7,MinionMeleeWindup=.24f,MinionCasterWindup=.24f,MinionSiegeWindup=.4f;
        public float SiegeHealthMultiplier=1.8f,SiegeStructureMultiplier=1.7f,MinionHeroAggroDuration=2.5f;
        public float[] AbilityCost = { 35, 55, 100 };
        public float[] AbilityCooldown = { 7, 11, 35 };
    }
    public enum NoticeKind { Bridge, BridgeWarning, Tower, Boss }
    public sealed class WorldNotice
    {
        public double Time;public string Text;public NoticeKind Kind;public Team Team;
    }
    public sealed class GameEvent
    {
        public double Time; public string Text;
        public GameEvent(double time, string text) { Time = time; Text = text; }
    }
}
