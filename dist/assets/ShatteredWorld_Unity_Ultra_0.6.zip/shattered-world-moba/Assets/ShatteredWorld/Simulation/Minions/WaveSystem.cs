namespace ShatteredWorld.Simulation
{
    public sealed class WaveSystem
    {
        readonly MatchWorld w;public int WaveNumber{get;private set;} public double NextWave{get;private set;}
        public readonly int[,] BlessedWaves=new int[2,3];
        public WaveSystem(MatchWorld world){w=world;NextWave=w.Rules.FirstWave;}
        public void Bless(Team team){for(int lane=0;lane<3;lane++)BlessedWaves[(int)team,lane]=2;}
        public void Update()
        {
            if(w.Clock.Time+1e-5<NextWave)return;
            double scheduled=NextWave;NextWave+=w.Rules.WaveInterval;WaveNumber++;
            bool siege=WaveNumber%3==0||scheduled>=w.Rules.LateWaveTime;
            for(int team=0;team<2;team++)for(int lane=0;lane<3;lane++)
            {
                bool blessed=BlessedWaves[team,lane]>0;if(blessed)BlessedWaves[team,lane]--;
                int count=siege?4:3;
                for(int i=0;i<count;i++)
                {
                    var kind=i<2?Kind.Guard:i==2?Kind.Caster:Kind.Destroyer;
                    var u=w.Spawn(kind,(Team)team,w.Layout.Bases[team]);u.Lane=lane;
                    u.BaseHealth*=1+(WaveNumber-1)*w.Rules.WaveHealthGrowth;u.Health=u.BaseHealth;
                    u.Damage*=1+(WaveNumber-1)*w.Rules.WaveDamageGrowth;
                    float exitDistance=4.8f+(count-1-i)*1.4f;
                    u.LaneDistance=team==0?exitDistance:w.Layout.LaneLength(lane)-exitDistance;
                    u.Position=w.Layout.LanePoint(lane,u.LaneDistance);u.SiegeBlessing=blessed;
                    if(blessed){w.Modifiers.Apply(u,Buffs.DawnHealth,u.Id,w.Clock.Time);u.Health=u.Stat(Stat.Health,w.Clock.Time);}
                }
            }
        }
    }
}
