using System;
namespace ShatteredWorld.Simulation
{
    public sealed class BotSystem
    {
        readonly MatchWorld w;
        public BotSystem(MatchWorld world){w=world;}
        public void Update(Unit u)
        {
            if(!u.Alive)return;
            if(u.IsStructure)
            {
                var current=w.Get(u.Target);
                if(current==null||!w.Combat.CanTarget(u,current)||V2.Distance(u.Position,current.Position)>u.Range)current=w.FindTarget(u,u.Range,true);
                if(current!=null){u.Target=current.Id;w.Combat.Attack(u,current);}return;
            }
            if(u.Kind==Kind.Monster){w.Objectives.ThinkMonster(u);return;}
            if(u.IsPlayer)return;
            if(u.IsMinion)
            {
                var enemy=w.Get(u.Target);
                // Minions and structures are committed targets until death. A hero is released
                // as soon as it leaves attack range. Neutral creatures are never acquired.
                if(enemy==null||!enemy.Alive||!w.Combat.CanTarget(u,enemy,true)||enemy.IsHero&&!w.Combat.InAttackRange(u,enemy))
                    enemy=AcquireMinionTarget(u);
                u.Target=enemy==null?0:enemy.Id;
                if(enemy!=null&&w.Combat.InAttackRange(u,enemy)){w.Combat.Attack(u,enemy);return;}
                float direction=u.Team==Team.Blue?1:-1;
                if(enemy!=null)
                {
                    float along=w.Layout.NearestLaneDistance(u.Lane,enemy.Position);
                    direction=along>=u.LaneDistance?1:-1;
                }
                float nextDistance=Math.Max(0,Math.Min(w.Layout.LaneLength(u.Lane),u.LaneDistance+direction*u.Stat(Stat.Speed,w.Clock.Time)*GameClock.Step));
                var next=w.Layout.LanePoint(u.Lane,nextDistance);
                if(w.Navigation.SegmentClear(u.Position,next)){u.LaneDistance=nextDistance;u.Position=next;}
                return;
            }
            var target=w.Get(u.Target);
            if(w.Clock.Time>=u.NextThink)
            {
                u.NextThink=w.Clock.Time+.35;
                if(u.Health<u.Stat(Stat.Health,w.Clock.Time)*.25f)u.Retreating=true;
                if(u.Health>=u.Stat(Stat.Health,w.Clock.Time)*.9f)u.Retreating=false;
                if(u.Retreating)
                {u.Target=0;SetDestination(u,w.Layout.Fountains[(int)u.Team]);}
                else
                {
                    target=w.FindTarget(u,13,false);
                    if(target!=null){u.Target=target.Id;SetDestination(u,target.Position);}
                    else
                    {
                        u.Target=0;
                        if(u.Lane==3)
                        {
                            Unit objective=w.Objectives.NearestAvailable(u.Position);
                            SetDestination(u,objective==null?w.Layout.LanePoint(1,w.Layout.LaneLength(1)*.5f):objective.Position);
                            if(objective!=null)u.Target=objective.Id;
                        }
                        else
                        {
                            Unit structure=w.NextStructure(u.Team,u.Lane);
                            if(structure!=null)
                            {
                                float current=w.Layout.NearestLaneDistance(u.Lane,u.Position);
                                float destination=w.Layout.NearestLaneDistance(u.Lane,structure.Position);
                                float ahead=u.Team==Team.Blue?Math.Min(current+9,destination):Math.Max(current-9,destination);
                                SetDestination(u,w.Layout.LanePoint(u.Lane,ahead));
                            }
                        }
                    }
                }
            }
            target=w.Get(u.Target);
            if(target!=null&&w.Combat.CanTarget(u,target)&&V2.Distance(u.Position,target.Position)<=u.Range)
            {
                w.Combat.Attack(u,target);
                if(target.IsHero||target.Kind==Kind.Monster)for(int i=0;i<3;i++)if(w.Combat.Ability(u,i,target.Position))break;
                return;
            }
            w.FollowPath(u);
        }
        Unit AcquireMinionTarget(Unit actor)
        {
            Unit best=null;int bestPriority=int.MaxValue;float bestDistance=float.MaxValue;
            foreach(var candidate in w.Units)
            {
                if(candidate.Team==Team.Neutral||!w.Combat.CanTarget(actor,candidate))continue;
                if(candidate.IsMinion&&(candidate.Lane!=actor.Lane||!MapLayout.NearRoute(candidate.Position,w.Layout.Lanes[actor.Lane],3.2f)))continue;
                if(candidate.Kind==Kind.Tower&&candidate.Lane!=actor.Lane)continue;
                float distance=V2.Distance(actor.Position,candidate.Position);
                if(candidate.IsHero?!w.Combat.InAttackRange(actor,candidate):distance>8+w.Combat.Footprint(candidate))continue;
                int priority=candidate.IsMinion?0:candidate.IsStructure?1:2;
                if(priority<bestPriority||priority==bestPriority&&distance<bestDistance)
                {best=candidate;bestPriority=priority;bestDistance=distance;}
            }
            return best;
        }
        public void SetDestination(Unit u,V2 point)
        {
            if(V2.Distance(u.Destination,point)>2||!u.HasDestination){u.Destination=point;u.HasDestination=true;u.RepathAt=0;}
        }
    }
}
