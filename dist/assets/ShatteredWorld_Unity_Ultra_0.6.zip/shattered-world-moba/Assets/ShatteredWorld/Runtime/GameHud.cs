using System;
using UnityEngine;
using ShatteredWorld.Simulation;
namespace ShatteredWorld.Unity
{
    public sealed partial class GameApp
    {
        GUIStyle titleStyle,headingStyle,labelStyle,smallStyle,buttonStyle,centerStyle;
        readonly Color ink=new Color(.035f,.065f,.085f,.96f),muted=new Color(.58f,.66f,.66f),paper=new Color(.9f,.91f,.84f);
        void Styles()
        {
            if(titleStyle!=null)return;
            titleStyle=new GUIStyle(GUI.skin.label){fontSize=54,fontStyle=FontStyle.Bold,wordWrap=true};titleStyle.normal.textColor=WorldRenderer.Gold;
            headingStyle=new GUIStyle(GUI.skin.label){fontSize=24,fontStyle=FontStyle.Bold};headingStyle.normal.textColor=paper;
            labelStyle=new GUIStyle(GUI.skin.label){fontSize=19,wordWrap=true};labelStyle.normal.textColor=paper;
            smallStyle=new GUIStyle(labelStyle){fontSize=15};smallStyle.normal.textColor=muted;
            centerStyle=new GUIStyle(headingStyle){alignment=TextAnchor.MiddleCenter};
            buttonStyle=new GUIStyle(GUI.skin.button){fontSize=20,fontStyle=FontStyle.Bold,alignment=TextAnchor.MiddleCenter};
        }
        void Fill(Rect r,Color c){Color previous=GUI.color;GUI.color=c;GUI.DrawTexture(r,Texture2D.whiteTexture);GUI.color=previous;}
        void Text(float x,float y,float w,float h,string text,GUIStyle style=null){GUI.Label(new Rect(x,y,w,h),text,style??labelStyle);}
        bool Button(float x,float y,float w,float h,string text,bool gold=false)
        {
            Color old=GUI.backgroundColor;GUI.backgroundColor=gold?WorldRenderer.Gold:new Color(.14f,.26f,.29f);bool clicked=GUI.Button(new Rect(x,y,w,h),text,buttonStyle);GUI.backgroundColor=old;return clicked;
        }
        string Stamp(double time){int t=(int)time;return $"{t/60:00}:{t%60:00}";}
        void OnGUI()
        {
            if(World==null)return;Styles();
            GUI.matrix=Matrix4x4.Scale(new Vector3(Screen.width/1600f,Screen.height/900f,1));
            if(menu){Menu();return;}
            HealthBars();
            Fill(new Rect(0,0,1600,78),ink);Fill(new Rect(0,77,1600,2),WorldRenderer.Gold);
            Text(28,12,380,28,"ДОЛИНА ОСКОЛКОВ",headingStyle);Text(28,44,400,24,training?"ТРЕНИРОВКА · F1 — инструменты":"ЛОКАЛЬНЫЙ МАТЧ · 5 × 5",smallStyle);
            Text(605,8,160,55,World.Kills[0].ToString(),centerStyle);Text(725,8,150,55,Stamp(World.Clock.Time),centerStyle);Text(865,8,150,55,World.Kills[1].ToString(),centerStyle);
            if(Button(1230,15,155,46,"Магазин · I"))shop=!shop;
            if(Button(1400,15,175,46,paused?"Продолжить":"Пауза · Esc"))paused=!paused;
            MiniMap();HeroPanel();AbilityPanel();JoystickPanel();BattleAnnouncements.Draw(World);
            if(World.Events.Count>0)
            {
                var message=World.Events[World.Events.Count-1];if(World.Clock.Time-message.Time<8)
                {Fill(new Rect(430,94,740,44),ink);Text(445,100,710,35,message.Text,smallStyle);}
            }
            Fill(new Rect(265,840,570,42),ink);Text(280,847,560,30,"WASD · ПКМ — путь · Пробел — атака · Q / E / R · B — база",smallStyle);
            if(shop)Shop();if(dev&&training)DevPanel();
            if(paused)PausePanel();
            if(World.Phase==MatchPhase.Finished)EndPanel();
        }
        void Menu()
        {
            Fill(new Rect(0,0,650,900),new Color(.025f,.05f,.065f,.96f));
            Text(54,60,540,32,"SHATTERED WORLD  /  ПРОТОТИП 0.6",smallStyle);
            Fill(new Rect(56,112,60,3),WorldRenderer.Gold);
            Text(50,145,580,150,"РАСКОЛОТЫЙ\nМИР",titleStyle);
            Text(56,315,550,50,"Долина осколков",headingStyle);
            Text(56,378,515,90,"Два королевства. Меняющиеся пути.\nКонтроль пространства решает исход боя.");
            if(Button(56,500,255,50,mage?"Герой: маг":"Герой: воин"))mage=!mage;
            if(Button(56,575,510,72,"НАЧАТЬ МАТЧ   →",true))StartMatch(false);
            if(Button(56,665,245,56,"Тренировка"))StartMatch(true);
            if(Button(320,665,246,56,"Настройки"))settings=!settings;
            Text(56,770,520,66,"Один игрок и девять ботов · 3D · Unity\nАвторские 3D-модели и анимации Blender",smallStyle);
            Fill(new Rect(1030,710,510,125),ink);Text(1050,725,470,36,"ПОЛЕ БОЯ МЕНЯЕТСЯ",headingStyle);
            Text(1050,770,465,60,"2 моста · 8 кристальных проходов\nПервый мост откроется на 2:00",smallStyle);
            if(settings)
            {
                Fill(new Rect(700,180,720,380),ink);Text(735,210,650,40,"НАСТРОЙКИ",headingStyle);
                Text(735,285,620,45,"Обзор камеры: "+zoom.ToString("F0"));zoom=GUI.HorizontalSlider(new Rect(735,345,600,30),zoom,18,55);
                Text(735,395,600,80,"Горизонтальная ориентация · цель 60 FPS\nЗамеры производительности на телефоне ещё не выполнены.",smallStyle);
                if(Button(735,485,260,48,"Закрыть"))settings=false;
            }
        }
        void HeroPanel()
        {
            var p=World.Player;Fill(new Rect(550,715,500,110),ink);
            Text(570,724,400,30,$"{(p.Kind==Kind.Warrior?"ВОИН":"МАГ")}   ·   УР. {p.Level}   ·   {(int)p.Gold} зол.",headingStyle);
            Bar(new Rect(570,768,460,18),p.Health,p.Stat(Stat.Health,World.Clock.Time),new Color(.25f,.72f,.44f));
            Bar(new Rect(570,796,460,10),p.Mana,p.MaxMana,WorldRenderer.Blue);
            if(!p.Alive)Text(570,670,500,38,"Возрождение через "+Mathf.CeilToInt(p.RespawnAt-(float)World.Clock.Time)+" с",headingStyle);
            if(p.RecallUntil>0)Text(570,670,500,38,"Возвращение на базу…",headingStyle);
            float x=550;foreach(var modifier in p.Modifiers)
            {if(modifier.Definition.Id.EndsWith("cdr"))continue;Fill(new Rect(x,635,180,32),ink);Text(x+6,639,174,28,modifier.Definition.Name,smallStyle);x+=185;if(x>1050)break;}
        }
        void Bar(Rect rect,float value,float max,Color color)
        {Fill(rect,new Color(.09f,.14f,.14f));var fill=rect;fill.width*=Mathf.Clamp01(value/Mathf.Max(1,max));Fill(fill,color);}
        void AbilityPanel()
        {
            var p=World.Player;
            string[] labels=p.Kind==Kind.Warrior?new[]{"Q · Рывок","E · Вихрь","R · Разлом"}:new[]{"Q · Импульс","E · Оковы","R · Катаклизм"};
            for(int i=0;i<3;i++)
            {
                int cooldown=Mathf.CeilToInt((float)(p.Cooldowns[i]-World.Clock.Time));
                if(Button(1110+i*155,710,143,72,cooldown>0?cooldown+" с":labels[i],i==2))Send(CommandType.Ability,AimPoint(),slot:i);
            }
            if(GUI.RepeatButton(new Rect(1320,800,250,78),"АТАКА · Пробел",buttonStyle))Send(CommandType.Attack);
            if(Button(1110,800,190,55,"На базу · B"))Send(CommandType.Recall);
            if(World.Objectives.Portals.Count>0&&Button(1110,860,190,35,"Портал · F"))World.Objectives.UsePortal(p);
        }
        void JoystickPanel()
        {
            Fill(new Rect(45,710,170,170),new Color(.04f,.12f,.14f,.75f));
            Text(60,725,145,30,"ДВИЖЕНИЕ",smallStyle);
            Fill(new Rect(111+joystick.X*48,785-joystick.Y*48,40,40),new Color(.53f,.67f,.57f,.9f));
        }
        void HealthBars()
        {
            foreach(var u in World.Units)if(u.Alive&&World.Visible(World.Player.Team,u))
            {
                var p=viewCamera.WorldToScreenPoint(WorldRenderer.P(u.Position,u.IsStructure?7:u.Camp>=14?7:3.8f));
                if(p.z<0||p.x<0||p.x>Screen.width||p.y<0||p.y>Screen.height)continue;
                float x=p.x*1600/Screen.width,y=(Screen.height-p.y)*900/Screen.height;float width=u.IsHero?62:u.IsStructure?68:36;
                Bar(new Rect(x-width/2,y,width,5),u.Health,u.Stat(Stat.Health,World.Clock.Time),u.Team==Team.Blue?WorldRenderer.Blue:u.Team==Team.Red?WorldRenderer.Red:WorldRenderer.Gold);
            }
        }
        Vector2 MapPoint(V2 p)=>new Vector2(24+(p.X+70)/140*210,658-(p.Y+70)/140*210);
        void MapDot(V2 p,Color color,float size){var q=MapPoint(p);Fill(new Rect(q.x-size/2,q.y-size/2,size,size),color);}
        void MapLine(V2 a,V2 b,Color color,float width=2)
        {
            var p=MapPoint(a);var q=MapPoint(b);var matrix=GUI.matrix;GUIUtility.RotateAroundPivot(Mathf.Atan2(q.y-p.y,q.x-p.x)*Mathf.Rad2Deg,p);
            Fill(new Rect(p.x,p.y,Vector2.Distance(p,q),width),color);GUI.matrix=matrix;
        }
        void MiniMap()
        {
            Fill(new Rect(12,422,235,250),ink);Text(24,425,220,25,"ДОЛИНА ОСКОЛКОВ",smallStyle);
            foreach(var lane in World.Layout.Lanes)for(int i=1;i<lane.Length;i++)MapLine(lane[i-1],lane[i],new Color(.43f,.45f,.33f),3);
            MapLine(new V2(-44,44),new V2(44,-44),new Color(.08f,.45f,.47f),3);
            foreach(var u in World.Units)if(u.Alive&&World.Visible(World.Player.Team,u))
            {
                Color c=u.Team==Team.Blue?WorldRenderer.Blue:u.Team==Team.Red?WorldRenderer.Red:WorldRenderer.Gold;
                MapDot(u.Position,c,u.IsHero?6:u.IsStructure?7:2.5f);
            }
            for(int i=0;i<2;i++)MapDot(World.Layout.Bridges[i],World.Map.Bridges[i].Warning?Color.white:World.Map.Bridges[i].Open?new Color(.3f,1,.6f):new Color(.3f,.35f,.35f),8);
            for(int i=0;i<8;i++)if(V2.Distance(World.Player.Position,World.Layout.Crystals[i])<16&&!World.Map.Crystals[i].Broken)MapDot(World.Layout.Crystals[i],WorldRenderer.Purple,4);
            MapDot(World.Player.Position,Color.white,7);
        }
        void Shop()
        {
            Fill(new Rect(430,200,740,420),ink);Text(460,225,650,42,"ЛАВКА ДРЕВНИХ",headingStyle);
            bool atBase=V2.Distance(World.Player.Position,World.Layout.Bases[(int)World.Player.Team])<9||V2.Distance(World.Player.Position,World.Layout.Fountains[(int)World.Player.Team])<World.Rules.FountainRadius;
            Text(460,278,650,45,atBase?"Покупки доступны · максимум 3 каждого предмета":"Вернитесь на базу для покупки",smallStyle);
            string[] names={"Клинок\n+20 урона","Сердце камня\n+200 здоровья","Кристалл потока\n+3 маны/с"};
            for(int i=0;i<3;i++)if(Button(460+i*225,350,210,120,names[i]+"\n200 зол. · "+World.Player.Items[i]+"/3"))Send(CommandType.Buy,slot:i);
            if(Button(460,530,650,52,"Закрыть"))shop=false;
        }
        void DevPanel()
        {
            Fill(new Rect(1170,100,410,550),ink);Text(1190,118,370,35,"РЕЖИМ РАЗРАБОТЧИКА",headingStyle);
            Text(1190,163,360,35,"Скорость симуляции: ×"+simulationSpeed,smallStyle);
            if(Button(1190,205,165,45,"×1"))simulationSpeed=1;if(Button(1370,205,185,45,"×8"))simulationSpeed=8;
            if(Button(1190,270,365,50,"+ 60 секунд")){for(int i=0;i<1200&&World.Phase==MatchPhase.Playing;i++)World.Step();}
            if(Button(1190,335,365,50,"+ 1000 золота"))World.Player.Gold+=1000;
            if(Button(1190,400,365,50,"Вызвать боссов")){World.Objectives.Camps[14].SpawnAt=World.Clock.Time;World.Objectives.Camps[15].SpawnAt=World.Clock.Time;}
            if(Button(1190,465,365,50,"Полный обзор карты · Tab"))overview=!overview;
            if(Button(1190,530,365,50,"Восстановить героя")){World.Player.Health=World.Player.BaseHealth;World.Player.Mana=World.Player.MaxMana;}
            Text(1190,600,360,30,"Инструменты доступны только в тренировке",smallStyle);
        }
        void PausePanel()
        {
            Fill(new Rect(500,240,600,390),ink);Text(550,280,500,70,"МАТЧ ПРИОСТАНОВЛЕН",centerStyle);
            if(Button(550,385,500,60,"Продолжить",true))paused=false;
            if(Button(550,480,500,60,"В главное меню")){menu=true;paused=false;}
        }
        void EndPanel()
        {
            Fill(new Rect(0,0,1600,900),new Color(.015f,.035f,.045f,.86f));
            Text(450,240,800,100,World.Winner==World.Player.Team?"ПОБЕДА":"ПОРАЖЕНИЕ",titleStyle);
            Text(450,370,700,60,$"Ядро разрушено · {Stamp(World.Clock.Time)} · {World.Kills[0]} : {World.Kills[1]}",headingStyle);
            if(Button(450,485,650,70,"Новый матч",true))StartMatch(training);
            if(Button(450,580,650,60,"В главное меню"))menu=true;
        }
    }
}
