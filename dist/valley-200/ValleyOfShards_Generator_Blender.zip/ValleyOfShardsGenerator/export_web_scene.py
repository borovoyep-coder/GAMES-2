"""Export the actual Blender 200x200 scene into compact, material-batched web streams."""
import bpy,math,json,gzip,struct,hashlib,sys,os,shutil
from pathlib import Path
from array import array
from mathutils import Matrix,Vector
from mathutils.noise import noise
ROOT=Path(__file__).resolve().parent
OUT=Path(os.environ.get('VALLEY_WEB_OUT',str(ROOT/'web-output'))).resolve()
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'output/ValleyOfShards.blend'))
scene=bpy.data.scenes['ValleyOfShards_200'];bpy.context.window.scene=scene;scene.frame_set(1);dg=bpy.context.evaluated_depsgraph_get()
R=Matrix(((1,0,0,0),(0,0,1,0),(0,-1,0,0),(0,0,0,1)));Ri=R.inverted()
PICK={'tower','nexus','camp','boss','clearing','crystal_gate','stone_bridge','energy_bridge','fountain','hero','neutral'}
entities=[];entity_ids={};actors=[];actor_ids={};materials=[];material_ids={};templates={};batches={}
for obj in sorted(scene.objects,key=lambda o:o.name):
 if obj.get('category') in PICK:
  entity_ids[obj.name]=len(entities)+1;p=obj.matrix_world.translation
  properties={k:obj[k] for k in obj.keys() if isinstance(obj[k],(str,int,float,bool))}
  entities.append({'id':len(entities)+1,'name':obj.name.removeprefix('VOS200::'),'category':obj['category'],'position':[p.x,p.y,p.z],'properties':properties})

def motion(obj):
 if obj.get('category') in {'tower','nexus'}:return 'structure'
 if obj.get('category') in {'neutral','boss'}:return 'neutral'
 if obj.get('category')=='minion_template':return 'minion_template'
 if obj.get('minion_part'):return 'minion_part'
 if obj.get('category')=='hero':return 'hero'
 if 'Dynamic forest bridge deck' in obj.name:return 'bridge_deck'
 if 'rest_location' in obj:return 'shard'
 if 'Tower floating focus' in obj.name:return 'tower_focus'
 if 'Nexus hovering energy' in obj.name:return 'nexus_focus'
 if 'Energy bridge translucent segment' in obj.name:return 'energy'
 if 'Animated river foam' in obj.name:return 'foam'
 if 'Animated waterfall spray' in obj.name:return 'spray'
 if 'Animated waterfall bubbling ring' in obj.name:return 'ripple'
 if 'Orbiting elemental stone' in obj.name:return 'elemental'
 return None

motion_counts={}
for obj in sorted(scene.objects,key=lambda o:o.name):
 kind=motion(obj)
 if not kind:continue
 index=motion_counts.get(kind,0);motion_counts[kind]=index+1
 owner=obj
 while owner and owner.name not in entity_ids:owner=owner.parent
 matrix=R@obj.matrix_world@Ri;location,quaternion,scale=matrix.decompose()
 actor={'id':len(actors)+1,'name':obj.name,'motion':kind,'owner':entity_ids.get(owner.name,0) if owner else 0,'matrix':[matrix[row][col] for col in range(4) for row in range(4)],'position':list(location),'quaternion':list(quaternion)[1:]+[quaternion.w],'scale':list(scale),'index':index}
 actor['template_key']=obj.get('template_key','');actor['part']=obj.get('minion_part','')
 actor_ids[obj.name]=actor['id'];actors.append(actor)

for actor in actors:
 obj=bpy.data.objects[actor['name']];parent=obj.parent
 while parent and parent.name not in actor_ids:parent=parent.parent
 actor['parent']=actor_ids.get(parent.name,0) if parent else 0

# Sample each scene frame once for every particle, instead of reevaluating the forest per particle.
particles=[a for a in actors if a['motion'] in {'spray','ripple'}]
for actor in particles:
 actor['period']=(36 if actor['motion']=='spray' else 58)/24;actor['keys']=[]
for frame in range(1,60,2):
 scene.frame_set(frame)
 for actor in particles:
  period_frames=36 if actor['motion']=='spray' else 58
  if frame>period_frames+1:continue
  obj=bpy.data.objects[actor['name']];p,q,s=(R@obj.matrix_world@Ri).decompose()
  actor['keys'].append({'time':(frame-1)/24,'p':list(p),'q':[q.x,q.y,q.z,q.w],'s':list(s)})
scene.frame_set(1)

def material(mat):
 if mat.name in material_ids:return material_ids[mat.name]
 shader=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED');ramp=next((n for n in mat.node_tree.nodes if n.type=='VALTORGB'),None)
 item={'name':mat.name.removeprefix('VOS200::'),'roughness':shader.inputs['Roughness'].default_value,'metalness':shader.inputs['Metallic'].default_value,'emission':shader.inputs['Emission Strength'].default_value,'alpha':shader.inputs['Alpha'].default_value}
 tex=mat.node_tree.nodes.get('Surface painted detail')
 if tex and tex.image:item['texture']='textures/'+Path(tex.image.filepath).name;item['textureScale']=3
 material_ids[mat.name]=len(materials);materials.append(item);return material_ids[mat.name]

def template(obj):
 key=(obj.type,obj.data.as_pointer())
 if key in templates:return templates[key]
 ev=obj.evaluated_get(dg);mesh=ev.to_mesh(preserve_all_data_layers=True,depsgraph=dg);mesh.calc_loop_triangles()
 corners=getattr(mesh,'corner_normals',None);uv=mesh.uv_layers.active
 lo=Vector(tuple(min(v.co[i] for v in mesh.vertices) for i in range(3)));hi=Vector(tuple(max(v.co[i] for v in mesh.vertices) for i in range(3)));span=hi-lo
 groups={};cache={};colors={}
 for tri in mesh.loop_triangles:
  mat=mesh.materials[tri.material_index] if mesh.materials else bpy.data.materials['VOS200::Stone'];mi=material(mat)
  ramp=next((n for n in mat.node_tree.nodes if n.type=='VALTORGB'),None)
  group=groups.setdefault(mi,{'p':[],'n':[],'c':[],'u':[],'i':[]});local_cache=cache.setdefault(mi,{})
  for li in tri.loops:
   loop=mesh.loops[li];v=mesh.vertices[loop.vertex_index].co;n=corners[li].vector if corners else loop.normal;t=tuple(uv.data[li].uv) if uv else (v.x*.19+v.z*.08,v.y*.19+v.z*.05)
   k=(loop.vertex_index,round(n.x,5),round(n.y,5),round(n.z,5),round(t[0],5),round(t[1],5))
   if k not in local_cache:
    local_cache[k]=len(group['p']);group['p'].append(tuple(v));group['n'].append(tuple(n));group['u'].append(t)
    ck=(loop.vertex_index,mi)
    if ck not in colors:
     generated=Vector(tuple((v[i]-lo[i])/(span[i] or 1) for i in range(3)))
     fac=max(0,min(1,.5+.32*noise(generated*2.8,noise_basis='PERLIN_ORIGINAL')+.13*noise(generated*6.1,noise_basis='PERLIN_ORIGINAL')))
     colors[ck]=tuple(ramp.color_ramp.evaluate(fac)[:3]) if ramp else tuple(mat.diffuse_color[:3])
    group['c'].append(colors[ck])
   group['i'].append(local_cache[k])
 ev.to_mesh_clear();templates[key]=groups;return groups

triangles=0
for i,obj in enumerate(sorted(scene.objects,key=lambda o:o.name)):
 if obj.type not in {'MESH','CURVE','FONT','SURFACE'} or obj.get('physics_only'):continue
 owner=obj
 while owner and owner.name not in entity_ids:owner=owner.parent
 owner_id=entity_ids.get(owner.name,0) if owner else 0
 actor=obj
 while actor and actor.name not in actor_ids:actor=actor.parent
 actor_id=actor_ids.get(actor.name,0) if actor else 0
 transform=R@((actor.matrix_world.inverted()@obj.matrix_world) if actor else obj.matrix_world);normal_matrix=transform.to_3x3().inverted().transposed()
 for mi,src in template(obj).items():
  key=(actor_id,mi);dest=batches.setdefault(key,{'actor':actor_id,'material':mi,'position':array('f'),'normal':array('h'),'color':array('H'),'uv':array('f'),'index':array('I'),'owner':array('I')})
  offset=len(dest['position'])//3
  for p,n,c,u in zip(src['p'],src['n'],src['c'],src['u']):
   v=transform@Vector(p);nn=(normal_matrix@Vector(n)).normalized();dest['position'].extend(v);dest['normal'].extend(max(-32767,min(32767,round(x*32767))) for x in nn);dest['color'].extend(round(max(0,min(1,x))*65535) for x in c);dest['uv'].extend(u)
  dest['index'].extend(offset+x for x in src['i']);count=len(src['i'])//3;dest['owner'].extend([owner_id]*count);triangles+=count
 if i%500==0:print('OBJECT',i,obj.name,flush=True)

# Byte layout is explicit. Web decoder verifies array bounds before constructing geometry.
parts=[];current=[];size=0
for batch in batches.values():
 estimate=sum(len(batch[k])*batch[k].itemsize for k in ['position','normal','color','uv','index','owner'])
 if current and size+estimate>11*1024*1024:parts.append(current);current=[];size=0
 current.append(batch);size+=estimate
if current:parts.append(current)
files=[]
for part,groups in enumerate(parts):
 payload=bytearray();header={'meshes':[]}
 for batch in groups:
  item={'actor':batch['actor'],'material':batch['material']}
  for name in ['position','normal','color','uv','index','owner']:
   while len(payload)%4:payload.append(0)
   a=batch[name]
   if sys.byteorder!='little':a.byteswap()
   item[name]={'offset':len(payload),'count':len(a)};payload.extend(a.tobytes())
  header['meshes'].append(item)
 meta=json.dumps(header,separators=(',',':')).encode()
 while len(meta)%4:meta+=b' '
 binary=struct.pack('<I',len(meta))+meta+payload;data=gzip.compress(binary,compresslevel=7);filename=f'data/map.{part:03d}.vmesh.gz';assert len(data)<25*1024*1024
 (OUT/filename).write_bytes(data);files.append({'url':filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'triangles':sum(len(b['index'])//3 for b in groups)})
 print('PART',part,len(binary),len(data),flush=True)
manifest={'version':'200.4','coordinateSystem':'Three.js: X east, Y height, -Z north','sourceSha256':hashlib.sha256((ROOT/'output/ValleyOfShards.blend').read_bytes()).hexdigest(),'files':files,'materials':materials,'entities':entities,'actors':actors,'triangles':triangles,'sourceObjects':len(scene.objects),'animationCounts':motion_counts,'note':'Topology and object positions come from Blender. Procedural materials are adapted to vertex colours and web PBR shaders.'}
(OUT/'scene.json').write_text(json.dumps(manifest,ensure_ascii=False,separators=(',',':')))
(OUT/'layout.json').write_text((ROOT/'output/ValleyOfShards.layout.json').read_text())
(OUT/'textures').mkdir(exist_ok=True)
for texture in (ROOT/'output/textures').glob('*.png'):shutil.copy(texture,OUT/'textures'/texture.name)
print('EXPORT200 COMPLETE',len(entities),'interactive roots',len(actors),'animated actors',triangles,'triangles',len(files),'files',sum(f['bytes'] for f in files),'compressed bytes',flush=True)
