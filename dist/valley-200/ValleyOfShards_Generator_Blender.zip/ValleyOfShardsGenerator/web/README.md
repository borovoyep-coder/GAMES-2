# Восстановление браузерной сборки

Бинарные меши не дублируются в ZIP. Из корня пакета выполните:

```bash
VALLEY_WEB_OUT=./web/dist/valley-200 blender -b --python-exit-code 1 --python export_web_scene.py
cd web
node tests-gameplay.mjs
node tests-valley-200.mjs
node tests-combat.mjs
node tests-combat-view.mjs
node tests-symmetry.mjs
node tests-stealth.mjs
```

После экспорта папку `dist` можно разместить на статическом HTTP-хостинге; входная страница — `valley-200/index.html`. Онлайн-скачивание ZIP и ссылка на прежний прототип ведут на опубликованный сайт. Сервер и браузер в среде создания не запускались.
