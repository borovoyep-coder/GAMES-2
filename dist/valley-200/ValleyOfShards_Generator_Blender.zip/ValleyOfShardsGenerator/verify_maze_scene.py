"""Independent read-back: ray-test the real forest substrate and inspect room geometry."""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));import maze_plan as mp
bpy.ops.wm.open_mainfile(filepath=str(R/'output/ValleyOfShards.blend'));s=bpy.data.scenes['ValleyOfShards_200'];bpy.context.window.scene=s;s.frame_set(1)
l=json.loads((R/'output/ValleyOfShards.layout.json').read_text());items=lambda c:[o for o in s.objects if o.get('category')==c]
assert len(items('forest_mass'))==2 and len(items('room_wall'))==16 and len(items('bush'))==44
assert 434<=len(items('tree'))<=520
assert len(items('shore_wall'))==8 and len(l['shore_walls'])==8
assert .5<=len(items('tree'))/868<=.6
assert all(3<=len(g['points'])<=6 for g in l['groves'])
assert sum(len(g['points'])*2 for g in l['groves'])==len(items('tree'))
for i,g in enumerate(l['groves']):
 for other in l['groves'][:i]:
  assert min(math.dist(a,b) for a in g['points'] for b in other['points'])>=3.65-1e-5
for o in items('shore_wall'):
 assert o['blocks_movement']
 assert any(c.get('collider_type')=='MeshCollider' for c in o.children)
for o in items('tree'):
 crown=next(c for c in o.children if 'spruce crown' in c.name)
 assert len(crown.data.vertices)>=384 and crown.data.color_attributes.get('ValleyPaint')
 trunk=next(c for c in o.children if 'sculpted trunk' in c.name)
 assert len(trunk.data.vertices)>0
assert len(l['rooms'])==16 and sum(r['kind']=='clearing' for r in l['rooms'])==4
assert all(2<=len(r['doors'])<=3 for r in l['rooms'])
for o in items('room_wall'):assert o['blocks_movement'] and o['door_count'] in [2,3]
for o in items('forest_mass'):assert o['blocks_movement'] and o['collider_type']=='MeshCollider'
plan=mp.SurfacePlan(l['surface_specs']);bvh=[]
for o in items('forest_mass'):
 verts=[o.matrix_world@v.co for v in o.data.vertices];polys=[list(p.vertices) for p in o.data.polygons];bvh.append(BVHTree.FromPolygons(verts,polys))
checked=0
for x in range(-94,95):
 for z in range(-94,95):
  if abs(x-z)/math.sqrt(2)<8 or plan.clearance((x,z))<=.65:continue
  origin=Vector((x,-z,12));hits=[tree.ray_cast(origin,Vector((0,0,-1)),15)[0] for tree in bvh]
  assert any(p is not None and p.z>.20 for p in hits),(x,z,'Uncovered forest metre')
  checked+=1
assert checked>10000
print('PASS actual 3D forest coverage:',checked,'one-metre samples outside authored floors covered by solid rock/grove geometry',flush=True)
for o in items('bush'):
 assert o['trigger_shape']=='capsule' and 1.19<o['trigger_radius']<1.21
 for child in o.children:
  if child.type!='MESH':continue
  assert child.data.shape_keys and child.data.color_attributes.get('ValleyPaint')
  for v in child.data.vertices:
   p=child.matrix_world@v.co;assert abs(p.x+p.y)/math.sqrt(2)>7.3,(o.name,'Grass in water')
for c in items('clearing'):assert abs(c['radius']-6.8)<1e-5
for c in items('camp'):assert abs(c['pocket_radius']-l['camps'][c['camp_index']-1]['radius'])<1e-5
assert any(o.get('gate_flank') for o in items('tree'))
core=bpy.data.materials['VOS200::AmethystCore'];shader=next(n for n in core.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
s.frame_set(1);bright=shader.inputs['Emission Strength'].default_value;s.frame_set(40);dim=shader.inputs['Emission Strength'].default_value;assert bright>dim+.5
for gate in items('crystal_gate'):
 shards=[c for c in gate.children if 'rest_location' in c];assert len(shards)==5
 assert any(c.dimensions.z>5 for c in shards)
for frame in [1,35]:
 s.frame_set(frame)
 for o in items('bush'):
  for child in o.children:
   if child.type=='MESH' and child.data.shape_keys:
    value=child.data.shape_keys.key_blocks['Wind bend'].value;assert value<.001 if frame==1 else value>.9
print('PASS sixteen enclosing ruin rings, compact pockets, dry radial doorway grass, animated roots and crystal flank groves',flush=True)
print('PASS 40–50% tree reduction in compact groves, six painted needle tiers, exposed trunks, eight continuous bank walls and pulsing five-shard amethyst clusters',flush=True)
print('MAZE SCENE READ-BACK PASSED',flush=True)
