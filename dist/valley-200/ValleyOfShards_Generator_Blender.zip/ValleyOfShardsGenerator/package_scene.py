"""Package only checked source, saved Blender geometry, web files and renders."""
from pathlib import Path
import json,zipfile,hashlib,shutil
from PIL import Image
R=Path(__file__).resolve().parent;S=Path('/workspace/sites/valley-of-shards/dist/valley-200')
markers={'generation':'GENERATION COMPLETE','tests':'ALL GENERATOR INTEGRATION CHECKS PASSED','readback':'SAVED SCENE READ-BACK PASSED','forest-readback':'FOREST SCENE READ-BACK PASSED','art-readback':'ART SCENE READ-BACK PASSED','web-export':'EXPORT200 COMPLETE','details':'STYLE DETAIL RENDERS COMPLETE','web-tests':'VALLEY200 CPU CHECKS PASSED','gameplay-tests':'GAMEPLAY 200.9 CHECKS PASSED','combat-tests':'COMBAT 200.9 CHECKS PASSED','animation-tests':'ANIMATION CPU 200.9 CHECKS PASSED','symmetry-tests':'SYMMETRY 200.9 CHECKS PASSED','stealth-tests':'STEALTH 200.9 CHECKS PASSED','forest-tests':'FOREST 200.9 CHECKS PASSED'}
logs=[]
for key,marker in markers.items():
 name=key+'-2009.log';assert marker in (R/name).read_text(),name;logs.append(name)
master=R/'output/ValleyOfShards.blend';manifest=json.loads((S/'scene.json').read_text())
assert manifest['version']=='200.9' and manifest['sourceSha256']==hashlib.sha256(master.read_bytes()).hexdigest()
assert (S/'layout.json').read_bytes()==(R/'output/ValleyOfShards.layout.json').read_bytes()
for name,target in [('ValleyOfShards','overview'),('Valley_Detail','forest'),('Creature_Collection','creatures')]:
 p=R/'output'/(name+'.png');assert p.stat().st_mtime>=master.stat().st_mtime,p
 with Image.open(p) as im:im.convert('RGB').save(S/(target+'.jpg'),quality=92,optimize=True)
for p in (S/'data').glob('*.vmesh.gz'):
 if 'data/'+p.name not in {f['url'] for f in manifest['files']}:p.unlink()
source=['generate_valley.py','maze_plan.py','maze_scene.py','art_upgrade.py','export_web_scene.py','package_scene.py','render_style_details.py','verify_saved_scene.py','verify_maze_scene.py','verify_forest_scene.py','verify_art_scene.py','test_generator.py','README.md','TEST_REPORT.md','FONT_LICENSE.txt','output/ValleyOfShards.blend','output/ValleyOfShards.layout.json',*logs]
source += [str(p.relative_to(R)) for p in (R/'design-input').iterdir() if p.is_file()]
source += [str(p.relative_to(R)) for p in (R/'output/textures').glob('*.png')]
archive=R/'ValleyOfShards_Generator_Blender.zip';origin='https://valley-of-shards-play.tinyguide2.chatgpt.site'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for name in source:z.write(R/name,'ValleyOfShardsGenerator/'+name)
 for p in S.iterdir():
  if p.suffix in {'.mjs','.css','.jpg','.json'}:z.write(p,'ValleyOfShardsGenerator/web/dist/valley-200/'+p.name)
 for name in ['index.html','gallery.html']:
  text=(S/name).read_text().replace('href="ValleyOfShards_Generator_Blender.zip?',f'href="{origin}/valley-200/ValleyOfShards_Generator_Blender.zip?').replace('href="../unity-map/"',f'href="{origin}/unity-map/"');z.writestr('ValleyOfShardsGenerator/web/dist/valley-200/'+name,text)
 for name in ['three.module.js','OrbitControls.js','three.LICENSE.txt']:z.write(S.parent/'assets'/name,'ValleyOfShardsGenerator/web/dist/assets/'+name)
 for p in S.parent.parent.glob('tests-*.mjs'):z.write(p,'ValleyOfShardsGenerator/web/'+p.name)
 z.writestr('ValleyOfShardsGenerator/web/README.md','''# Восстановление браузерной сборки\n\nИз корня пакета: `VALLEY_WEB_OUT=./web/dist/valley-200 blender -b --python-exit-code 1 --python export_web_scene.py`. После экспорта разместите `web/dist` на статическом HTTP-хостинге; входная страница — `valley-200/index.html`. Бинарные меши восстанавливаются из настоящей `.blend` и не дублируются в ZIP. В папке `web` находятся семь Node-проверок. Изображения получены в Blender, браузер/WebGL в среде сборки не запускался.\n''')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;archive_count=len(z.namelist())
assert archive.stat().st_size<25*1024*1024,archive.stat().st_size
for name in ['ValleyOfShards_Generator_Blender.zip','generate_valley.py','maze_plan.py','maze_scene.py','art_upgrade.py','README.md','TEST_REPORT.md']:shutil.copy2(R/name,S/name)
(S/'WEB_TEST_REPORT.txt').write_text('\n'.join((R/(key+'-2009.log')).read_text() for key in markers if key.endswith('tests')))
(R/'download.json').write_text(json.dumps({'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_sha256':manifest['sourceSha256'],'files':archive_count},indent=2))
files=[p for p in S.parent.rglob('*') if p.is_file()];total=sum(p.stat().st_size for p in files)
assert all(p.stat().st_size<25*1024*1024 for p in files) and total<256*1024*1024
print('PACKAGE COMPLETE',round(archive.stat().st_size/1048576,2),'MiB source ZIP;',round(total/1048576,2),'MiB static site;',archive_count,'files',flush=True)
