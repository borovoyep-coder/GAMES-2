import bpy,math,json,sys,importlib.util
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'output/ValleyOfShards.blend'))
s=bpy.data.scenes['ValleyOfShards_200'];bpy.context.window.scene=s;s.frame_set(1)
l=json.loads((R/'output/ValleyOfShards.layout.json').read_text());items=lambda kind:[o for o in s.objects if o.get('category')==kind]
assert len(items('tower'))==18 and len(items('crystal_gate'))==6 and len(items('bush'))==26
for row in l['towers']:
 o=next(o for o in items('tower') if (o['team'],o['lane'],o['tier'])==(row['team'],row['lane'],row['tier']));assert abs(o.location.x-row['position']['X'])<1e-5 and abs(o.location.y-row['position']['Y'])<1e-5
for b in l['bushes']:
 o=next(o for o in items('bush') if o['bush_id']==b['id']);assert abs(o.location.x-b['position']['X'])<1e-5 and abs(o.location.y-b['position']['Y'])<1e-5;assert o['allied_opacity']>.449 and o['allied_opacity']<.451
rotation=Matrix.Rotation(math.pi,4,'Z');pairs=[o for o in s.objects if o.get('symmetric_partner')]
for frame in [1,35]:
 s.frame_set(frame);s.view_layers[0].update()
 for o in pairs:
  other=bpy.data.objects[o['symmetric_partner']];expected=rotation@o.matrix_world
  assert max(abs(other.matrix_world[i][j]-expected[i][j]) for i in range(4) for j in range(4))<.002,(o.name,frame)
assert len([o for o in s.objects if o.get('physics_collider') and o.hide_render])==4
assert len(items('neutral'))==24 and len(items('boss'))==2 and len(items('minion_template'))==6
assert len([o for o in s.objects if o.get('minion_part')])==20
assert all(abs(o.location.z)<1e-8 for o in items('hero'))
for i in range(1,7):
 a=next(o for o in items('camp') if o['camp_index']==i);b=next(o for o in items('camp') if o['camp_index']==i+6);assert (a.location.xy+b.location.xy).length<1e-5
for n in ['painted_stone.png','painted_earth.png','painted_foliage.png','flowing_water.png']:assert any(i.packed_file for i in bpy.data.images if i.filepath.endswith(n))
assert len(items('waterfall'))==6 and len(items('tree'))==72
print('PASS saved scene: all 18 exact towers, six gates, 26 exact StealthBush roots and paired camps',flush=True)
print('PASS 180-degree geometry and animated cascade pairs, four hidden BoxCollider perimeter meshes',flush=True)
print('PASS packed textures, planar heroes, six minion templates and 26 neutral creatures',flush=True)
print('SAVED SCENE READ-BACK PASSED',flush=True)
