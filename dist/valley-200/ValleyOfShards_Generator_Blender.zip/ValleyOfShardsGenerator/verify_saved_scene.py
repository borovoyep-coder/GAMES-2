import bpy,sys,importlib.util,json,math
from pathlib import Path
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('valley_generator',root/'generate_valley.py');g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
bpy.ops.wm.open_mainfile(filepath=str(root/'output/ValleyOfShards.blend'))
scene=bpy.data.scenes[g.SCENE_NAME];bpy.context.window.scene=scene
layout=json.loads((root/'output/ValleyOfShards.layout.json').read_text())
towers=[o for o in scene.objects if o.get('category')=='tower'];assert len(towers)==18
for row in layout['towers']:
 obj=next(o for o in towers if (o['team'],o['lane'],o['tier'])==(row['team'],row['lane'],row['tier']))
 assert abs(obj.location.x-row['position']['X'])<1e-6 and abs(obj.location.y-row['position']['Y'])<1e-6
trails=[o for o in scene.objects if o.type=='MESH' and 'Forest trail ' in o.name]
assert all(p.normal.z>.999 for o in trails for p in o.data.polygons)
assert len({round(o.data.vertices[0].co.z,6) for o in trails})==len(trails)
foam=[o for o in scene.objects if 'Animated river foam' in o.name];assert len(foam)==58
assert all(len(g.action_curves(o))>=6 for o in foam)
first=foam[0].location.copy();scene.frame_set(35);assert (foam[0].location-first).length>1
for name in ['RiverWater','SkyWater']:
 mat=bpy.data.materials[g.PREFIX+name];assert mat.node_tree.animation_data and mat.node_tree.animation_data.drivers
blue=bpy.data.materials[g.PREFIX+'BlueEnergy'];assert blue.diffuse_color[3]<.5
root_gate=next(o for o in scene.objects if o.get('gate_index')==1)
try:g.damage_crystal(root_gate,float('nan'));raise AssertionError('NaN input accepted')
except ValueError:pass
assert any(f.packed_file for f in bpy.data.fonts if getattr(f,'filepath','').endswith('DejaVuSans.ttf'))
assert not bpy.data.images.get('external texture')
meshes={o.data for o in scene.objects if o.type=='MESH'}
triangles=0
for mesh in meshes:mesh.calc_loop_triangles();triangles+=len(mesh.loop_triangles)
print('PASS saved .blend: 18 exact towers, all topology-safe trails, moving keyed foam, animated water nodes, translucent blue energy, packed font',flush=True)
print('PASS legacy/layered animation adapter on Blender '+bpy.app.version_string+'; NaN damage rejection',flush=True)
print('MESH INVENTORY',len(meshes),'unique mesh datablocks;',triangles,'unique prototype triangles',flush=True)
terraces=[o for o in scene.objects if o.name.startswith('VOS200::Lower buttress geological terrace')]
assert len({round(o.location.z,6) for o in terraces})==len(terraces)
shards=[o for o in root_gate.children if 'rest_location' in o]
assert all(any(c.name.startswith('VOS200::Inset crystal refracted facet') for c in o.children) for o in shards)
g.damage_crystal(root_gate,24,frame=80);scene.frame_set(104)
assert all(max(c.matrix_world.to_scale())<.01 for o in shards for c in o.children)
g.restore_crystal(root_gate,frame=120);scene.frame_set(140)
assert all(min(c.matrix_world.to_scale())>.99 for o in shards for c in o.children)
assert any('Leviathan continuous sculpted serpent' in o.name for o in scene.objects)
assert any('Colossus royal sun shield' in o.name for o in scene.objects)
print('PASS separate cliff cap heights, inherited crystal glint shatter/restore, continuous dragon and solar shield',flush=True)
print('SAVED SCENE READ-BACK PASSED',flush=True)
