"""Independent saved-scene checks for the 200.9 asset and balance revision."""
import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'output/ValleyOfShards.blend'));s=bpy.data.scenes['ValleyOfShards_200'];bpy.context.window.scene=s;s.frame_set(1)
items=lambda kind:[o for o in s.objects if o.get('category')==kind]
for t in items('tower'):
 assert t['health']=={1:6500,2:8000,3:10000}[t['tier']] and abs(t['minion_damage_reduction']-.2)<1e-6
 assert t['art_revision']=='jewel_sanctuary_2009'
 if t['lane']=='Mid':
  d={1:18,2:35,3:54}[t['tier']];sign=-1 if t['team']=='Light' else 1;assert abs(t.location.x-sign*d)<1e-6 and abs(t.location.y-sign*d)<1e-6
 assert any('sculpted golden crystal claw' in o.name for o in t.children)
assert all(o['art_revision']=='sculpted_2009' for o in items('neutral')+items('boss'))
assert all(o['art_revision']=='heraldic_2009' for o in items('minion_template'))
for name in ['painted_stone','painted_earth','painted_foliage','flowing_water','creature_scales','embroidered_cloth']:
 img=bpy.data.images['VOS200::'+name];assert img.packed_file and tuple(img.size)==(768,768)
river=bpy.data.materials['VOS200::RiverWater'];ramp=next(n for n in river.node_tree.nodes if n.type=='VALTORGB');c=ramp.color_ramp.elements[-1].color;assert c[2]>c[0]*5 and c[1]>c[0]*5
assert any('Wraith pointed sculpted hollow cowl' in o.name for o in s.objects)
assert any('Leviathan overlapping obsidian armor' in o.name for o in s.objects)
assert any('Guard sculpted heraldic shield rim' in o.name for o in s.objects)
assert any('Caster tailored folded cloth mantle' in o.name for o in s.objects)
assert len([o for o in s.objects if o.get('minion_part')])==20
print('ART SCENE READ-BACK PASSED: six packed maps, azure palette, carved tower/crystal silhouettes, ornate minions, sculpted neutrals, outward mid coordinates and 6500/8000/10000 tower HP',flush=True)
