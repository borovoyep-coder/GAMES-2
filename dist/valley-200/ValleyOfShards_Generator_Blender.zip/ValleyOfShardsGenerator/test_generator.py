"""Integration test for canonical half generation; execute inside Blender."""
import importlib.util,sys,json,math
from pathlib import Path
import bpy
from mathutils import Matrix
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('valley_generator',R/'generate_valley.py');g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
sentinel=bpy.data.objects.new('User object to preserve',None);bpy.context.scene.collection.objects.link(sentinel)
cfg=g.Config(output=R/'test-output',tree_count=2400,resolution=320,samples=1,labels=False)
a=g.build_map(cfg);one=json.loads((cfg.output/'ValleyOfShards.layout.json').read_text());b=g.build_map(cfg);two=json.loads((cfg.output/'ValleyOfShards.layout.json').read_text());assert one==two
assert sentinel.name in bpy.data.objects and sentinel.users_collection
assert len([s for s in bpy.data.scenes if s.name==g.SCENE_NAME])==1
assert len([o for o in b.scene.objects if o.get('category')=='crystal_gate'])==6
assert len([o for o in b.scene.objects if o.get('category')=='bush'])==44
assert len([o for o in b.scene.objects if o.get('physics_collider')])==4
rotation=Matrix.Rotation(math.pi,4,'Z')
for frame in [1,29]:
 b.scene.frame_set(frame);b.scene.view_layers[0].update()
 for left,right in b.registry['symmetric_pairs']:
  x=bpy.data.objects[left];y=bpy.data.objects[right];expected=rotation@x.matrix_world
  assert max(abs(y.matrix_world[i][j]-expected[i][j]) for i in range(4) for j in range(4))<.002,(left,right,frame)
  if x.type in {'MESH','CURVE'}:assert x.data==y.data
root=b.registry['crystal_1']
for _ in range(6):g.damage_crystal(root,4,frame=50)
assert root['durability']==0
b.scene.frame_set(74);assert all(o.scale.x<.002 for o in root.children if 'rest_location' in o)
g.restore_crystal(root,frame=80);b.scene.frame_set(100);assert root['durability']==24
for side in ['Light','Dark']:
 camps=[o for o in b.scene.objects if o.get('category')=='camp' and o['side']==side]
 assert len(camps)==6 and sum(o['member_count'] for o in camps)==11
assert len([o for o in b.scene.objects if o.get('category') in {'neutral','boss'}])==26
assert len([o for o in b.scene.objects if o.get('category')=='minion_template'])==6
assert all(o.location.z==0 for o in b.scene.objects if o.get('category')=='hero')
print('PASS deterministic generation, preserved user scene, six gates, 44 grass pockets, four continuous perimeter colliders',flush=True)
print('PASS all authored geometry pairs at two animation frames, shared mesh topology and camp counts',flush=True)
print('PASS crystal shatter and restoration; ten planar heroes and six minion templates',flush=True)
print('ALL GENERATOR INTEGRATION CHECKS PASSED',flush=True)
