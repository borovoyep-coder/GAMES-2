"""Integration checks; run with blender -b --python test_generator.py."""
import importlib.util,sys,json,math
from pathlib import Path
import bpy
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('valley_generator',ROOT/'generate_valley.py')
g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
# A non-generated object must survive both scene builds.
sentinel=bpy.data.objects.new('User object — preserve me',None);bpy.context.scene.collection.objects.link(sentinel)
config=g.Config(output=ROOT/'test-output',tree_count=220,resolution=320,samples=1,labels=False)
a=g.build_map(config);first=g.validate_scene(a);layout1=json.loads((config.output/'ValleyOfShards.layout.json').read_text())
b=g.build_map(config);second=g.validate_scene(b);layout2=json.loads((config.output/'ValleyOfShards.layout.json').read_text())
assert sentinel.name in bpy.data.objects and sentinel.users_collection
assert first==second and layout1==layout2,'Non-deterministic generation or duplicate objects'
assert len([s for s in bpy.data.scenes if s.name==g.SCENE_NAME])==1
assert not any(s.name.startswith('VOS temporary') for s in bpy.data.scenes)
root=b.registry['crystal_1']
for _ in range(5):g.damage_crystal(root,4,frame=10)
assert root['durability']==4 and not any(o.animation_data for o in root.children if 'rest_location' in o)
g.damage_crystal(root,4,frame=10);assert root['durability']==0
b.scene.frame_set(34)
assert all(o.scale.x<.002 for o in root.children if 'rest_location' in o),'Shards did not vanish'
g.restore_crystal(root,frame=40);b.scene.frame_set(60)
assert root['durability']==24 and all(abs(o.scale.x-1)<.001 for o in root.children if 'rest_location' in o)
# A complete stone crossing exists on each requested lane.
for lane,point in g.STONE_BRIDGES:
 assert g.route_distance(point,b.river)<.01
 assert g.route_distance(point,b.lanes[lane])<.01
assert min(v.co.z for o in b.scene.objects if o.get('category')=='playable_terrain' for v in o.data.vertices)<-2
assert max(v.co.z for o in b.scene.objects if o.get('category')=='playable_terrain' for v in o.data.vertices)==0
assert len([o for o in b.scene.objects if o.get('physics_only')])==1
assert all(o.location.z==0 for o in b.scene.objects if o.get('category')=='hero')
assert len(g.TOWER_PASSAGES)==18 and len(g.BOSS_APPROACHES)==4
for side in ['Light','Dark']:
 gates=[o for o in b.scene.objects if o.get('category')=='crystal_gate' and o['side']==side]
 assert len(gates)==4 and {o['route_role'] for o in gates}=={'ambush','hunt','rescue','invasion'}
assert all(bpy.data.images.get(g.PREFIX+n) or (config.output/'textures'/n).exists() for n in ['painted_stone.png','painted_earth.png','painted_foliage.png','flowing_water.png'])
for mat in ['BlueCrystal','RedCrystal','Amethyst','SunGlow','RiverWater','SkyWater']:
 shader=next(n for n in b.materials[mat].node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 assert shader.inputs['Emission Strength'].default_value>0,mat
trail_objects=[o for o in b.scene.objects if o.type=='MESH' and 'Forest trail ' in o.name]
assert len(trail_objects)>10
assert all(.10<o.data.vertices[0].co.z<.139 for o in trail_objects)
assert all(face.normal.z>.999 for obj in trail_objects for face in obj.data.polygons),'Downward trail normals'
heights=[round(obj.data.vertices[0].co.z,6) for obj in trail_objects]
assert len(set(heights))==len(heights),'Coplanar crossing trails'
print('PASS repeatable seeded generation, exact tower anchors, clearings, flat gameplay ground, decorative cascades, five crossings, fountains, ten heroes, eight role-based gates and emission',flush=True)
print('PASS six melee crystal hits, shatter and restoration animation',flush=True)
print('PASS user-scene preservation and no duplicate generated scenes',flush=True)
print('ALL GENERATOR INTEGRATION CHECKS PASSED',flush=True)
