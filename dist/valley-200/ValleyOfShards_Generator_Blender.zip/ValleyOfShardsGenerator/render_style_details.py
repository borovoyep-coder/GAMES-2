"""Render the actual authored meshes at a readable scale; does not save gallery into the map."""
import bpy,math,os
from pathlib import Path
from mathutils import Matrix,Vector
root=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(root/'output/ValleyOfShards.blend'))
scene=bpy.data.scenes['ValleyOfShards_200'];bpy.context.window.scene=scene;scene.frame_set(1)
scene.cycles.samples=16;scene.cycles.adaptive_threshold=.08
camera=scene.camera
collections=list(scene.collection.children)
for c in collections:
 if c.name!='VOS200::Lighting':c.hide_render=True
review=bpy.data.collections.new('Creature Review Gallery');scene.collection.children.link(review)
roots={}
for o in scene.objects:
 if o.get('category') in {'neutral','boss','minion_template'}:roots.setdefault(o.get('monster_kind') or o.get('template_key'),o)
order=['MoonWolf','StoneCentipede','RiftWraith','MagmaGuardian','AzureGolem','CrystalCrab','Watcher','RiftRay','SolarColossus','NightLeviathan','Light_Guard','Light_Caster','Light_Siege','Dark_Guard','Dark_Caster','Dark_Siege']
for i,kind in enumerate(order):
 row=i//4;col=i%4;count=min(4,len(order)-row*4);p=Vector(((col-(count-1)/2)*12,row*10.6,0));source=roots[kind];scale={'SolarColossus':1.35,'NightLeviathan':.90,'Light_Guard':1.5,'Light_Caster':1.5,'Light_Siege':1.5,'Dark_Guard':1.5,'Dark_Caster':1.5,'Dark_Siege':1.5}.get(kind,1.0)
 transform=Matrix.Translation(p)@Matrix.Scale(scale,4)@source.matrix_world.inverted()
 for obj in source.children_recursive:
  if obj.type not in {'MESH','CURVE'}:continue
  copy=obj.copy();copy.data=obj.data;copy.animation_data_clear();copy.parent=None;copy.matrix_world=transform@obj.matrix_world;review.objects.link(copy)
 # A gallery plinth is presentation geometry, not a part of the exported map.
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=3.7 if kind!='NightLeviathan' else 4.5,depth=.42,location=p+Vector((0,0,-.25)))
 pedestal=bpy.context.object
 for c in list(pedestal.users_collection):c.objects.unlink(pedestal)
 review.objects.link(pedestal);pedestal.data.materials.append(bpy.data.materials['VOS200::StoneDark'])
 modifier=pedestal.modifiers.new('Gallery softened edge','BEVEL');modifier.width=.10;modifier.segments=2
camera.location=(0,-38,47);target=Vector((0,16,1.8));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=65
scene.render.resolution_x=1280;scene.render.resolution_y=1100;scene.render.filepath=str(root/'output/Creature_Collection.png');bpy.ops.render.render(write_still=True,scene=scene.name);print('CREATURE DETAIL RENDERED',flush=True)
if os.environ.get('STYLE_RENDER_ONLY')!='creatures':
    review.hide_render=True
    for c in collections:c.hide_render=False
    camera.location=(-44,-68,52);target=Vector((-30,-28,0));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=84
    scene.render.resolution_x=1152;scene.render.resolution_y=800;scene.render.filepath=str(root/'output/Valley_Detail.png');bpy.ops.render.render(write_still=True,scene=scene.name);print('FOREST DETAIL RENDERED',flush=True)
print('STYLE DETAIL RENDERS COMPLETE',flush=True)
