from pathlib import Path
exec(compile((Path(__file__).parent/'verify_maze_scene.py').read_text(),str(Path(__file__).parent/'verify_maze_scene.py'),'exec'))
print('FOREST SCENE READ-BACK PASSED',flush=True)
