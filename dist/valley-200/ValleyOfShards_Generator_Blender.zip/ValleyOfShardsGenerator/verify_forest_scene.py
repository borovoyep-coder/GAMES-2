"""Read back actual Blender geometry and paint, not the generator's declarations."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'output/ValleyOfShards.blend'))
s=bpy.data.scenes['ValleyOfShards_200'];bpy.context.window.scene=s;s.frame_set(1);l=json.loads((R/'output/ValleyOfShards.layout.json').read_text())
meshes=[o for o in s.objects if o.type=='MESH'];bushes=[o for o in s.objects if o.get('category')=='bush'];grass=[o for o in meshes if 'Tall grass tapered curved blades' in o.name]
assert len(bushes)==40 and len(grass)==40
assert not any('crown' in o.name.lower() for b in bushes for o in b.children_recursive)
assert all(b['trigger_shape']=='capsule' and abs(b['half_length']-2.6)<1e-4 for b in bushes)
for b in bushes:
 spec=next(x for x in l['bushes'] if x['id']==b['bush_id']);assert abs(spec['angle']+b.rotation_euler.z)<1e-6
 for o in b.children:
  if o.type!='MESH':continue
  for v in o.data.vertices:
   p=o.matrix_world@v.co
   assert abs(p.x+p.y)/math.sqrt(2)>7.5,(b.name,'Grass reaches the wet bank')
   assert max(abs(p.x),abs(p.y))<96
  assert o.data.shape_keys and len(o.data.color_attributes['ValleyPaint'].data)==len(o.data.vertices)
  key=o.data.shape_keys.key_blocks['Wind bend'];assert abs(key.value)<1e-6
  for a,z in zip(o.data.vertices,key.data):
   if a.co.z==0:assert (a.co-z.co).length<1e-7
s.frame_set(35);assert all(o.data.shape_keys.key_blocks['Wind bend'].value>.9 for o in grass)
s.frame_set(1)
terrain=next(o for o in s.objects if o.get('category')=='playable_terrain');assert terrain.data.color_attributes.get('ValleyPaint')
assert any(abs(v.co.x-100)<1e-4 and abs(v.co.y)<1e-4 and abs(v.co.z+7)<1e-4 for v in terrain.data.vertices),'Outer mountain verge does not drop below the ledge'
paths=[o for o in meshes if o.get('surface_type')=='warm_ochre_trail'];assert len(paths)>=70
for o in paths:assert o.data.materials[0].name=='VOS200::TrailBlend' and o.data.color_attributes.get('ValleyPaint')
for c in [o for o in s.objects if o.get('category')=='clearing']:
 obj=next(o for o in c.children if 'Mottled' in o.name);colors=obj.data.color_attributes['ValleyPaint'];assert len({tuple(round(x,2) for x in c.color[:3]) for c in colors.data})>30
assert len([o for o in s.objects if o.get('category')=='tree'])==240
assert l['forest_wall_count']==38
assert len([o for o in meshes if o.get('obstacle_kind')=='forest_crag'])==38
assert not any('Paved forest arc' in o.name or 'Permanent bush shore island' in o.name for o in s.objects)
cores=[o for o in meshes if 'Amethyst neon internal core' in o.name];assert len(cores)==30 and all('rest_location' in o.parent for o in cores)
assert all(next(n for n in o.data.materials[0].node_tree.nodes if n.type=='BSDF_PRINCIPLED').inputs['Emission Strength'].default_value>3.7 for o in cores)
print('PASS actual saved geometry: 40 tall grass meshes with anchored animated shape keys, every blade entirely on dry ground',flush=True)
print('PASS painted feathered earth paths, four mottled clearings, 240 dark firs, 38 ruin/crag barriers and 30 inherited neon cores',flush=True)
print('FOREST SCENE READ-BACK PASSED',flush=True)
